package com.cray.hazi;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import java.util.function.Consumer;
import java.util.function.IntConsumer;

final class Ui {
    static final int BG = 0xFF0A0A0B, SURF = 0xFF151518, SURF2 = 0xFF1E1E23, YEL = 0xFFFFD60A,
            TXT = 0xFFF6F4EA, MUTED = 0xFF9B9A8E, OK = 0xFF3DDC84, BAD = 0xFFFF5A5F, LINE = 0x26FFFFFF, DARK = 0xFF111111;
    private static Typeface fb, fm, fo;

    static int dp(Context c, float v) { return Math.round(v * c.getResources().getDisplayMetrics().density); }
    static Typeface bold(Context c) { if (fb == null) fb = c.getResources().getFont(R.font.chakra_bold); return fb; }
    static Typeface med(Context c) { if (fm == null) fm = c.getResources().getFont(R.font.chakra_med); return fm; }
    static Typeface brand(Context c) { if (fo == null) fo = c.getResources().getFont(R.font.oxanium_bold); return fo; }

    static GradientDrawable rect(Context c, int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, r));
        return g;
    }
    static GradientDrawable stroke(Context c, int fill, int line, float r) {
        GradientDrawable g = rect(c, fill, r);
        g.setStroke(dp(c, 1), line);
        return g;
    }
    static GradientDrawable grad(Context c, int a, int b, float r) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{a, b});
        g.setCornerRadius(dp(c, r));
        return g;
    }

    static TextView tv(Context c, CharSequence s, float sp, int color, boolean b) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTypeface(b ? bold(c) : med(c));
        t.setIncludeFontPadding(false);
        return t;
    }

    static LinearLayout col(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }
    static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }
    static LinearLayout card(Context c) {
        LinearLayout l = col(c);
        int p = dp(c, 16);
        l.setPadding(p, p, p, p);
        l.setBackground(stroke(c, SURF, LINE, 20));
        return l;
    }
    static LinearLayout.LayoutParams lp(Context c, int w, int h, float l, float t, float r, float b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(c, l), dp(c, t), dp(c, r), dp(c, b));
        return p;
    }
    static LinearLayout.LayoutParams wrapLp(Context c, float t) {
        return lp(c, -1, -2, 0, t, 0, 0);
    }

    static void press(View v) {
        v.setOnTouchListener((x, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) x.animate().scaleX(.96f).scaleY(.96f).alpha(.85f).setDuration(80).start();
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL)
                x.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(120).start();
            return false;
        });
    }

    static TextView button(Context c, String label, boolean primary, View.OnClickListener l) {
        TextView t = tv(c, label, 14, primary ? DARK : TXT, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(c, 18), dp(c, 14), dp(c, 18), dp(c, 14));
        t.setBackground(primary ? rect(c, YEL, 16) : stroke(c, SURF2, LINE, 16));
        t.setOnClickListener(l);
        press(t);
        return t;
    }

    static TextView pill(Context c, String s, int fill, int color) {
        TextView t = tv(c, s, 11, color, true);
        t.setPadding(dp(c, 10), dp(c, 6), dp(c, 10), dp(c, 6));
        t.setBackground(rect(c, fill, 20));
        return t;
    }

    static View switchRow(Context c, String title, String sub, boolean on, Consumer<Boolean> cb) {
        LinearLayout row = row(c);
        row.setPadding(0, dp(c, 8), 0, dp(c, 8));
        LinearLayout txt = col(c);
        txt.addView(tv(c, title, 14, TXT, true));
        if (sub != null) {
            TextView s = tv(c, sub, 11, MUTED, false);
            s.setPadding(0, dp(c, 3), 0, 0);
            txt.addView(s);
        }
        row.addView(txt, new LinearLayout.LayoutParams(0, -2, 1f));
        Switch sw = new Switch(c);
        sw.setChecked(on);
        sw.setThumbTintList(new ColorStateList(new int[][]{{android.R.attr.state_checked}, {}}, new int[]{YEL, 0xFF8A8A80}));
        sw.setTrackTintList(new ColorStateList(new int[][]{{android.R.attr.state_checked}, {}}, new int[]{0x66FFD60A, 0x33FFFFFF}));
        sw.setOnCheckedChangeListener((b, v) -> cb.accept(v));
        row.addView(sw);
        return row;
    }

    static View slider(Context c, String label, int min, int max, int val, String suffix, IntConsumer cb) {
        LinearLayout l = col(c);
        l.setPadding(0, dp(c, 6), 0, dp(c, 6));
        LinearLayout head = row(c);
        TextView a = tv(c, label, 12, MUTED, true);
        TextView v = tv(c, val + suffix, 12, YEL, true);
        head.addView(a, new LinearLayout.LayoutParams(0, -2, 1f));
        head.addView(v);
        SeekBar sb = new SeekBar(c);
        sb.setMax(max - min);
        sb.setProgress(Math.max(0, Math.min(max - min, val - min)));
        sb.setProgressTintList(ColorStateList.valueOf(YEL));
        sb.setThumbTintList(ColorStateList.valueOf(YEL));
        sb.setProgressBackgroundTintList(ColorStateList.valueOf(0x33FFFFFF));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                v.setText((p + min) + suffix);
                if (user) cb.accept(p + min);
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        l.addView(head);
        l.addView(sb, new LinearLayout.LayoutParams(-1, -2));
        return l;
    }

    static View chips(Context c, String[] labels, int sel, IntConsumer cb) {
        HorizontalScrollView hs = new HorizontalScrollView(c);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(c);
        hs.addView(row);
        TextView[] ts = new TextView[labels.length];
        int[] cur = {sel};
        Runnable paint = () -> {
            for (int i = 0; i < ts.length; i++) {
                boolean on = i == cur[0];
                ts[i].setBackground(on ? rect(c, YEL, 14) : stroke(c, SURF2, LINE, 14));
                ts[i].setTextColor(on ? DARK : TXT);
            }
        };
        for (int i = 0; i < labels.length; i++) {
            TextView t = tv(c, labels[i], 12, TXT, true);
            t.setPadding(dp(c, 14), dp(c, 9), dp(c, 14), dp(c, 9));
            final int idx = i;
            t.setOnClickListener(v -> { cur[0] = idx; paint.run(); cb.accept(idx); });
            press(t);
            ts[i] = t;
            row.addView(t, lp(c, -2, -2, 0, 0, 8, 0));
        }
        paint.run();
        return hs;
    }

    static TextView section(Context c, String s) {
        TextView t = tv(c, s.toUpperCase(), 10.5f, MUTED, true);
        t.setLetterSpacing(.12f);
        t.setPadding(0, dp(c, 12), 0, dp(c, 6));
        return t;
    }
}

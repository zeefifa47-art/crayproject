package com.cray.hazi;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.Insets;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Memantau game di depan; menampilkan panel + crosshair hanya saat game dibuka. */
public class GameService extends Service {
    private static final String CH_ID = "cray_game";
    private static final long RESET_MS = 5 * 60 * 1000L;
    private static final Pattern PKG = Pattern.compile("u\\d+\\s+([\\w.]+)/");

    private final Handler main = new Handler(Looper.getMainLooper());
    private Context ctx;
    private WindowManager wm;
    private boolean alive, busy, inGame, expanded;
    private LinearLayout root, panel;
    private ScrollView body;
    private CrosshairView cross;
    private WindowManager.LayoutParams rootLp;
    private int tab = 0;
    private SharedPreferences.OnSharedPreferenceChangeListener prefL;

    static void start(Context c) {
        try { c.startForegroundService(new Intent(c, GameService.class)); } catch (Throwable ignored) { }
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        Context base = this;
        if (Build.VERSION.SDK_INT >= 30) {
            try { base = createWindowContext(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, null); } catch (Throwable ignored) { }
        }
        wm = (WindowManager) base.getSystemService(Context.WINDOW_SERVICE);
        ctx = new ContextThemeWrapper(base, R.style.Theme_Cray);
        prefL = (sp, key) -> {
            if (key != null && key.startsWith("ch_") && inGame) main.post(this::syncCrosshair);
        };
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(prefL);
    }

    @Override public int onStartCommand(Intent i, int flags, int id) {
        startFg();
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY; }
        if (!alive) { alive = true; main.post(tick); }
        return START_STICKY;
    }

    private void startFg() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CH_ID, "CRAY Mode Game", NotificationManager.IMPORTANCE_LOW));
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CH_ID)
                .setSmallIcon(R.drawable.ic_notif).setContentTitle("CRAY aktif")
                .setContentText("Panel muncul otomatis saat game dibuka").setContentIntent(pi).setOngoing(true).build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1, n);
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!alive) return;
            if (!busy) {
                busy = true;
                Shell.async(() -> {
                    final boolean ready = Shell.ready();
                    final String out = ready ? Shell.run("dumpsys activity activities | grep -E 'topResumedActivity|ResumedActivity' | head -n 3") : "";
                    main.post(() -> { busy = false; onTop(out, ready); });
                });
            }
            main.postDelayed(this, 2000);
        }
    };

    private static boolean isGame(String p) { return Angle.FF.equals(p) || Angle.FF_MAX.equals(p); }

    private void onTop(String out, boolean ready) {
        boolean now = false;
        if (ready) {
            Matcher m = PKG.matcher(out);
            if (m.find()) now = isGame(m.group(1));
        }
        if (now != inGame) {
            inGame = now;
            if (inGame) enter(); else leave();
        }
        long t = System.currentTimeMillis();
        if (inGame) {
            Prefs.put(this, Prefs.LEFT_AT, 0L);
        } else if (Resetter.anyApplied(this)) {
            long left = Prefs.l(this, Prefs.LEFT_AT, 0L);
            if (left == 0) Prefs.put(this, Prefs.LEFT_AT, t);
            else if (t - left >= RESET_MS) {
                Prefs.put(this, Prefs.LEFT_AT, 0L);
                Shell.async(() -> Resetter.resetAll(this));
                Panels.toast(this, "CRAY: semua pengaturan direset");
            }
        } else {
            Prefs.put(this, Prefs.LEFT_AT, 0L);
        }
    }

    private void enter() { showPanel(); syncCrosshair(); }

    private void leave() {
        hidePanel();
        if (cross != null) { try { wm.removeView(cross); } catch (Throwable ignored) { } cross = null; }
    }

    // ---------- Panel ----------

    private int[] safe() {
        try {
            WindowInsets wi = wm.getCurrentWindowMetrics().getWindowInsets();
            Insets in = wi.getInsetsIgnoringVisibility(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
            return new int[]{in.left, in.top};
        } catch (Throwable t) {
            return new int[]{0, 0};
        }
    }

    private Rect screen() {
        try { return wm.getCurrentWindowMetrics().getBounds(); } catch (Throwable t) { return new Rect(0, 0, 1280, 720); }
    }

    private void applyCutoutMode(WindowManager.LayoutParams lp) {
        if (Build.VERSION.SDK_INT >= 30) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        else if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
    }

    private void showPanel() {
        if (root != null) return;
        root = Ui.row(ctx);
        root.setGravity(Gravity.TOP);
        int bs = Ui.dp(ctx, 42);
        TextView bubble = Ui.tv(ctx, "C", 20, Ui.DARK, true);
        bubble.setTypeface(Ui.brand(ctx));
        bubble.setGravity(Gravity.CENTER);
        bubble.setBackground(Ui.grad(ctx, Ui.YEL, 0xFFFF9F0A, 21));
        bubble.setElevation(Ui.dp(ctx, 6));
        root.addView(bubble, new LinearLayout.LayoutParams(bs, bs));
        panel = buildPanel();
        panel.setVisibility(View.GONE);
        root.addView(panel, Ui.lp(ctx, Ui.dp(ctx, 296), -2, 8, 0, 0, 0));

        int[] s = safe();
        rootLp = new WindowManager.LayoutParams(-2, -2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        rootLp.gravity = Gravity.TOP | Gravity.START;
        rootLp.x = s[0] + Ui.dp(ctx, 16);
        rootLp.y = s[1] + Ui.dp(ctx, 20);
        applyCutoutMode(rootLp);

        final int slop = ViewConfiguration.get(ctx).getScaledTouchSlop();
        final float[] d = new float[4];
        final boolean[] moved = {false};
        bubble.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    d[0] = e.getRawX(); d[1] = e.getRawY(); d[2] = rootLp.x; d[3] = rootLp.y; moved[0] = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = e.getRawX() - d[0], dy = e.getRawY() - d[1];
                    if (Math.abs(dx) > slop || Math.abs(dy) > slop) moved[0] = true;
                    if (moved[0]) { rootLp.x = (int) (d[2] + dx); rootLp.y = (int) (d[3] + dy); clampAndUpdate(); }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!moved[0]) toggle();
                    return true;
                default:
                    return true;
            }
        });
        try { wm.addView(root, rootLp); } catch (Throwable t) { root = null; }
    }

    private void clampAndUpdate() {
        Rect sc = screen();
        int[] s = safe();
        int w = Ui.dp(ctx, 42) + (expanded ? Ui.dp(ctx, 304) : 0);
        rootLp.x = Math.max(s[0], Math.min(sc.width() - w - Ui.dp(ctx, 8), rootLp.x));
        rootLp.y = Math.max(s[1], Math.min(sc.height() - Ui.dp(ctx, 60), rootLp.y));
        try { wm.updateViewLayout(root, rootLp); } catch (Throwable ignored) { }
    }

    private void toggle() {
        expanded = !expanded;
        if (expanded) {
            Rect sc = screen();
            int avail = sc.height() - rootLp.y - Ui.dp(ctx, 24);
            setBodyHeight(Math.max(Ui.dp(ctx, 160), Math.min(Ui.dp(ctx, 250), avail - Ui.dp(ctx, 50))));
            panel.setVisibility(View.VISIBLE);
        } else {
            panel.setVisibility(View.GONE);
        }
        clampAndUpdate();
    }

    private void setBodyHeight(int h) {
        body.setLayoutParams(new LinearLayout.LayoutParams(-1, h));
    }

    private LinearLayout buildPanel() {
        LinearLayout p = Ui.col(ctx);
        int pad = Ui.dp(ctx, 12);
        p.setPadding(pad, pad, pad, pad);
        p.setBackground(Ui.stroke(ctx, 0xF2121215, 0x33FFD60A, 20));
        p.addView(Ui.tv(ctx, "CRAY", 15, Ui.YEL, true));
        p.addView(Ui.chips(ctx, new String[]{"Crosshair", "Sensi", "Layar", "Reset"}, tab, i -> { tab = i; showTab(); }),
                Ui.lp(ctx, -2, -2, 0, 8, 0, 6));
        body = new ScrollView(ctx);
        body.setVerticalScrollBarEnabled(false);
        p.addView(body, new LinearLayout.LayoutParams(-1, Ui.dp(ctx, 200)));
        showTab();
        return p;
    }

    private void showTab() {
        body.removeAllViews();
        View v;
        if (tab == 0) v = Panels.crosshair(ctx);
        else if (tab == 1) v = Panels.sensi(ctx);
        else if (tab == 2) v = Panels.display(ctx);
        else {
            LinearLayout l = Ui.col(ctx);
            TextView t = Ui.tv(ctx, "Kembalikan semua pengaturan (crosshair, Pixel Lab, DPI, kecerahan, suara) ke awal. Otomatis juga terjadi jika 5 menit tidak kembali ke game.", 12, Ui.MUTED, false);
            t.setLineSpacing(0, 1.2f);
            l.addView(t);
            l.addView(Ui.button(ctx, "Reset Semua", true, x -> {
                Shell.async(() -> Resetter.resetAll(this));
                Panels.toast(this, "Semua pengaturan direset");
                main.postDelayed(this::syncCrosshair, 600);
            }), Ui.wrapLp(ctx, 12));
            v = l;
        }
        body.addView(v);
    }

    private void hidePanel() {
        if (root != null) { try { wm.removeView(root); } catch (Throwable ignored) { } }
        root = null; panel = null; body = null; expanded = false;
    }

    // ---------- Crosshair ----------

    private void syncCrosshair() {
        if (!inGame || !Prefs.b(this, Prefs.CH_ON, false)) {
            if (cross != null) { try { wm.removeView(cross); } catch (Throwable ignored) { } cross = null; }
            return;
        }
        int size = Ui.dp(ctx, Prefs.i(this, Prefs.CH_SIZE, 28) + 6);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(size, size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.CENTER;
        lp.x = Ui.dp(ctx, Prefs.i(this, Prefs.CH_DX, 0));
        lp.y = Ui.dp(ctx, Prefs.i(this, Prefs.CH_DY, 0));
        applyCutoutMode(lp);
        try {
            if (cross == null) { cross = new CrosshairView(ctx); wm.addView(cross, lp); }
            else { wm.updateViewLayout(cross, lp); cross.invalidate(); }
        } catch (Throwable ignored) { }
    }

    @Override public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        if (root != null) {
            int[] s = safe();
            rootLp.x = s[0] + Ui.dp(ctx, 16);
            rootLp.y = s[1] + Ui.dp(ctx, 20);
            clampAndUpdate();
        }
        if (cross != null) syncCrosshair();
    }

    @Override public void onDestroy() {
        alive = false;
        main.removeCallbacksAndMessages(null);
        try { Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(prefL); } catch (Throwable ignored) { }
        leave();
        super.onDestroy();
    }
}

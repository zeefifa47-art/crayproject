package com.cray.hazi;

import android.content.Context;
import android.content.SharedPreferences;

final class Prefs {
    static final String CH_ON = "ch_on", CH_STYLE = "ch_style", CH_SIZE = "ch_size", CH_ALPHA = "ch_alpha",
            CH_COLOR = "ch_color", CH_DX = "ch_dx", CH_DY = "ch_dy";
    static final String GAME_MODE = "game_mode", LEFT_AT = "left_at";
    static final String PX_LEVEL = "px_level", PX_NEAREST = "px_nearest", PX_MIP = "px_mip",
            PX_FF = "px_ff", PX_MAX = "px_max", PX_APPLIED = "px_applied", PX_TAB = "px_tab";
    static final String DPI_BASE = "dpi_base", DPI_APPLIED = "dpi_applied";
    static final String BR_ORIG = "br_orig", BR_MODE = "br_mode", VOL_ORIG = "vol_orig";
    static final String SENSI_STYLE = "sensi_style", SENSI_BOOST = "sensi_boost";

    static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("cray", Context.MODE_PRIVATE);
    }
    static int i(Context c, String k, int d) { return sp(c).getInt(k, d); }
    static boolean b(Context c, String k, boolean d) { return sp(c).getBoolean(k, d); }
    static long l(Context c, String k, long d) { return sp(c).getLong(k, d); }
    static void put(Context c, String k, int v) { sp(c).edit().putInt(k, v).apply(); }
    static void put(Context c, String k, boolean v) { sp(c).edit().putBoolean(k, v).apply(); }
    static void put(Context c, String k, long v) { sp(c).edit().putLong(k, v).apply(); }
}

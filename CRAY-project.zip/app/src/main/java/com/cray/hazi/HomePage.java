package com.cray.hazi;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

final class HomePage {
    static final String TIKTOK = "https://www.tiktok.com/@inihazi";
    static final String WA = "https://whatsapp.com/channel/0029VbDubQbHrDZYJiw3fC1s";

    static void open(Activity a, String url) {
        try { a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Throwable t) { Panels.toast(a, "Tidak bisa membuka tautan"); }
    }

    static View build(Activity a, Runnable goDonate) {
        ScrollView sv = new ScrollView(a);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout l = Ui.col(a);
        int p = Ui.dp(a, 20);
        l.setPadding(p, Ui.dp(a, 8), p, Ui.dp(a, 32));
        sv.addView(l);

        // Hero
        LinearLayout hero = Ui.col(a);
        hero.setPadding(Ui.dp(a, 20), Ui.dp(a, 20), Ui.dp(a, 20), Ui.dp(a, 16));
        hero.setBackground(Ui.grad(a, Ui.YEL, 0xFFFF9F0A, 26));
        TextView tag = Ui.tv(a, "GAME SPACE", 10.5f, 0xAA111111, true);
        tag.setLetterSpacing(.2f);
        hero.addView(tag);
        TextView title = Ui.tv(a, "CRAY", 42, Ui.DARK, true);
        title.setTypeface(Ui.brand(a));
        hero.addView(title, Ui.wrapLp(a, 4));
        TextView sub = Ui.tv(a, "Crosshair, sensitivity, dan Pixel Lab untuk Free Fire.", 13, 0xCC111111, false);
        sub.setLineSpacing(0, 1.15f);
        hero.addView(sub, Ui.wrapLp(a, 6));
        LinearLayout inner = Ui.col(a);
        inner.setPadding(Ui.dp(a, 16), Ui.dp(a, 4), Ui.dp(a, 12), Ui.dp(a, 4));
        inner.setBackground(Ui.rect(a, Ui.DARK, 18));
        inner.addView(Ui.switchRow(a, "Mode Game", "Panel muncul otomatis saat game dibuka",
                Prefs.b(a, Prefs.GAME_MODE, true), v -> {
                    Prefs.put(a, Prefs.GAME_MODE, v);
                    if (v) GameService.start(a); else a.stopService(new Intent(a, GameService.class));
                }));
        hero.addView(inner, Ui.wrapLp(a, 16));
        l.addView(hero);

        // Info
        LinearLayout chips = Ui.row(a);
        chips.addView(Ui.pill(a, "Shizuku aktif", 0x333DDC84, Ui.OK));
        chips.addView(Ui.pill(a, "Panel kiri atas", 0x33FFD60A, Ui.YEL), Ui.lp(a, -2, -2, 8, 0, 0, 0));
        chips.addView(Ui.pill(a, "Reset 5 menit", 0x33FFFFFF, Ui.TXT), Ui.lp(a, -2, -2, 8, 0, 0, 0));
        l.addView(chips, Ui.wrapLp(a, 14));

        // Pixel Lab
        boolean ok = Build.VERSION.SDK_INT >= 35;
        LinearLayout px = Ui.card(a);
        LinearLayout ph = Ui.row(a);
        ph.addView(Ui.tv(a, "Pixel Lab", 18, Ui.TXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        ph.addView(Ui.pill(a, ok ? "Android 15+" : "Terkunci", ok ? 0x33FFD60A : 0x33FF5A5F, ok ? Ui.YEL : Ui.BAD));
        px.addView(ph);
        TextView pd = Ui.tv(a, "Buat tekstur game jadi kotak-kotak ala retro. Ada gambar sampel sebelum dan sesudah.", 12.5f, Ui.MUTED, false);
        pd.setLineSpacing(0, 1.15f);
        px.addView(pd, Ui.wrapLp(a, 8));
        px.addView(Ui.button(a, ok ? "Buka Pixel Lab" : "Butuh Android 15 ke atas", ok, v -> {
            if (Build.VERSION.SDK_INT >= 35) a.startActivity(new Intent(a, PixelLabActivity.class));
            else Panels.toast(a, "Pixel Lab hanya untuk Android 15 ke atas");
        }), Ui.wrapLp(a, 12));
        l.addView(px, Ui.wrapLp(a, 16));

        // Pengaturan panel
        LinearLayout set = Ui.card(a);
        set.addView(Ui.tv(a, "Pengaturan Panel", 18, Ui.TXT, true));
        TextView sd = Ui.tv(a, "Atur dari sini atau langsung dari panel saat di dalam game.", 12.5f, Ui.MUTED, false);
        set.addView(sd, Ui.wrapLp(a, 6));
        LinearLayout box = Ui.col(a);
        int[] cur = {-1};
        Runnable[] show = new Runnable[1];
        set.addView(Ui.chips(a, new String[]{"Crosshair", "Sensitivity", "Layar"}, 0, i -> {
            cur[0] = i;
            box.removeAllViews();
            box.addView(i == 0 ? Panels.crosshair(a) : i == 1 ? Panels.sensi(a) : Panels.display(a));
        }), Ui.wrapLp(a, 14));
        box.addView(Panels.crosshair(a));
        set.addView(box, Ui.wrapLp(a, 4));
        l.addView(set, Ui.wrapLp(a, 16));

        TextView rs = Ui.tv(a, "Semua fitur, termasuk Pixel Lab, otomatis kembali normal jika 5 menit tidak kembali ke game.", 11.5f, Ui.MUTED, false);
        rs.setLineSpacing(0, 1.2f);
        l.addView(rs, Ui.wrapLp(a, 14));

        TextView don = Ui.button(a, "Dukung CRAY lewat QRIS  >", false, v -> goDonate.run());
        l.addView(don, Ui.wrapLp(a, 16));

        LinearLayout links = Ui.row(a);
        links.addView(Ui.button(a, "by @inihazi", true, v -> open(a, TIKTOK)), new LinearLayout.LayoutParams(0, -2, 1f));
        links.addView(Ui.button(a, "Saluran WhatsApp", false, v -> open(a, WA)), Ui.lp(a, 0, -2, 10, 0, 0, 0));
        ((LinearLayout.LayoutParams) links.getChildAt(1).getLayoutParams()).weight = 1f;
        l.addView(links, Ui.wrapLp(a, 12));

        TextView foot = Ui.tv(a, "CRAY  •  by @inihazi", 11, Ui.MUTED, false);
        foot.setGravity(Gravity.CENTER);
        l.addView(foot, Ui.wrapLp(a, 20));
        return sv;
    }
}

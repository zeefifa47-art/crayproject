package com.cray.hazi;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;
import java.util.Random;

/** Gambar sampel sebelum/sesudah. Simulasi buatan app sendiri, bukan tampilan asli game. */
final class CompareView extends View {
    private static final int S = 320;
    private final Bitmap base;
    private Bitmap after;
    private boolean nearest;
    private float split = .5f;
    private final Paint pf = new Paint(Paint.FILTER_BITMAP_FLAG), pn = new Paint();
    private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG), pill = new Paint(Paint.ANTI_ALIAS_FLAG),
            line = new Paint(Paint.ANTI_ALIAS_FLAG), knob = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path clip = new Path();

    CompareView(Context c) {
        super(c);
        base = makeBase();
        txt.setTypeface(Ui.bold(c));
        txt.setTextSize(Ui.dp(c, 11));
        pill.setColor(0xAA000000);
        line.setColor(Color.WHITE);
        knob.setColor(Ui.YEL);
        update(0, false, false);
    }

    void update(int level, boolean nearestFilter, boolean mip) {
        nearest = nearestFilter;
        int f = 1 << Math.max(0, Math.min(4, level));
        int n = Math.max(8, S / f);
        Bitmap small = Bitmap.createScaledBitmap(base, n, n, true);
        Bitmap out = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(out);
        Paint pp = new Paint();
        pp.setFilterBitmap(!nearestFilter);
        Rect full = new Rect(0, 0, S, S);
        cv.drawBitmap(small, null, full, pp);
        if (mip) {
            Bitmap far = Bitmap.createScaledBitmap(base, Math.max(6, n / 2), Math.max(6, n / 2), true);
            cv.save();
            cv.clipRect(0, 210, S, S);
            cv.drawBitmap(far, null, full, pp);
            cv.restore();
        }
        after = out;
        invalidate();
    }

    private Bitmap makeBase() {
        Bitmap b = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        Random rnd = new Random(7);
        Paint p = new Paint();
        cv.drawColor(0xFFCDBFB6);
        int rowH = 26, bw = 62;
        for (int r = 0; r * rowH < 210; r++) {
            int off = (r % 2) * (bw / 2);
            for (int x = -off; x < S; x += bw) {
                int j = rnd.nextInt(30) - 15;
                int col = rnd.nextInt(100) < 20 ? Color.rgb(104 + j, 140 + j, 60) : Color.rgb(160 + j, 96 + j, 92 + j);
                p.setColor(col);
                cv.drawRect(x + 2, r * rowH + 2, x + bw - 2, r * rowH + rowH - 2, p);
                if (rnd.nextInt(100) < 35) {
                    p.setColor(Color.argb(70, 0, 0, 0));
                    cv.drawRect(x + 4, r * rowH + rowH - 9, x + bw - 6, r * rowH + rowH - 4, p);
                }
            }
        }
        for (int y = 210; y < S; y += 4) {
            for (int x = 0; x < S; x += 4) {
                int k = rnd.nextInt(10), j = rnd.nextInt(34) - 17;
                p.setColor(k < 7 ? Color.rgb(64 + j, 140 + j, 58 + j) : Color.rgb(130 + j, 88 + j, 70 + j));
                cv.drawRect(x, y, x + 4, y + 4, p);
            }
        }
        return b;
    }

    @Override protected void onDraw(Canvas cv) {
        Context c = getContext();
        int w = getWidth(), h = getHeight();
        clip.reset();
        clip.addRoundRect(new RectF(0, 0, w, h), Ui.dp(c, 20), Ui.dp(c, 20), Path.Direction.CW);
        cv.clipPath(clip);
        RectF dst = new RectF(0, 0, w, h);
        cv.drawBitmap(base, null, dst, pf);
        int sx = (int) (w * split);
        cv.save();
        cv.clipRect(sx, 0, w, h);
        cv.drawBitmap(after, null, dst, nearest ? pn : pf);
        cv.restore();
        cv.drawRect(sx - Ui.dp(c, 1), 0, sx + Ui.dp(c, 1), h, line);
        cv.drawCircle(sx, h / 2f, Ui.dp(c, 18), knob);
        txt.setColor(Ui.DARK);
        txt.setTextAlign(Paint.Align.CENTER);
        cv.drawText("<>", sx, h / 2f + Ui.dp(c, 4), txt);
        label(cv, "SEBELUM", Ui.dp(c, 12), false);
        label(cv, "SESUDAH", w - Ui.dp(c, 12), true);
    }

    private void label(Canvas cv, String s, float x, boolean right) {
        Context c = getContext();
        txt.setColor(Color.WHITE);
        txt.setTextAlign(Paint.Align.LEFT);
        float tw = txt.measureText(s), pad = Ui.dp(c, 8), y = Ui.dp(c, 12);
        float l = right ? x - tw - pad * 2 : x;
        cv.drawRoundRect(new RectF(l, y, l + tw + pad * 2, y + Ui.dp(c, 24)), Ui.dp(c, 12), Ui.dp(c, 12), pill);
        cv.drawText(s, l + pad, y + Ui.dp(c, 16), txt);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN && getParent() != null)
            getParent().requestDisallowInterceptTouchEvent(true);
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN || e.getActionMasked() == MotionEvent.ACTION_MOVE) {
            split = Math.max(.05f, Math.min(.95f, e.getX() / Math.max(1, getWidth())));
            invalidate();
        }
        return true;
    }
}

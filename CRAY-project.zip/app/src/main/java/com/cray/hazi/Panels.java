package com.cray.hazi;

import android.content.ContentResolver;
import android.content.Context;
import android.content.res.Resources;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** Isi panel fitur, dipakai di aplikasi dan di panel dalam game. */
final class Panels {
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    static void toast(Context c, String s) {
        MAIN.post(() -> Toast.makeText(c.getApplicationContext(), s, Toast.LENGTH_SHORT).show());
    }

    static View crosshair(Context c) {
        LinearLayout l = Ui.col(c);
        l.addView(Ui.switchRow(c, "Crosshair", "Titik bidik di tengah layar saat bermain",
                Prefs.b(c, Prefs.CH_ON, false), v -> Prefs.put(c, Prefs.CH_ON, v)));
        l.addView(Ui.section(c, "Gaya"));
        l.addView(Ui.chips(c, new String[]{"Titik", "Plus", "Lingkaran", "Bidik"},
                Prefs.i(c, Prefs.CH_STYLE, 1), i -> Prefs.put(c, Prefs.CH_STYLE, i)));
        l.addView(Ui.slider(c, "Ukuran", 8, 90, Prefs.i(c, Prefs.CH_SIZE, 28), " dp", v -> Prefs.put(c, Prefs.CH_SIZE, v)));
        l.addView(Ui.slider(c, "Transparansi", 20, 100, Prefs.i(c, Prefs.CH_ALPHA, 90), "%", v -> Prefs.put(c, Prefs.CH_ALPHA, v)));
        l.addView(Ui.section(c, "Warna"));
        l.addView(Ui.chips(c, new String[]{"Kuning", "Merah", "Hijau", "Putih", "Cyan"},
                Prefs.i(c, Prefs.CH_COLOR, 0), i -> Prefs.put(c, Prefs.CH_COLOR, i)));
        l.addView(Ui.section(c, "Posisi"));
        l.addView(Ui.slider(c, "Geser kiri / kanan", -80, 80, Prefs.i(c, Prefs.CH_DX, 0), "", v -> Prefs.put(c, Prefs.CH_DX, v)));
        l.addView(Ui.slider(c, "Geser atas / bawah", -80, 80, Prefs.i(c, Prefs.CH_DY, 0), "", v -> Prefs.put(c, Prefs.CH_DY, v)));
        return l;
    }

    static View sensi(Context c) {
        LinearLayout l = Ui.col(c);
        if (Prefs.i(c, Prefs.DPI_APPLIED, 0) == 0)
            Prefs.put(c, Prefs.DPI_BASE, Resources.getSystem().getDisplayMetrics().densityDpi);
        int base = Prefs.i(c, Prefs.DPI_BASE, 420);
        int cur = Prefs.i(c, Prefs.DPI_APPLIED, 0) != 0 ? Prefs.i(c, Prefs.DPI_APPLIED, base) : base;
        int[] pick = {cur};

        l.addView(Ui.section(c, "DPI layar"));
        l.addView(Ui.slider(c, "DPI (bawaan " + base + ")", 280, 640, cur, "", v -> pick[0] = v));
        LinearLayout btns = Ui.row(c);
        btns.addView(Ui.button(c, "Terapkan DPI", true, v -> Shell.async(() -> {
            if (!Shell.ready()) { toast(c, "Shizuku belum aktif"); return; }
            Shell.run("wm density " + pick[0]);
            Prefs.put(c, Prefs.DPI_APPLIED, pick[0]);
            toast(c, "DPI " + pick[0] + " diterapkan");
        })), new LinearLayout.LayoutParams(0, -2, 1f));
        btns.addView(Ui.button(c, "Reset", false, v -> Shell.async(() -> {
            if (Shell.ready()) Shell.run("wm density reset");
            Prefs.put(c, Prefs.DPI_APPLIED, 0);
            toast(c, "DPI dikembalikan");
        })), Ui.lp(c, 0, -2, 8, 0, 0, 0));
        ((LinearLayout.LayoutParams) btns.getChildAt(1).getLayoutParams()).weight = 1f;
        l.addView(btns, Ui.wrapLp(c, 6));
        TextView warn = Ui.tv(c, "DPI mengubah skala tampilan sehingga rasa sentuh ikut berubah. Kembali normal otomatis jika 5 menit tidak masuk game.", 11, Ui.MUTED, false);
        warn.setPadding(0, Ui.dp(c, 8), 0, 0);
        l.addView(warn);

        l.addView(Ui.section(c, "Saran sensitivity dalam game"));
        LinearLayout table = Ui.col(c);
        Runnable fill = () -> {
            table.removeAllViews();
            int[] vals = SensiCalc.values(Prefs.i(c, Prefs.SENSI_STYLE, 1), Prefs.i(c, Prefs.SENSI_BOOST, 0));
            for (int i = 0; i < vals.length; i++) {
                LinearLayout r = Ui.row(c);
                r.setPadding(Ui.dp(c, 12), Ui.dp(c, 9), Ui.dp(c, 12), Ui.dp(c, 9));
                r.setBackground(Ui.rect(c, i % 2 == 0 ? Ui.SURF2 : Ui.SURF, 10));
                r.addView(Ui.tv(c, SensiCalc.NAMES[i], 13, Ui.TXT, false), new LinearLayout.LayoutParams(0, -2, 1f));
                r.addView(Ui.tv(c, String.valueOf(vals[i]), 14, Ui.YEL, true));
                table.addView(r);
            }
        };
        fill.run();
        l.addView(Ui.chips(c, SensiCalc.STYLES, Prefs.i(c, Prefs.SENSI_STYLE, 1), i -> { Prefs.put(c, Prefs.SENSI_STYLE, i); fill.run(); }));
        l.addView(Ui.slider(c, "Naik / turun semua", -10, 10, Prefs.i(c, Prefs.SENSI_BOOST, 0), "", v -> { Prefs.put(c, Prefs.SENSI_BOOST, v); fill.run(); }));
        l.addView(table, Ui.wrapLp(c, 4));
        TextView note = Ui.tv(c, "Titik awal saja. Atur angka ini di menu Pengaturan > Sensitivitas dalam game, lalu sesuaikan sendiri.", 11, Ui.MUTED, false);
        note.setPadding(0, Ui.dp(c, 8), 0, 0);
        l.addView(note);
        return l;
    }

    static View display(Context c) {
        LinearLayout l = Ui.col(c);
        ContentResolver cr = c.getContentResolver();
        int br;
        try { br = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS); } catch (Exception e) { br = 128; }
        l.addView(Ui.slider(c, "Kecerahan", 1, 255, br, "", v -> {
            if (!Settings.System.canWrite(c)) { toast(c, "Izin ubah sistem belum diberikan"); return; }
            try {
                if (Prefs.i(c, Prefs.BR_ORIG, -1) < 0) {
                    Prefs.put(c, Prefs.BR_MODE, Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, 0));
                    Prefs.put(c, Prefs.BR_ORIG, Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128));
                }
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, 0);
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, v);
            } catch (Throwable t) { toast(c, "Gagal mengubah kecerahan"); }
        }));
        AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
        int max = Math.max(1, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        l.addView(Ui.slider(c, "Volume media", 0, max, am.getStreamVolume(AudioManager.STREAM_MUSIC), "", v -> {
            try {
                if (Prefs.i(c, Prefs.VOL_ORIG, -1) < 0)
                    Prefs.put(c, Prefs.VOL_ORIG, am.getStreamVolume(AudioManager.STREAM_MUSIC));
                am.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0);
            } catch (Throwable t) { toast(c, "Gagal mengubah volume"); }
        }));
        l.addView(Ui.button(c, "Kembalikan kecerahan & suara", false, v -> {
            Resetter.restoreDisplay(c);
            toast(c, "Dikembalikan ke semula");
        }), Ui.wrapLp(c, 10));
        return l;
    }
}

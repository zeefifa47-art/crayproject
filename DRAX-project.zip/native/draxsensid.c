/*
 * draxsensid - pengali sensitivitas sentuh per sumbu (X dan Y).
 *
 * Cara kerja: membaca event dari layar sentuh, membuat layar sentuh virtual (uinput), lalu
 * meneruskan event dengan pergeseran jari (dari titik sentuh awal) dikalikan faktor X/Y.
 * Hanya sentuhan yang dimulai di area yang dipilih (default: kanan layar) yang dikalikan,
 * sehingga joystick tetap normal.
 *
 * Pengaman:
 *  - berhenti sendiri bila file konfigurasi tidak disentuh lebih dari 10 detik
 *    (aplikasi mengirim detak jantung tiap ~2 detik),
 *  - berhenti dan melepas layar sentuh asli pada kesalahan apa pun atau sinyal TERM/INT/HUP,
 *  - bila proses mati paksa, kernel otomatis melepas layar sentuh asli.
 *
 * Konfigurasi (satu baris): "<kx> <ky> <zona%> <aktif>"
 */
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <linux/input.h>
#include <linux/uinput.h>
#include <poll.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#define MAXS 24
#define BATCH 256
#define DEADMAN_SEC 10
#define LONG_BITS (8 * sizeof(unsigned long))
#define NBITS(x) ((((x) - 1) / LONG_BITS) + 1)

static volatile sig_atomic_t g_run = 1;
static const char *STATUS = "/data/local/tmp/drax_sensi.status";

static void on_sig(int s) { (void)s; g_run = 0; }

static void status(const char *msg) {
    FILE *f = fopen(STATUS, "w");
    if (f) { fputs(msg, f); fputc('\n', f); fclose(f); }
}

static int test_bit(int bit, const unsigned long *arr) {
    return (arr[bit / LONG_BITS] >> (bit % LONG_BITS)) & 1UL;
}

typedef struct { float kx, ky; int zone; int on; } Cfg;
typedef struct { int x0, y0, hx, hy, scale; } Slot;

/* 1 = ok, 0 = isi tidak valid (konfigurasi lama dipakai), -1 = file hilang */
static int load_cfg(const char *path, Cfg *c, time_t *mtime) {
    struct stat st;
    if (stat(path, &st) != 0) return -1;
    *mtime = st.st_mtime;
    FILE *f = fopen(path, "r");
    if (!f) return -1;
    float kx, ky;
    int z, on;
    int n = fscanf(f, "%f %f %d %d", &kx, &ky, &z, &on);
    fclose(f);
    if (n != 4) return 0;
    if (kx < 1.0f) kx = 1.0f;
    if (kx > 4.0f) kx = 4.0f;
    if (ky < 1.0f) ky = 1.0f;
    if (ky > 4.0f) ky = 4.0f;
    if (z < 0) z = 0;
    if (z > 90) z = 90;
    c->kx = kx; c->ky = ky; c->zone = z; c->on = on ? 1 : 0;
    return 1;
}

/* Cari layar sentuh multitouch langsung (INPUT_PROP_DIRECT). */
static int open_touch(char *name, size_t nlen, struct input_id *id) {
    char path[64];
    for (int i = 0; i < 64; i++) {
        snprintf(path, sizeof path, "/dev/input/event%d", i);
        int fd = open(path, O_RDONLY | O_CLOEXEC);
        if (fd < 0) continue;
        unsigned long abs[NBITS(ABS_MAX + 1)];
        unsigned long prop[NBITS(INPUT_PROP_MAX + 1)];
        memset(abs, 0, sizeof abs);
        memset(prop, 0, sizeof prop);
        if (ioctl(fd, EVIOCGBIT(EV_ABS, sizeof abs), abs) >= 0 &&
            test_bit(ABS_MT_POSITION_X, abs) && test_bit(ABS_MT_POSITION_Y, abs)) {
            ioctl(fd, EVIOCGPROP(sizeof prop), prop);
            if (test_bit(INPUT_PROP_DIRECT, prop)) {
                memset(name, 0, nlen);
                ioctl(fd, EVIOCGNAME(nlen - 1), name);
                ioctl(fd, EVIOCGID, id);
                return fd;
            }
        }
        close(fd);
    }
    return -1;
}

static int make_uinput(const char *name, const struct input_id *id,
                       const struct input_absinfo *ai, const unsigned long *absbits) {
    int u = open("/dev/uinput", O_WRONLY | O_NONBLOCK | O_CLOEXEC);
    if (u < 0) return -1;
    struct uinput_user_dev dev;
    memset(&dev, 0, sizeof dev);
    snprintf(dev.name, UINPUT_MAX_NAME_SIZE, "%s", name);
    dev.id = *id;
    if (ioctl(u, UI_SET_EVBIT, EV_SYN) < 0 || ioctl(u, UI_SET_EVBIT, EV_KEY) < 0 ||
        ioctl(u, UI_SET_EVBIT, EV_ABS) < 0 || ioctl(u, UI_SET_KEYBIT, BTN_TOUCH) < 0) {
        close(u);
        return -1;
    }
    ioctl(u, UI_SET_PROPBIT, INPUT_PROP_DIRECT);
    for (int c = 0; c <= ABS_MAX; c++) {
        if (!test_bit(c, absbits)) continue;
        if (ioctl(u, UI_SET_ABSBIT, c) < 0) continue;
        dev.absmin[c] = ai[c].minimum;
        dev.absmax[c] = ai[c].maximum;
        dev.absfuzz[c] = ai[c].fuzz;
        dev.absflat[c] = ai[c].flat;
    }
    if (write(u, &dev, sizeof dev) != (ssize_t)sizeof dev) { close(u); return -1; }
    if (ioctl(u, UI_DEV_CREATE) < 0) { close(u); return -1; }
    return u;
}

static int clampi(long v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : (int)v); }

int main(int argc, char **argv) {
    const char *conf = argc > 1 ? argv[1] : "/data/local/tmp/drax_sensi.conf";
    signal(SIGTERM, on_sig);
    signal(SIGINT, on_sig);
    signal(SIGHUP, on_sig);
    signal(SIGPIPE, SIG_IGN);

    Cfg cfg = {1.0f, 1.0f, 50, 0};
    time_t mt = 0;
    if (load_cfg(conf, &cfg, &mt) < 0) { status("error: tidak ada konfigurasi"); return 1; }

    char name[80];
    struct input_id id;
    int tfd = open_touch(name, sizeof name, &id);
    if (tfd < 0) { status("error: layar sentuh tidak ditemukan / tidak ada izin"); return 2; }

    unsigned long absbits[NBITS(ABS_MAX + 1)];
    struct input_absinfo ai[ABS_CNT];
    memset(absbits, 0, sizeof absbits);
    memset(ai, 0, sizeof ai);
    if (ioctl(tfd, EVIOCGBIT(EV_ABS, sizeof absbits), absbits) < 0) { status("error: baca kemampuan"); return 3; }
    for (int c = 0; c <= ABS_MAX; c++)
        if (test_bit(c, absbits)) ioctl(tfd, EVIOCGABS(c), &ai[c]);

    int xmin = ai[ABS_MT_POSITION_X].minimum, xmax = ai[ABS_MT_POSITION_X].maximum;
    int ymin = ai[ABS_MT_POSITION_Y].minimum, ymax = ai[ABS_MT_POSITION_Y].maximum;
    if (xmax <= xmin || ymax <= ymin) { status("error: rentang layar tidak valid"); return 3; }

    int u = make_uinput(name, &id, ai, absbits);
    if (u < 0) { status("error: /dev/uinput tidak bisa dipakai"); return 4; }
    usleep(300000); /* beri waktu sistem mengenali perangkat virtual */

    if (ioctl(tfd, EVIOCGRAB, 1) < 0) {
        ioctl(u, UI_DEV_DESTROY);
        close(u);
        status("error: gagal mengambil alih layar sentuh");
        return 5;
    }
    status("running");

    Slot slots[MAXS];
    memset(slots, 0, sizeof slots);
    int cur = 0;
    struct input_event out[BATCH];
    int n = 0;
    time_t last_cfg = 0;
    struct pollfd pfd = {tfd, POLLIN, 0};

    while (g_run) {
        int r = poll(&pfd, 1, 150);
        time_t now = time(NULL);
        if (now != last_cfg) {
            last_cfg = now;
            time_t m = 0;
            int lr = load_cfg(conf, &cfg, &m);
            if (lr < 0 || now - m > DEADMAN_SEC) break;
        }
        if (r < 0) { if (errno == EINTR) continue; break; }
        if (r == 0) continue;
        if (pfd.revents & (POLLERR | POLLHUP | POLLNVAL)) break;

        struct input_event ev[64];
        ssize_t len = read(tfd, ev, sizeof ev);
        if (len < 0) { if (errno == EAGAIN || errno == EINTR) continue; break; }
        int cnt = (int)(len / (ssize_t)sizeof(struct input_event));
        int bad = 0;
        for (int i = 0; i < cnt; i++) {
            struct input_event e = ev[i];
            if (e.type == EV_ABS) {
                Slot *s = &slots[cur];
                if (e.code == ABS_MT_SLOT) {
                    cur = clampi(e.value, 0, MAXS - 1);
                } else if (e.code == ABS_MT_TRACKING_ID) {
                    memset(s, 0, sizeof *s);
                } else if (e.code == ABS_MT_POSITION_X) {
                    if (!s->hx) {
                        s->hx = 1;
                        s->x0 = e.value;
                        int thr = xmin + (int)((long)(xmax - xmin) * cfg.zone / 100);
                        s->scale = (cfg.zone == 0 || e.value >= thr);
                    } else if (cfg.on && s->scale && cfg.kx != 1.0f) {
                        e.value = clampi((long)s->x0 + (long)((e.value - s->x0) * cfg.kx), xmin, xmax);
                    }
                } else if (e.code == ABS_MT_POSITION_Y) {
                    if (!s->hy) {
                        s->hy = 1;
                        s->y0 = e.value;
                    } else if (cfg.on && s->scale && cfg.ky != 1.0f) {
                        e.value = clampi((long)s->y0 + (long)((e.value - s->y0) * cfg.ky), ymin, ymax);
                    }
                }
            }
            out[n++] = e;
            if ((e.type == EV_SYN && e.code == SYN_REPORT) || n == BATCH) {
                ssize_t w = write(u, out, (size_t)n * sizeof(struct input_event));
                n = 0;
                if (w < 0 && errno != EAGAIN) { bad = 1; break; }
            }
        }
        if (bad) break;
    }

    ioctl(tfd, EVIOCGRAB, 0);
    ioctl(u, UI_DEV_DESTROY);
    close(u);
    close(tfd);
    status("stopped");
    return 0;
}

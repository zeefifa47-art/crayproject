# DRAX (com.cray.hazi)

Upload isi folder ini ke repo GitHub (branch `main`), lalu buka tab **Actions** → **Build DRAX APK**.
Hasil: `DRAX.apk` ada di **Artifacts** dan di halaman **Releases**.

Catatan:
- Tanda tangan APK dibuat otomatis dan disimpan di cache GitHub. Agar update tidak bentrok tanda tangan,
  simpan keystore sendiri: `base64 cray.jks` → secret `KEYSTORE_B64` (alias `cray`, password di secret `KS_PASS`).
- QR donasi ada di `secret/qris.jpg`, dienkripsi saat build dan terikat ke tanda tangan APK (`tools/bind_qr.py`).

## Sensi X/Y
`native/draxsensid.c` dikompilasi otomatis oleh workflow (NDK, arm64) menjadi `assets/draxsensid`.
Di HP, DRAX menyalin file itu ke `/data/local/tmp` lewat Shizuku dan menjalankannya hanya saat game
dengan panel aktif sedang dibuka. Berhenti sendiri jika DRAX tertutup (detak jantung 10 detik).

package com.cray.hazi;

/** Saran titik awal sensitivity di dalam game (slider 0-100). Sesuaikan sendiri. */
final class SensiCalc {
    static final String[] NAMES = {"General", "Red Dot", "2x Scope", "4x Scope", "AWM Scope", "Free Look"};
    static final String[] STYLES = {"Stabil", "Seimbang", "Cepat"};
    private static final int[][] BASE = {
            {70, 64, 58, 52, 40, 65},
            {82, 78, 70, 64, 52, 75},
            {92, 90, 84, 78, 66, 85}};

    static int[] values(int style, int boost) {
        int[] b = BASE[Math.max(0, Math.min(2, style))];
        int[] o = new int[b.length];
        for (int i = 0; i < b.length; i++) o[i] = Math.max(0, Math.min(100, b[i] + boost));
        return o;
    }
}

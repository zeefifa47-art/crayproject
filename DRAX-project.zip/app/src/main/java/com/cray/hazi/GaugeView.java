package com.cray.hazi;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Gauge FPS setengah lingkaran terbuka di bawah. */
final class GaugeView extends View {
    private int fps = -1, max = 120;
    private String sub;
    private final Paint tr = new Paint(Paint.ANTI_ALIAS_FLAG), pr = new Paint(Paint.ANTI_ALIAS_FLAG),
            tx = new Paint(Paint.ANTI_ALIAS_FLAG);

    GaugeView(Context c) {
        super(c);
        tr.setStyle(Paint.Style.STROKE);
        pr.setStyle(Paint.Style.STROKE);
        tr.setStrokeCap(Paint.Cap.ROUND);
        pr.setStrokeCap(Paint.Cap.ROUND);
        tr.setColor(0x26FFFFFF);
        pr.setColor(Ui.YEL);
        tx.setTextAlign(Paint.Align.CENTER);
        tx.setTypeface(Ui.bold(c));
    }

    void set(int f, int m, String s) { fps = f; max = Math.max(60, m); sub = s; invalidate(); }

    @Override protected void onDraw(Canvas cv) {
        Context c = getContext();
        float size = Math.min(getWidth(), getHeight());
        float pad = Ui.dp(c, 6), cx = getWidth() / 2f, cy = getHeight() / 2f;
        float sw = Ui.dp(c, 5);
        tr.setStrokeWidth(sw);
        pr.setStrokeWidth(sw);
        RectF r = new RectF(cx - size / 2 + pad, cy - size / 2 + pad, cx + size / 2 - pad, cy + size / 2 - pad);
        cv.drawArc(r, 135, 270, false, tr);
        if (fps >= 0) cv.drawArc(r, 135, 270f * Math.min(1f, fps / (float) max), false, pr);
        tx.setColor(Ui.MUTED);
        tx.setTextSize(Ui.dp(c, 9));
        cv.drawText("FPS", cx, cy - size * .16f, tx);
        tx.setColor(Ui.TXT);
        tx.setTextSize(Ui.dp(c, 20));
        cv.drawText(fps >= 0 ? String.valueOf(fps) : "--", cx, cy + size * .1f, tx);
        String t2 = fps < 0 ? "MENCARI" : sub;
        if (t2 != null) {
            tx.setColor(Ui.MUTED);
            tx.setTextSize(Ui.dp(c, 8));
            cv.drawText(t2, cx, cy + size * .34f, tx);
        }
    }
}

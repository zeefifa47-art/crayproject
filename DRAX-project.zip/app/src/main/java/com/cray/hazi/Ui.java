package com.cray.hazi;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import java.util.function.Consumer;
import java.util.function.IntConsumer;

final class Ui {
    static int BG = 0xFF0B0506, SURF = 0xFF170B0C, SURF2 = 0xFF231213, YEL = 0xFFFF2D2D, ACC2 = 0xFFB80F1E, ON_ACC = 0xFFFFFFFF;
    static final int TXT = 0xFFF6F4EA, MUTED = 0xFF9B9A8E, OK = 0xFF3DDC84, BAD = 0xFFFF5A5F, LINE = 0x26FFFFFF, DARK = 0xFF111111;
    static final String[] THEME_NAMES = {"Merah", "Kuning", "Hijau", "Biru", "Ungu"};
    // aksen, aksen2, teks di atas aksen, latar, permukaan, permukaan2
    private static final int[][] THEMES = {
            {0xFFFF2D2D, 0xFFB80F1E, 0xFFFFFFFF, 0xFF0B0506, 0xFF170B0C, 0xFF231213},
            {0xFFFFD60A, 0xFFFF9F0A, 0xFF111111, 0xFF0A0A0B, 0xFF151518, 0xFF1E1E23},
            {0xFF2DFF7A, 0xFF12A650, 0xFF111111, 0xFF050B08, 0xFF0C1712, 0xFF12231B},
            {0xFF3DA5FF, 0xFF1E5BFF, 0xFF111111, 0xFF05080D, 0xFF0B121B, 0xFF121C2A},
            {0xFFB45CFF, 0xFF6A1FD1, 0xFFFFFFFF, 0xFF09060D, 0xFF130C1B, 0xFF1C1228}};
    private static Typeface fb, fm, fo;

    /** Membaca tema dari pengaturan. Dipanggil di aplikasi dan di service supaya panel ikut berubah. */
    static void load(Context c) {
        int i = Math.max(0, Math.min(THEMES.length - 1, Prefs.i(c, Prefs.THEME, 0)));
        int[] t = THEMES[i];
        YEL = t[0]; ACC2 = t[1]; ON_ACC = t[2]; BG = t[3]; SURF = t[4]; SURF2 = t[5];
    }
    static int acc(int a) { return (a << 24) | (YEL & 0xFFFFFF); }
    static int alpha(int col, int a) { return (a << 24) | (col & 0xFFFFFF); }

    static int dp(Context c, float v) { return Math.round(v * c.getResources().getDisplayMetrics().density); }
    static Typeface bold(Context c) { if (fb == null) fb = Typeface.create("sans-serif", Typeface.BOLD); return fb; }
    static Typeface med(Context c) { if (fm == null) fm = Typeface.create("sans-serif-medium", Typeface.NORMAL); return fm; }
    static Typeface brand(Context c) { if (fo == null) fo = c.getResources().getFont(R.font.oxanium_bold); return fo; }

    static GradientDrawable rect(Context c, int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, r));
        return g;
    }
    static GradientDrawable stroke(Context c, int fill, int line, float r) {
        GradientDrawable g = rect(c, fill, r);
        g.setStroke(dp(c, 1), line);
        return g;
    }
    static GradientDrawable grad(Context c, int a, int b, float r) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{a, b});
        g.setCornerRadius(dp(c, r));
        return g;
    }

    static TextView tv(Context c, CharSequence s, float sp, int color, boolean b) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTypeface(b ? bold(c) : med(c));
        t.setIncludeFontPadding(false);
        return t;
    }

    static LinearLayout col(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }
    static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }
    static LinearLayout card(Context c) {
        LinearLayout l = col(c);
        int p = dp(c, 16);
        l.setPadding(p, p, p, p);
        l.setBackground(glass(c, 22));
        return l;
    }
    static LinearLayout.LayoutParams lp(Context c, int w, int h, float l, float t, float r, float b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(c, l), dp(c, t), dp(c, r), dp(c, b));
        return p;
    }
    static LinearLayout.LayoutParams wrapLp(Context c, float t) {
        return lp(c, -1, -2, 0, t, 0, 0);
    }

    static void press(View v) {
        v.setOnTouchListener((x, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) x.animate().scaleX(.96f).scaleY(.96f).alpha(.85f).setDuration(80).start();
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL)
                x.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(120).start();
            return false;
        });
    }

    static TextView button(Context c, String label, boolean primary, View.OnClickListener l) {
        TextView t = tv(c, label, 14, primary ? ON_ACC : TXT, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(c, 18), dp(c, 14), dp(c, 18), dp(c, 14));
        t.setBackground(primary ? gradBg(c, 16) : glass(c, 16));
        t.setOnClickListener(l);
        press(t);
        return t;
    }

    static TextView pill(Context c, String s, int fill, int color) {
        TextView t = tv(c, s, 11, color, true);
        t.setPadding(dp(c, 10), dp(c, 6), dp(c, 10), dp(c, 6));
        t.setBackground(rect(c, fill, 20));
        return t;
    }

    static View switchRow(Context c, String title, String sub, boolean on, Consumer<Boolean> cb) {
        LinearLayout row = row(c);
        row.setPadding(0, dp(c, 8), 0, dp(c, 8));
        LinearLayout txt = col(c);
        txt.addView(tv(c, title, 14, TXT, true));
        if (sub != null) {
            TextView s = tv(c, sub, 11, MUTED, false);
            s.setPadding(0, dp(c, 3), 0, 0);
            txt.addView(s);
        }
        row.addView(txt, new LinearLayout.LayoutParams(0, -2, 1f));
        Switch sw = new Switch(c);
        sw.setChecked(on);
        sw.setThumbTintList(new ColorStateList(new int[][]{{android.R.attr.state_checked}, {}}, new int[]{YEL, 0xFF8A8A80}));
        sw.setTrackTintList(new ColorStateList(new int[][]{{android.R.attr.state_checked}, {}}, new int[]{Ui.acc(0x66), 0x33FFFFFF}));
        sw.setOnCheckedChangeListener((b, v) -> cb.accept(v));
        row.addView(sw);
        return row;
    }

    static View slider(Context c, String label, int min, int max, int val, String suffix, IntConsumer cb) {
        LinearLayout l = col(c);
        l.setPadding(0, dp(c, 6), 0, dp(c, 6));
        LinearLayout head = row(c);
        TextView a = tv(c, label, 12, MUTED, true);
        TextView v = tv(c, val + suffix, 12, YEL, true);
        head.addView(a, new LinearLayout.LayoutParams(0, -2, 1f));
        head.addView(v);
        SeekBar sb = new SeekBar(c);
        sb.setMax(max - min);
        sb.setProgress(Math.max(0, Math.min(max - min, val - min)));
        sb.setProgressTintList(ColorStateList.valueOf(YEL));
        sb.setThumbTintList(ColorStateList.valueOf(YEL));
        sb.setProgressBackgroundTintList(ColorStateList.valueOf(0x33FFFFFF));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                v.setText((p + min) + suffix);
                if (user) cb.accept(p + min);
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        l.addView(head);
        l.addView(sb, new LinearLayout.LayoutParams(-1, -2));
        return l;
    }

    static View chips(Context c, String[] labels, int sel, IntConsumer cb) {
        HorizontalScrollView hs = new HorizontalScrollView(c);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(c);
        hs.addView(row);
        TextView[] ts = new TextView[labels.length];
        int[] cur = {sel};
        Runnable paint = () -> {
            for (int i = 0; i < ts.length; i++) {
                boolean on = i == cur[0];
                ts[i].setBackground(on ? gradBg(c, 14) : glass(c, 14));
                ts[i].setTextColor(on ? ON_ACC : TXT);
            }
        };
        for (int i = 0; i < labels.length; i++) {
            TextView t = tv(c, labels[i], 12, TXT, true);
            t.setPadding(dp(c, 14), dp(c, 9), dp(c, 14), dp(c, 9));
            final int idx = i;
            t.setOnClickListener(v -> { cur[0] = idx; paint.run(); cb.accept(idx); });
            press(t);
            ts[i] = t;
            row.addView(t, lp(c, -2, -2, 0, 0, 8, 0));
        }
        paint.run();
        return hs;
    }

    static TextView section(Context c, String s) {
        TextView t = tv(c, s.toUpperCase(), 10.5f, MUTED, true);
        t.setLetterSpacing(.12f);
        t.setPadding(0, dp(c, 12), 0, dp(c, 6));
        return t;
    }

    static TextView cap(Context c, String s) {
        TextView t = tv(c, s, 12, YEL, true);
        t.setLetterSpacing(.04f);
        return t;
    }

    /** Tombol bulat bergradien (utama) atau kaca (sekunder). */
    static TextView cbtn(Context c, String label, boolean primary, boolean small, View.OnClickListener l) {
        TextView t = tv(c, label, small ? 12.5f : 15, primary ? ON_ACC : TXT, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(c, small ? 16 : 20), dp(c, small ? 10 : 16), dp(c, small ? 16 : 20), dp(c, small ? 10 : 16));
        t.setBackground(primary ? gradBg(c, small ? 14 : 18) : glass(c, small ? 14 : 18));
        t.setOnClickListener(l);
        press(t);
        return t;
    }

    static GradientDrawable glass(Context c, float r) {
        GradientDrawable g = rect(c, 0x14FFFFFF, r);
        g.setStroke(dp(c, 1), 0x26FFFFFF);
        return g;
    }

    static GradientDrawable gradBg(Context c, float r) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{YEL, ACC2});
        g.setCornerRadius(dp(c, r));
        return g;
    }

    static TextView roundBtn(Context c, String label, int sizeDp, View.OnClickListener l) {
        TextView t = tv(c, label, 18, ON_ACC, true);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{YEL, ACC2});
        g.setShape(GradientDrawable.OVAL);
        t.setBackground(g);
        t.setLayoutParams(new LinearLayout.LayoutParams(dp(c, sizeDp), dp(c, sizeDp)));
        t.setOnClickListener(l);
        press(t);
        return t;
    }

    static ImageView appIcon(Context c, String pkg, float radiusDp) {
        ImageView iv = new ImageView(c);
        iv.setImageDrawable(Games.icon(c, pkg));
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setBackground(rect(c, SURF2, radiusDp));
        iv.setClipToOutline(true);
        return iv;
    }

    static int themeColor(int i) { return THEMES[Math.max(0, Math.min(THEMES.length - 1, i))][0]; }

    static int mix(int a, int b, float t) {
        int r = Math.round(((a >> 16) & 0xFF) * (1 - t) + ((b >> 16) & 0xFF) * t);
        int g = Math.round(((a >> 8) & 0xFF) * (1 - t) + ((b >> 8) & 0xFF) * t);
        int bl = Math.round((a & 0xFF) * (1 - t) + (b & 0xFF) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    /** Tab bentuk kapsul seperti di GZI Tools. */
    static View segment(Context c, String[] labels, int sel, IntConsumer cb) {
        LinearLayout row = new LinearLayout(c);
        row.setBackground(glass(c, 26));
        row.setPadding(dp(c, 4), dp(c, 4), dp(c, 4), dp(c, 4));
        TextView[] ts = new TextView[labels.length];
        int[] cur = {sel};
        Runnable paint = () -> {
            for (int i = 0; i < ts.length; i++) {
                boolean on = i == cur[0];
                ts[i].setBackground(on ? gradBg(c, 22) : null);
                ts[i].setTextColor(on ? ON_ACC : TXT);
            }
        };
        for (int i = 0; i < labels.length; i++) {
            TextView t = tv(c, labels[i], 12, TXT, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(c, 10), 0, dp(c, 10));
            final int idx = i;
            t.setOnClickListener(v -> { cur[0] = idx; paint.run(); cb.accept(idx); });
            ts[i] = t;
            row.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        paint.run();
        return row;
    }
}

package com.cray.hazi;

import android.content.Context;
import java.util.Locale;

/**
 * Sensitivitas sentuh X dan Y (0 = normal, 10 = tertinggi). Menjalankan draxsensid lewat Shizuku.
 * Berjalan hanya saat game dengan panel aktif sedang di depan; berhenti otomatis jika DRAX tertutup.
 */
final class SensiEngine {
    static final String BIN = "/data/local/tmp/drax_sensid";
    static final String CONF = "/data/local/tmp/drax_sensi.conf";
    static final String ST = "/data/local/tmp/drax_sensi.status";
    private static boolean pushed;

    static float factor(int level) { return 1f + 0.2f * Math.max(0, Math.min(10, level)); }

    /** Panggil dari thread Shell. Menyalakan, memperbarui, atau mematikan mesin sesuai setelan. */
    static void sync(Context c) {
        int sx = Prefs.i(c, Prefs.SENSI_X, 0), sy = Prefs.i(c, Prefs.SENSI_Y, 0);
        if (sx == 0 && sy == 0) { stop(); return; }
        if (!Shell.ready()) return;
        int zone = Prefs.i(c, Prefs.SENSI_ZONE, 0) == 0 ? 50 : 0;
        String conf = String.format(Locale.US, "%.2f %.2f %d 1", factor(sx), factor(sy), zone);
        boolean running = !Shell.run("pidof drax_sensid").trim().isEmpty();
        if (running) {
            Shell.run("echo '" + conf + "' > " + CONF);
            return;
        }
        if (!pushed) pushed = Shell.pushAsset(c, "draxsensid", BIN);
        if (!pushed) { fail(c, "komponen sensi tidak ditemukan"); return; }
        Shell.run("echo '" + conf + "' > " + CONF + "; rm -f " + ST
                + "; (setsid nohup " + BIN + " " + CONF + " </dev/null >/dev/null 2>&1 &)");
        try { Thread.sleep(900); } catch (InterruptedException ignored) { }
        String st = Shell.run("cat " + ST).trim();
        if (!st.startsWith("running")) fail(c, st.isEmpty() ? "tidak bisa dijalankan" : st);
    }

    private static void fail(Context c, String why) {
        stop();
        Prefs.put(c, Prefs.SENSI_X, 0);
        Prefs.put(c, Prefs.SENSI_Y, 0);
        Panels.toast(c, "Sensi tidak didukung di HP ini: " + why);
    }

    static void stop() {
        if (!Shell.ready()) return;
        Shell.run("pkill -f drax_sensid; rm -f " + CONF + " " + ST);
    }
}

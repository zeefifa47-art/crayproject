package com.cray.hazi;

import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Daftar game yang ditambahkan pengguna. Panel hanya aktif untuk game di daftar ini. */
final class Games {
    static final int MAX = 10;
    private static final String KEY = "games";

    static Set<String> set(Context c) {
        return new LinkedHashSet<>(Prefs.sp(c).getStringSet(KEY, new LinkedHashSet<>()));
    }
    static List<String> list(Context c) { return new ArrayList<>(set(c)); }
    static boolean has(Context c, String p) { return set(c).contains(p); }
    static boolean any(Context c) { return !set(c).isEmpty(); }
    static void add(Context c, String p) {
        Set<String> s = set(c);
        s.add(p);
        Prefs.sp(c).edit().putStringSet(KEY, s).apply();
    }
    static void remove(Context c, String p) {
        Set<String> s = set(c);
        s.remove(p);
        Prefs.sp(c).edit().putStringSet(KEY, s).apply();
    }
    static String label(Context c, String p) {
        try {
            PackageManager pm = c.getPackageManager();
            return pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString();
        } catch (Throwable t) { return p; }
    }
    static Drawable icon(Context c, String p) {
        try { return c.getPackageManager().getApplicationIcon(p); } catch (Throwable t) { return null; }
    }
}

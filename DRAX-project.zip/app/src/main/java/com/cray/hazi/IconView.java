package com.cray.hazi;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Ikon garis sederhana untuk kartu fitur. */
final class IconView extends View {
    static final int BOLT = 0, SLIDERS = 1, GRID = 2, TARGET = 3, LAYERS = 4;
    private final int kind;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    IconView(Context c, int kind) {
        super(c);
        this.kind = kind;
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
    }

    @Override protected void onDraw(Canvas cv) {
        float u = Math.min(getWidth(), getHeight()) / 24f;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2f * u);
        p.setColor(Ui.TXT);
        path.reset();
        switch (kind) {
            case BOLT:
                path.moveTo(13 * u, 2 * u);
                path.lineTo(5 * u, 13.5f * u);
                path.lineTo(11 * u, 13.5f * u);
                path.lineTo(10 * u, 22 * u);
                path.lineTo(19 * u, 10 * u);
                path.lineTo(13 * u, 10 * u);
                path.close();
                cv.drawPath(path, p);
                break;
            case SLIDERS: {
                float[] kx = {8, 16, 10};
                for (int i = 0; i < 3; i++) {
                    float y = (6 + 6 * i) * u;
                    p.setStyle(Paint.Style.STROKE);
                    p.setColor(Ui.TXT);
                    cv.drawLine(3 * u, y, 21 * u, y, p);
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(Ui.YEL);
                    cv.drawCircle(kx[i] * u, y, 2.6f * u, p);
                }
                break;
            }
            case GRID: {
                float[][] o = {{3, 3}, {14, 3}, {3, 14}, {14, 14}};
                for (float[] q : o) cv.drawRoundRect(new RectF(q[0] * u, q[1] * u, (q[0] + 7) * u, (q[1] + 7) * u), 1.6f * u, 1.6f * u, p);
                break;
            }
            case TARGET:
                cv.drawCircle(12 * u, 12 * u, 8 * u, p);
                cv.drawLine(12 * u, 1.5f * u, 12 * u, 6 * u, p);
                cv.drawLine(12 * u, 18 * u, 12 * u, 22.5f * u, p);
                cv.drawLine(1.5f * u, 12 * u, 6 * u, 12 * u, p);
                cv.drawLine(18 * u, 12 * u, 22.5f * u, 12 * u, p);
                break;
            default:
                for (int i = 0; i < 3; i++) {
                    float y = (6 + 5 * i) * u;
                    path.reset();
                    path.moveTo(12 * u, y - 4 * u);
                    path.lineTo(21 * u, y);
                    path.lineTo(12 * u, y + 4 * u);
                    path.lineTo(3 * u, y);
                    path.close();
                    cv.drawPath(path, p);
                }
        }
    }
}

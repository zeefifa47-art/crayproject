package com.cray.hazi;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;
import java.util.function.IntConsumer;

/** Slider tebal dengan gagang persegi membulat. */
final class SliderView extends View {
    private final int min, max;
    private int val;
    private final IntConsumer cb;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();

    SliderView(Context c, int min, int max, int val, IntConsumer cb) {
        super(c);
        this.min = min;
        this.max = Math.max(min + 1, max);
        this.val = Math.max(min, Math.min(this.max, val));
        this.cb = cb;
    }

    @Override protected void onMeasure(int w, int h) {
        setMeasuredDimension(View.getDefaultSize(0, w), Ui.dp(getContext(), 34));
    }

    @Override protected void onDraw(Canvas cv) {
        Context c = getContext();
        float w = getWidth(), h = getHeight(), side = Ui.dp(c, 10), th = Ui.dp(c, 12), cy = h / 2f;
        float frac = (val - min) / (float) (max - min);
        float x = side + frac * (w - 2 * side);
        p.setShader(null);
        p.setColor(Ui.mix(Ui.BG, 0xFFFFFFFF, .14f));
        r.set(side, cy - th / 2, w - side, cy + th / 2);
        cv.drawRoundRect(r, th / 2, th / 2, p);
        p.setShader(new LinearGradient(side, 0, w - side, 0, Ui.ACC2, Ui.YEL, Shader.TileMode.CLAMP));
        r.set(side, cy - th / 2, Math.max(side + th, x), cy + th / 2);
        cv.drawRoundRect(r, th / 2, th / 2, p);
        p.setShader(null);
        p.setColor(Ui.mix(Ui.YEL, 0xFFFFFFFF, .8f));
        float tw = Ui.dp(c, 14), tH = Ui.dp(c, 28);
        r.set(x - tw / 2, cy - tH / 2, x + tw / 2, cy + tH / 2);
        cv.drawRoundRect(r, Ui.dp(c, 6), Ui.dp(c, 6), p);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN && getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
        if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_MOVE) {
            float side = Ui.dp(getContext(), 10);
            float frac = Math.max(0f, Math.min(1f, (e.getX() - side) / Math.max(1f, getWidth() - 2 * side)));
            int nv = min + Math.round(frac * (max - min));
            if (nv != val) {
                val = nv;
                invalidate();
                if (cb != null) cb.accept(val);
            }
        }
        return true;
    }
}

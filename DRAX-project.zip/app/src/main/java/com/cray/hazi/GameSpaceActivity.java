package com.cray.hazi;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Halaman Game Space: fitur khusus satu game. Setelan panel diatur langsung di panel dalam game. */
public class GameSpaceActivity extends Activity {
    private String pkg;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.load(this);
        pkg = getIntent().getStringExtra("pkg");
        if (pkg == null || !Games.has(this, pkg)) { finish(); return; }
        FrameLayout host = new FrameLayout(this);
        host.setFitsSystemWindows(true);
        host.setBackground(new GridDrawable(this));
        setContentView(host);

        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout l = Ui.col(this);
        int p = Ui.dp(this, 16);
        l.setPadding(p, Ui.dp(this, 14), p, Ui.dp(this, 24));
        sv.addView(l);
        host.addView(sv, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout head = Ui.row(this);
        head.addView(Ui.cbtn(this, "<", false, true, v -> finish()));
        LinearLayout tc = Ui.col(this);
        tc.addView(Ui.cap(this, "DRAX GAME SPACE"));
        tc.addView(Ui.tv(this, Games.label(this, pkg), 20, Ui.TXT, true), Ui.wrapLp(this, 4));
        head.addView(tc, Ui.lp(this, 0, -2, 14, 0, 0, 0));
        ((LinearLayout.LayoutParams) tc.getLayoutParams()).weight = 1f;
        l.addView(head);

        // Banner game
        LinearLayout card = Ui.row(this);
        card.setPadding(Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 16));
        card.setBackground(new CyberDrawable(this, Ui.SURF2, Ui.alpha(Ui.YEL, 0x55), Ui.acc(0xAA), 1.5f, 14, true));
        LinearLayout left = Ui.col(this);
        left.addView(Ui.cap(this, "GAME"));
        left.addView(Ui.tv(this, Games.label(this, pkg), 20, Ui.TXT, true), Ui.wrapLp(this, 4));
        left.addView(Ui.tv(this, pkg, 10, Ui.MUTED, false), Ui.wrapLp(this, 2));
        left.addView(Ui.cbtn(this, "Main", true, true, v -> HomePage.launch(this, pkg)), Ui.wrapLp(this, 14));
        card.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));
        ImageView iv = new ImageView(this);
        iv.setImageDrawable(Games.icon(this, pkg));
        iv.setPadding(Ui.dp(this, 3), Ui.dp(this, 3), Ui.dp(this, 3), Ui.dp(this, 3));
        iv.setBackground(new CyberDrawable(this, 0x33000000, 0x33000000, Ui.YEL, 1.5f, 8, false));
        card.addView(iv, new LinearLayout.LayoutParams(Ui.dp(this, 66), Ui.dp(this, 66)));
        l.addView(card, Ui.wrapLp(this, 16));

        // Pixel Lab
        boolean ok = Build.VERSION.SDK_INT >= 35;
        LinearLayout px = Ui.col(this);
        px.setPadding(Ui.dp(this, 18), Ui.dp(this, 16), Ui.dp(this, 18), Ui.dp(this, 16));
        px.setBackground(new CyberDrawable(this, Ui.SURF, Ui.SURF, Ui.acc(0x88), 1.5f, 14, false));
        LinearLayout ph = Ui.row(this);
        ph.addView(Ui.tv(this, "PIXEL LAB", 15, Ui.TXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        ph.addView(Ui.pill(this, ok ? "ANDROID 15+" : "TERKUNCI", ok ? Ui.acc(0x33) : 0x33FF5A5F, ok ? Ui.YEL : Ui.BAD));
        px.addView(ph);
        TextView pd = Ui.tv(this, "Buat tekstur game jadi kotak-kotak ala retro. Ada gambar sampel sebelum dan sesudah.", 12.5f, Ui.MUTED, false);
        pd.setLineSpacing(0, 1.15f);
        px.addView(pd, Ui.wrapLp(this, 8));
        px.addView(Ui.cbtn(this, ok ? "Buka Pixel Lab" : "Butuh Android 15+", ok, false, v -> {
            if (Build.VERSION.SDK_INT >= 35) startActivity(new Intent(this, PixelLabActivity.class).putExtra("pkg", pkg));
            else Panels.toast(this, "Pixel Lab hanya untuk Android 15 ke atas");
        }), Ui.wrapLp(this, 12));
        l.addView(px, Ui.wrapLp(this, 12));

        // Info panel
        LinearLayout pn = Ui.col(this);
        pn.setPadding(Ui.dp(this, 18), Ui.dp(this, 16), Ui.dp(this, 18), Ui.dp(this, 16));
        pn.setBackground(new CyberDrawable(this, Ui.SURF, Ui.SURF, Ui.LINE, 1, 12, false));
        pn.addView(Ui.cap(this, "PANEL GAME"));
        TextView pi = Ui.tv(this, "Crosshair, sensitivity, kecerahan, suara, dan refresh rate diatur langsung dari panel. Buka game lalu geser tab Pengaturan Cepat dari tengah atas layar.", 12.5f, Ui.MUTED, false);
        pi.setLineSpacing(0, 1.2f);
        pn.addView(pi, Ui.wrapLp(this, 6));
        l.addView(pn, Ui.wrapLp(this, 12));
    }
}

package com.cray.hazi;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Game Space: setelan sebelum main (panel, posisi panel, Pixel Lab). Lalu tekan Launch. */
public class GameSpaceActivity extends Activity {
    private String pkg;
    private FrameLayout host;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.load(this);
        pkg = getIntent().getStringExtra("pkg");
        if (pkg == null || !Games.has(this, pkg)) { finish(); return; }
        host = new FrameLayout(this);
        host.setFitsSystemWindows(true);
        host.setBackground(new GridDrawable(this));
        setContentView(host);
    }

    @Override protected void onResume() {
        super.onResume();
        if (host != null && pkg != null) build();
    }

    private TextView heading(String s) {
        TextView t = Ui.tv(this, s, 16, Ui.TXT, true);
        return t;
    }

    private View divider() {
        View d = new View(this);
        d.setBackgroundColor(0x1FFFFFFF);
        return d;
    }

    private void build() {
        host.removeAllViews();
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout l = Ui.col(this);
        int p = Ui.dp(this, 20);
        l.setPadding(p, Ui.dp(this, 14), p, Ui.dp(this, 28));
        sv.addView(l);
        host.addView(sv, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout head = Ui.row(this);
        TextView back = Ui.tv(this, "‹", 26, Ui.TXT, true);
        back.setGravity(android.view.Gravity.CENTER);
        back.setBackground(Ui.glass(this, 22));
        back.setOnClickListener(v -> finish());
        Ui.press(back);
        head.addView(back, new LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44)));
        LinearLayout tc = Ui.col(this);
        tc.addView(Ui.tv(this, "Game Space", 20, Ui.TXT, true));
        tc.addView(Ui.tv(this, "Atur dulu, lalu Launch", 12, Ui.MUTED, false), Ui.wrapLp(this, 2));
        head.addView(tc, Ui.lp(this, 0, -2, 14, 0, 0, 0));
        ((LinearLayout.LayoutParams) tc.getLayoutParams()).weight = 1f;
        l.addView(head);

        // Kartu game
        LinearLayout gc = Ui.card(this);
        LinearLayout gr = Ui.row(this);
        gr.addView(Ui.appIcon(this, pkg, 20), new LinearLayout.LayoutParams(Ui.dp(this, 72), Ui.dp(this, 72)));
        LinearLayout gt = Ui.col(this);
        gt.addView(Ui.tv(this, Games.label(this, pkg), 20, Ui.TXT, true));
        gt.addView(Ui.tv(this, pkg, 11, Ui.MUTED, false), Ui.wrapLp(this, 4));
        gr.addView(gt, Ui.lp(this, 0, -2, 16, 0, 0, 0));
        ((LinearLayout.LayoutParams) gt.getLayoutParams()).weight = 1f;
        gc.addView(gr);
        gc.addView(Ui.cbtn(this, "Launch", true, false, v -> HomePage.launch(this, pkg)), Ui.wrapLp(this, 16));
        l.addView(gc, Ui.wrapLp(this, 18));

        // Panel
        l.addView(heading("Panel game"), Ui.wrapLp(this, 24));
        LinearLayout pn = Ui.card(this);
        pn.addView(Ui.switchRow(this, "Aktifkan panel", "Tab Pengaturan Cepat muncul saat game ini dibuka",
                Prefs.b(this, "panel_" + pkg, false), v -> Prefs.put(this, "panel_" + pkg, v)));
        TextView pd = Ui.tv(this, "Geser batang di tepi kiri layar (atau ketuk) untuk membuka panel. Ketuk ikon untuk membuka pengaturannya, ketuk lagi untuk menutup.", 12, Ui.MUTED, false);
        pd.setLineSpacing(0, 1.2f);
        pn.addView(pd, Ui.wrapLp(this, 12));
        l.addView(pn, Ui.wrapLp(this, 10));

        // Pixel Lab
        l.addView(heading("Pixel Lab"), Ui.wrapLp(this, 24));
        boolean ok = Build.VERSION.SDK_INT >= 35;
        boolean on = ok && Prefs.b(this, Prefs.PX_APPLIED, false) && Prefs.b(this, "px_" + pkg, false);
        LinearLayout px = Ui.card(this);
        LinearLayout ph = Ui.row(this);
        ph.addView(Ui.tv(this, "Tekstur ringan", 15, Ui.TXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        ph.addView(Ui.pill(this, !ok ? "Terkunci" : on ? "Aktif" : "Mati", !ok ? 0x33FF5A5F : on ? Ui.acc(0x33) : 0x1FFFFFFF,
                !ok ? Ui.BAD : on ? Ui.YEL : Ui.MUTED));
        px.addView(ph);
        TextView xd = Ui.tv(this, !ok ? "Pixel Lab hanya untuk Android 15 ke atas."
                : "Setelan tersimpan otomatis. Kalau sudah aktif dan belum direset, tekstur langsung berubah saat game dibuka lewat DRAX.", 12, Ui.MUTED, false);
        xd.setLineSpacing(0, 1.2f);
        px.addView(xd, Ui.wrapLp(this, 8));
        px.addView(Ui.cbtn(this, ok ? "Atur Pixel Lab" : "Butuh Android 15+", false, false, v -> {
            if (Build.VERSION.SDK_INT >= 35) startActivity(new Intent(this, PixelLabActivity.class).putExtra("pkg", pkg));
            else Panels.toast(this, "Pixel Lab hanya untuk Android 15 ke atas");
        }), Ui.wrapLp(this, 14));
        l.addView(px, Ui.wrapLp(this, 10));
    }
}

package com.cray.hazi;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Game Space: setelan sebelum main (panel dan Pixel Lab). Lalu tekan Launch. */
public class GameSpaceActivity extends Activity {
    private String pkg;
    private FrameLayout host;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.load(this);
        pkg = getIntent().getStringExtra("pkg");
        if (pkg == null || !Games.has(this, pkg)) { finish(); return; }
        host = new FrameLayout(this);
        host.setFitsSystemWindows(true);
        host.setBackground(new GridDrawable(this));
        setContentView(host);
    }

    @Override protected void onResume() {
        super.onResume();
        if (host != null && pkg != null) build();
    }

    private void build() {
        host.removeAllViews();
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout l = Ui.col(this);
        int p = Ui.dp(this, 18);
        l.setPadding(p, Ui.dp(this, 16), p, Ui.dp(this, 28));
        sv.addView(l);
        host.addView(sv, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout head = Ui.row(this);
        TextView back = Ui.tv(this, "‹", 26, Ui.TXT, true);
        back.setGravity(Gravity.CENTER);
        back.setBackground(Ui.glass(this, 22));
        back.setOnClickListener(v -> finish());
        Ui.press(back);
        head.addView(back, new LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44)));
        LinearLayout tc = Ui.col(this);
        tc.addView(Ui.tv(this, Games.label(this, pkg), 24, Ui.TXT, true));
        tc.addView(Ui.tv(this, "Game Space · atur dulu, lalu Launch", 12, Ui.MUTED, false), Ui.wrapLp(this, 2));
        head.addView(tc, Ui.lp(this, 0, -2, 14, 0, 0, 0));
        ((LinearLayout.LayoutParams) tc.getLayoutParams()).weight = 1f;
        l.addView(head);

        // Panel game
        ToggleView pt = new ToggleView(this);
        pt.set(Prefs.b(this, "panel_" + pkg, false));
        pt.setOnChange(v -> Prefs.put(this, "panel_" + pkg, v));
        l.addView(Ui.feature(this, new IconView(this, IconView.SLIDERS), 26, "Panel game",
                "Batang di tepi kiri layar. Geser atau ketuk untuk membuka crosshair, sensi, kecerahan, suara, dan Hz.", pt), Ui.wrapLp(this, 20));

        // Pixel Lab
        boolean ok = Build.VERSION.SDK_INT >= 35;
        boolean on = ok && Prefs.b(this, Prefs.PX_APPLIED, false) && Prefs.b(this, "px_" + pkg, false);
        TextView pxBtn = Ui.lightBtn(this, ok ? "Atur Pixel Lab" : "Butuh Android 15+", v -> {
            if (Build.VERSION.SDK_INT >= 35) startActivity(new Intent(this, PixelLabActivity.class).putExtra("pkg", pkg));
            else Panels.toast(this, "Pixel Lab hanya untuk Android 15 ke atas");
        });
        LinearLayout px = Ui.feature(this, new IconView(this, IconView.GRID), 26, "Pixel Lab",
                !ok ? "Hanya untuk Android 15 ke atas."
                        : "Tekstur kotak-kotak ala retro. " + (on ? "Sedang aktif." : "Sedang mati.")
                        + " Kalau aktif dan belum direset, langsung berlaku saat Launch tanpa simpan lagi.", null);
        px.addView(pxBtn, Ui.lp(this, -2, -2, 0, 14, 0, 0));
        l.addView(px, Ui.wrapLp(this, 12));

        l.addView(Ui.cbtn(this, "Launch", true, false, v -> HomePage.launch(this, pkg)), Ui.wrapLp(this, 22));
    }
}

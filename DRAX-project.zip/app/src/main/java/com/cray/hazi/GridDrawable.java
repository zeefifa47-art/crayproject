package com.cray.hazi;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/** Latar gelap dengan pendar warna tema di pojok. (Nama lama dipertahankan.) */
final class GridDrawable extends Drawable {
    private final Paint base = new Paint(), g1 = new Paint(), g2 = new Paint();

    GridDrawable(Context c) { base.setColor(Ui.BG); }

    @Override protected void onBoundsChange(Rect b) {
        float w = b.width(), h = b.height();
        g1.setShader(new RadialGradient(w * 0.95f, h * 0.02f, Math.max(w, h) * 0.75f, Ui.alpha(Ui.YEL, 0x55), 0x00000000, Shader.TileMode.CLAMP));
        g2.setShader(new RadialGradient(w * 0.0f, h * 0.98f, Math.max(w, h) * 0.65f, Ui.alpha(Ui.ACC2, 0x44), 0x00000000, Shader.TileMode.CLAMP));
    }

    @Override public void draw(Canvas cv) {
        Rect b = getBounds();
        cv.drawRect(b, base);
        cv.drawRect(b, g1);
        cv.drawRect(b, g2);
    }

    @Override public void setAlpha(int a) { }
    @Override public void setColorFilter(ColorFilter f) { }
    @Override public int getOpacity() { return PixelFormat.OPAQUE; }
}

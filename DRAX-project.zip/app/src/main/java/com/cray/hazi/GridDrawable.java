package com.cray.hazi;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/** Latar gelap dengan semburat warna tema dan garis kisi tipis. */
final class GridDrawable extends Drawable {
    private final Paint bg = new Paint(), grid = new Paint();
    private final float step;

    GridDrawable(Context c) {
        step = Ui.dp(c, 36);
        grid.setColor(Ui.acc(0x14));
        grid.setStrokeWidth(Math.max(1f, Ui.dp(c, 0.6f)));
    }

    @Override protected void onBoundsChange(Rect b) {
        int glow = Ui.alpha(Ui.YEL, 0x26);
        int top = Ui.BG;
        int bottom = ((0xFF << 24)
                | ((((top >> 16) & 0xFF) * 3 / 4 + ((glow >> 16) & 0xFF) / 4) << 16)
                | ((((top >> 8) & 0xFF) * 3 / 4 + ((glow >> 8) & 0xFF) / 4) << 8)
                | (((top & 0xFF) * 3 / 4 + (glow & 0xFF) / 4)));
        bg.setShader(new LinearGradient(0, b.top, 0, b.bottom, bottom, top, Shader.TileMode.CLAMP));
    }

    @Override public void draw(Canvas cv) {
        Rect b = getBounds();
        cv.drawRect(b, bg);
        for (float x = b.left; x < b.right; x += step) cv.drawLine(x, b.top, x, b.bottom, grid);
        for (float y = b.top; y < b.bottom; y += step) cv.drawLine(b.left, y, b.right, y, grid);
    }

    @Override public void setAlpha(int a) { }
    @Override public void setColorFilter(ColorFilter f) { }
    @Override public int getOpacity() { return PixelFormat.OPAQUE; }
}

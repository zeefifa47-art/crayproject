package com.cray.hazi;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/** Latar gelap dengan semburat warna tema yang halus dari kiri atas. (Nama lama dipertahankan.) */
final class GridDrawable extends Drawable {
    private final Paint p = new Paint();

    GridDrawable(Context c) { }

    @Override protected void onBoundsChange(Rect b) {
        p.setShader(new LinearGradient(b.left, b.top, b.right, b.bottom,
                Ui.mix(Ui.BG, Ui.YEL, .13f), Ui.BG, Shader.TileMode.CLAMP));
    }

    @Override public void draw(Canvas cv) { cv.drawRect(getBounds(), p); }

    @Override public void setAlpha(int a) { }
    @Override public void setColorFilter(ColorFilter f) { }
    @Override public int getOpacity() { return PixelFormat.OPAQUE; }
}

package com.cray.hazi;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Tombol heksagon bergaya HUD, ikon digambar sendiri. */
final class HexButton extends View {
    static final int AUDIO = 0, SUN = 1, CROSS = 2, SENSI = 3, TEXT = 4, MAKRO = 5;
    private final int kind;
    private final String num, label;
    boolean selected, locked;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), line = new Paint(Paint.ANTI_ALIAS_FLAG),
            ic = new Paint(Paint.ANTI_ALIAS_FLAG), tx = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    HexButton(Context c, int kind, String num, String label) {
        super(c);
        this.kind = kind;
        this.num = num;
        this.label = label;
        fill.setStyle(Paint.Style.FILL);
        line.setStyle(Paint.Style.STROKE);
        ic.setStyle(Paint.Style.STROKE);
        ic.setStrokeCap(Paint.Cap.ROUND);
        tx.setTextAlign(Paint.Align.CENTER);
        tx.setTypeface(Ui.bold(c));
        setClickable(true);
    }

    void set(boolean sel, boolean lock) { selected = sel; locked = lock; invalidate(); }

    @Override protected void onDraw(Canvas cv) {
        Context c = getContext();
        float w = getWidth(), labelH = label.isEmpty() ? 0 : Ui.dp(c, 14);
        float hh = getHeight() - labelH;
        float rr = Math.min(w, hh) / 2f - Ui.dp(c, 2);
        float cx = w / 2f, cy = hh / 2f, h2 = rr * 1.8f;
        fill.setColor(selected ? Ui.acc(0x55) : 0x14FFFFFF);
        line.setColor(selected ? Ui.YEL : (locked ? 0x22FFFFFF : 0x44FFFFFF));
        line.setStrokeWidth(Ui.dp(c, selected ? 2 : 1));
        cv.drawCircle(cx, cy, rr, fill);
        cv.drawCircle(cx, cy, rr, line);

        float u = h2 * 0.2f;
        ic.setColor(locked ? 0x66F6F4EA : (selected ? Ui.YEL : Ui.TXT));
        ic.setStrokeWidth(Math.max(Ui.dp(c, 1.6f), u * .22f));
        ic.setStyle(Paint.Style.STROKE);
        if (locked) {
            RectF b = new RectF(cx - u * .8f, cy - u * .1f, cx + u * .8f, cy + u * .9f);
            ic.setStyle(Paint.Style.FILL);
            cv.drawRoundRect(b, u * .2f, u * .2f, ic);
            ic.setStyle(Paint.Style.STROKE);
            cv.drawArc(new RectF(cx - u * .55f, cy - u * 1.0f, cx + u * .55f, cy + u * .3f), 180, 180, false, ic);
        } else {
            switch (kind) {
                case AUDIO:
                    ic.setStyle(Paint.Style.FILL);
                    Path s = new Path();
                    s.moveTo(cx - u * 1.1f, cy - u * .4f);
                    s.lineTo(cx - u * .5f, cy - u * .4f);
                    s.lineTo(cx + u * .2f, cy - u * 1.0f);
                    s.lineTo(cx + u * .2f, cy + u * 1.0f);
                    s.lineTo(cx - u * .5f, cy + u * .4f);
                    s.lineTo(cx - u * 1.1f, cy + u * .4f);
                    s.close();
                    cv.drawPath(s, ic);
                    ic.setStyle(Paint.Style.STROKE);
                    cv.drawArc(new RectF(cx - u * .3f, cy - u * .6f, cx + u * .7f, cy + u * .6f), -50, 100, false, ic);
                    cv.drawArc(new RectF(cx - u * .6f, cy - u * 1.0f, cx + u * 1.2f, cy + u * 1.0f), -50, 100, false, ic);
                    break;
                case SUN:
                    cv.drawCircle(cx, cy, u * .5f, ic);
                    for (int k = 0; k < 8; k++) {
                        double a = Math.PI / 4 * k;
                        cv.drawLine(cx + (float) Math.cos(a) * u * .85f, cy + (float) Math.sin(a) * u * .85f,
                                cx + (float) Math.cos(a) * u * 1.2f, cy + (float) Math.sin(a) * u * 1.2f, ic);
                    }
                    break;
                case CROSS:
                    cv.drawCircle(cx, cy, u * .8f, ic);
                    cv.drawLine(cx - u * 1.2f, cy, cx + u * 1.2f, cy, ic);
                    cv.drawLine(cx, cy - u * 1.2f, cx, cy + u * 1.2f, ic);
                    break;
                case SENSI:
                    cv.drawCircle(cx, cy, u * 1.1f, ic);
                    cv.drawCircle(cx, cy, u * .6f, ic);
                    ic.setStyle(Paint.Style.FILL);
                    cv.drawCircle(cx, cy, u * .2f, ic);
                    break;
                case MAKRO:
                    Path bolt = new Path();
                    bolt.moveTo(cx + u * 0.15f, cy - u * 1.1f);
                    bolt.lineTo(cx - u * 0.65f, cy + u * 0.15f);
                    bolt.lineTo(cx - u * 0.05f, cy + u * 0.15f);
                    bolt.lineTo(cx - u * 0.15f, cy + u * 1.1f);
                    bolt.lineTo(cx + u * 0.65f, cy - u * 0.15f);
                    bolt.lineTo(cx + u * 0.05f, cy - u * 0.15f);
                    bolt.close();
                    ic.setStyle(Paint.Style.FILL);
                    cv.drawPath(bolt, ic);
                    break;
                default:
                    tx.setColor(selected ? Ui.YEL : Ui.TXT);
                    tx.setTextSize(Ui.dp(c, 15));
                    cv.drawText(num, cx, cy + Ui.dp(c, 5), tx);
            }
        }
        if (label.isEmpty()) return;
        tx.setColor(locked ? 0x66F6F4EA : (selected ? Ui.YEL : Ui.MUTED));
        tx.setTextSize(Ui.dp(c, 8.5f));
        cv.drawText(label, cx, getHeight() - Ui.dp(c, 3), tx);
    }
}

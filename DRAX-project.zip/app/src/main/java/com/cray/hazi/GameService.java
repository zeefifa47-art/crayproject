package com.cray.hazi;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.ContextThemeWrapper;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Memantau game yang ditambahkan. Saat game terbuka dan panelnya diaktifkan, muncul tab kecil "‹"
 * di tepi kanan layar. Geser atau ketuk untuk membuka panel; ketuk ikon sekali untuk membuka
 * pengaturannya, ketuk lagi untuk menutup.
 */
public class GameService extends Service {
    private static final String CH_ID = "cray_game";
    private static final long RESET_MS = 5 * 60 * 1000L;
    private static final Pattern PKG = Pattern.compile("u\\d+\\s+([\\w.]+)/");
    private static final int[] HZ = {60, 90, 120, 144};

    private final Handler main = new Handler(Looper.getMainLooper());
    private Context ctx;
    private WindowManager wm;
    private boolean alive, busy, inGame, expanded, perfBusy, panelActive;
    private String curPkg = "";
    private LinearLayout root, drawer, sheet;
    private HandleView handle;
    private ScrollView body;
    private CrosshairView cross;
    private WindowManager.LayoutParams rootLp;
    private final HexButton[] tabBtns = new HexButton[5];
    private final TextView[] hzTv = new TextView[4];
    private TextView fpsTxt, cpuTxt;
    private int tab = -1, panelW, contentH, lastFps = -1, desiredHz = -1;
    private long[] lastCpu;
    private SharedPreferences.OnSharedPreferenceChangeListener prefL;

    // ---------- Makro: 1 tombol trigger + daftar target tap (tiap target punya jeda ms sendiri) ----------
    private LinearLayout macroList;
    private View macroBtn, macroMarker;
    private WindowManager.LayoutParams macroBtnLp, macroMarkerLp;
    private final List<int[]> macroTargets = new ArrayList<>(); // tiap item: [x, y, ms]
    private int macroEditIdx = -1;

    static void start(Context c) {
        try { c.startForegroundService(new Intent(c, GameService.class)); } catch (Throwable ignored) { }
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        Ui.load(this);
        Context base = this;
        if (Build.VERSION.SDK_INT >= 30) {
            try { base = createWindowContext(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, null); } catch (Throwable ignored) { }
        }
        wm = (WindowManager) base.getSystemService(Context.WINDOW_SERVICE);
        ctx = new ContextThemeWrapper(base, R.style.Theme_Cray);
        prefL = (sp, key) -> {
            if (key == null) return;
            if (key.startsWith("ch_") && panelActive) main.post(this::syncCrosshair);
            else if (key.equals(Prefs.THEME)) main.post(() -> { Ui.load(this); relayout(); });
            else if (key.startsWith("panel_")) main.post(() -> updateState(inGame));
            else if (key.startsWith("sensi_")) main.post(this::syncSensi);
        };
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(prefL);
    }

    @Override public int onStartCommand(Intent i, int flags, int id) {
        startFg();
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY; }
        if (!alive) { alive = true; main.post(tick); }
        return START_STICKY;
    }

    private void startFg() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CH_ID, "DRAX Mode Game", NotificationManager.IMPORTANCE_LOW));
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CH_ID)
                .setSmallIcon(R.drawable.ic_notif).setContentTitle("DRAX aktif")
                .setContentText("Panel muncul otomatis saat game dibuka").setContentIntent(pi).setOngoing(true).build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1, n);
    }

    // ---------- Deteksi game ----------

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!alive) return;
            if (!busy) {
                busy = true;
                Shell.async(() -> {
                    final boolean ready = Shell.ready();
                    final String out = ready ? Shell.run("dumpsys activity activities | grep -E 'topResumedActivity|ResumedActivity' | head -n 3; [ -f " + SensiEngine.CONF + " ] && touch " + SensiEngine.CONF) : "";
                    main.post(() -> { busy = false; onTop(out, ready); });
                });
            }
            if (inGame && desiredHz > 0) {
                int cur;
                try { cur = Math.round(display().getRefreshRate()); } catch (Throwable ignored) { cur = -1; }
                if (cur == desiredHz) desiredHz = -1;
                else pushModePref(desiredHz); // beberapa game/ROM suka balikin mode-nya sendiri, terus ditekan
            }
            main.postDelayed(this, 2000);
        }
    };

    /** Minta mode layar yang cocok lewat jendela overlay (lokal, tanpa shell). Boleh dipanggil berkali-kali. */
    private void pushModePref(int hz) {
        try {
            Display d = display();
            Display.Mode cm = d.getMode();
            Display.Mode best = null; int bestDiff = Integer.MAX_VALUE;
            for (Display.Mode m : d.getSupportedModes()) {
                if (m.getPhysicalWidth() != cm.getPhysicalWidth() || m.getPhysicalHeight() != cm.getPhysicalHeight()) continue;
                int diff = Math.abs(Math.round(m.getRefreshRate()) - hz);
                if (diff < bestDiff) { bestDiff = diff; best = m; }
            }
            if (best == null) return;
            if (root != null && rootLp != null && rootLp.preferredDisplayModeId != best.getModeId()) {
                rootLp.preferredDisplayModeId = best.getModeId();
                rootLp.preferredRefreshRate = best.getRefreshRate();
                try { wm.updateViewLayout(root, rootLp); } catch (Throwable ignored) { }
            }
            if (cross != null) {
                WindowManager.LayoutParams lp = (WindowManager.LayoutParams) cross.getLayoutParams();
                if (lp != null && lp.preferredDisplayModeId != best.getModeId()) {
                    lp.preferredDisplayModeId = best.getModeId();
                    lp.preferredRefreshRate = best.getRefreshRate();
                    try { wm.updateViewLayout(cross, lp); } catch (Throwable ignored) { }
                }
            }
        } catch (Throwable ignored) { }
    }

    private void onTop(String out, boolean ready) {
        boolean now = false;
        if (ready) {
            Matcher m = PKG.matcher(out);
            if (m.find() && Games.has(this, m.group(1))) { now = true; curPkg = m.group(1); }
        }
        updateState(now);
        long t = System.currentTimeMillis();
        if (inGame) {
            Prefs.put(this, Prefs.LEFT_AT, 0L);
        } else if (Resetter.anyApplied(this)) {
            long left = Prefs.l(this, Prefs.LEFT_AT, 0L);
            if (left == 0) Prefs.put(this, Prefs.LEFT_AT, t);
            else if (t - left >= RESET_MS) {
                Prefs.put(this, Prefs.LEFT_AT, 0L);
                Shell.async(() -> Resetter.resetAll(this));
                Panels.toast(this, "DRAX: semua pengaturan direset");
            }
        } else {
            Prefs.put(this, Prefs.LEFT_AT, 0L);
        }
    }

    /** Panel hanya muncul saat game di depan DAN panelnya diaktifkan untuk game itu. */
    private void updateState(boolean now) {
        inGame = now;
        boolean pnl = now && Prefs.b(this, "panel_" + curPkg, false);
        if (pnl != panelActive) {
            panelActive = pnl;
            syncSensi();
            if (panelActive) { showHandle(); syncCrosshair(); }
            else leave();
        }
    }

    private final Runnable sensiRun = () -> {
        final boolean on = panelActive;
        Shell.async(() -> { if (on) SensiEngine.sync(this); else SensiEngine.stop(); });
    };

    private void syncSensi() {
        main.removeCallbacks(sensiRun);
        main.postDelayed(sensiRun, 300);
    }

    private void relayout() {
        if (!panelActive) return;
        boolean wasOpen = expanded;
        hideAll();
        showHandle();
        if (wasOpen) openPanel();
    }

    private void leave() {
        hideAll();
        if (cross != null) { try { wm.removeView(cross); } catch (Throwable ignored) { } cross = null; }
    }

    // ---------- Ukuran layar ----------

    private int[] cutout() {
        try {
            WindowInsets wi = wm.getCurrentWindowMetrics().getWindowInsets();
            Insets in = wi.getInsets(WindowInsets.Type.displayCutout());
            return new int[]{in.left, in.top, in.right, in.bottom};
        } catch (Throwable t) {
            return new int[4];
        }
    }

    private Rect screen() {
        try { return wm.getCurrentWindowMetrics().getBounds(); } catch (Throwable t) { return new Rect(0, 0, 1600, 720); }
    }

    private void applyCutoutMode(WindowManager.LayoutParams lp) {
        if (Build.VERSION.SDK_INT >= 30) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        else if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
    }

    // ---------- Tab tepi kanan dan panel geser ----------

    /** Tab di tepi kiri, agak di bawah atas layar (menjauhi punch-hole). Saat terbuka, panel di kiri atas. */
    private void place(boolean open) {
        int[] cut = cutout();
        Rect sc = screen();
        rootLp.gravity = Gravity.TOP | Gravity.START;
        // x selalu 0 (mentok kiri layar): dulu pakai cut[0] (inset cutout kiri), tapi itu bikin pegangan
        // ketarik dikit dari tepi layar jadi bentuk setengah-kapsulnya (dipotong sengaja di HandleView)
        // kelihatan "kepotong"/aneh karena nggak persis mentok. Pegangan ada di tengah layar (bukan di
        // area notch/punch-hole atas), jadi inset cutout kiri gak relevan di sini.
        rootLp.x = 0;
        // Panel kebuka dulu pakai cut[1] (inset cutout atas) + 10dp sebagai jarak dari atas, tapi itu
        // malah bikin kelihatan "pas banget di kamera" karena nempel ke sisi kiri area cutout. Panel ada
        // di tepi kiri (x=0) sedangkan kamera biasanya gak sampai ke ujung kiri layar, jadi aman digeser
        // lebih ke atas, mepet ke tepi atas layar (bukan ngikut inset cutout lagi).
        // Ditaruh di tengah-kiri (bukan 0.16 yang kena area minimap game), supaya tidak ketimpa minimap.
        rootLp.y = open ? Ui.dp(ctx, 4) : Math.max(cut[1] + Ui.dp(ctx, 8), (int) (sc.height() * 0.42f));
    }

    private void showHandle() {
        if (root != null) return;
        root = Ui.row(ctx);
        root.setGravity(Gravity.TOP);
        handle = new HandleView(ctx);
        root.addView(handle, new LinearLayout.LayoutParams(Ui.dp(ctx, 20), Ui.dp(ctx, 60)));

        rootLp = new WindowManager.LayoutParams(-2, -2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        applyCutoutMode(rootLp);
        place(false);

        final int slop = ViewConfiguration.get(ctx).getScaledTouchSlop();
        final float[] x0 = new float[1];
        handle.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    x0[0] = e.getRawX();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (e.getRawX() - x0[0] > Ui.dp(ctx, 14)) openPanel();
                    return true;
                case MotionEvent.ACTION_UP:
                    if (Math.abs(e.getRawX() - x0[0]) < slop) openPanel();
                    return true;
                default:
                    return true;
            }
        });
        try { wm.addView(root, rootLp); } catch (Throwable t) { root = null; }
        if (Prefs.b(ctx, Prefs.MACRO_ON, false)) buildMacroBtn();
    }

    private void openPanel() {
        if (expanded || root == null) return;
        expanded = true;
        Rect sc = screen();
        place(true);
        panelW = Math.min(Ui.dp(ctx, 330), (int) (sc.width() * 0.52f));
        int avail = sc.height() - rootLp.y - Ui.dp(ctx, 14);
        contentH = Math.max(Ui.dp(ctx, 90), avail - Ui.dp(ctx, 185));
        tab = -1;
        drawer = buildDrawer();
        handle.setVisibility(View.GONE);
        root.addView(drawer, new LinearLayout.LayoutParams(panelW, -2));
        drawer.setTranslationX(-panelW);
        drawer.animate().translationX(0f).setDuration(220).start();
        try { wm.updateViewLayout(root, rootLp); } catch (Throwable ignored) { }
        updateHz();
        main.post(perfLoop);
    }

    private void closePanel(boolean animate) {
        if (!expanded) return;
        expanded = false;
        main.removeCallbacks(perfLoop);
        stopPlaceTarget();
        final View d = drawer;
        Runnable fin = () -> {
            if (root != null && d != null) root.removeView(d);
            drawer = null;
            sheet = null;
            body = null;
            tab = -1;
            if (handle != null) handle.setVisibility(View.VISIBLE);
            if (root != null) {
                place(false);
                try { wm.updateViewLayout(root, rootLp); } catch (Throwable ignored) { }
            }
        };
        if (animate && d != null) d.animate().translationX(-panelW).setDuration(180).withEndAction(fin).start();
        else fin.run();
    }

    private void hideAll() {
        main.removeCallbacks(perfLoop);
        if (root != null) { try { wm.removeView(root); } catch (Throwable ignored) { } }
        root = null; drawer = null; sheet = null; body = null; handle = null; expanded = false;
        stopPlaceTarget();
        removeMacroBtn();
    }

    private TextView iconBtn(String label, View.OnClickListener l) {
        TextView t = Ui.tv(ctx, label, 16, Ui.TXT, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(Ui.glass(ctx, 15));
        t.setOnClickListener(l);
        Ui.press(t);
        return t;
    }

    private LinearLayout buildDrawer() {
        LinearLayout d = Ui.col(ctx);
        int pad = Ui.dp(ctx, 12);
        d.setPadding(pad, pad, pad, pad);
        GradientDrawable bg = Ui.rect(ctx, 0xEE0B0B0E, 22);
        bg.setStroke(Ui.dp(ctx, 1), Ui.acc(0x66));
        d.setBackground(bg);

        // Header: logo, judul, FPS/CPU, reset, tutup
        LinearLayout head = Ui.row(ctx);
        ImageView lg = new ImageView(ctx);
        lg.setImageResource(R.drawable.logo_drax);
        lg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        lg.setBackground(Ui.rect(ctx, Ui.SURF, 9));
        lg.setClipToOutline(true);
        head.addView(lg, new LinearLayout.LayoutParams(Ui.dp(ctx, 28), Ui.dp(ctx, 28)));
        TextView title = Ui.tv(ctx, "DRAX", 15, Ui.TXT, true);
        title.setTypeface(Ui.brand(ctx));
        title.setLetterSpacing(.15f);
        head.addView(title, Ui.lp(ctx, 0, -2, 8, 0, 0, 0));
        ((LinearLayout.LayoutParams) title.getLayoutParams()).weight = 1f;
        LinearLayout stats = Ui.col(ctx);
        stats.setGravity(Gravity.END);
        fpsTxt = Ui.tv(ctx, "-- FPS", 14, Ui.TXT, true);
        cpuTxt = Ui.tv(ctx, "CPU --%", 10.5f, Ui.MUTED, true);
        stats.addView(fpsTxt);
        stats.addView(cpuTxt, Ui.wrapLp(ctx, 1));
        head.addView(stats, Ui.lp(ctx, -2, -2, 0, 0, 10, 0));
        head.addView(iconBtn("↺", v -> {
            Shell.async(() -> Resetter.resetAll(this));
            Panels.toast(this, "Semua pengaturan direset");
            main.postDelayed(() -> { syncCrosshair(); updateHz(); if (tab >= 0) fillBody(); }, 900);
        }), Ui.lp(ctx, Ui.dp(ctx, 30), Ui.dp(ctx, 30), 0, 0, 6, 0));
        head.addView(iconBtn("‹", v -> closePanel(true)), Ui.lp(ctx, Ui.dp(ctx, 30), Ui.dp(ctx, 30), 0, 0, 0, 0));
        final float[] hx = new float[1];
        head.setOnTouchListener((v, e) -> {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) { hx[0] = e.getRawX(); return true; }
            if (e.getActionMasked() == MotionEvent.ACTION_MOVE && hx[0] - e.getRawX() > Ui.dp(ctx, 40)) closePanel(true);
            return true;
        });
        d.addView(head);

        // Refresh rate
        LinearLayout seg = Ui.row(ctx);
        seg.setBackground(Ui.glass(ctx, 16));
        seg.setPadding(Ui.dp(ctx, 3), Ui.dp(ctx, 3), Ui.dp(ctx, 3), Ui.dp(ctx, 3));
        final Set<Integer> sup = supportedHz();
        for (int i = 0; i < 4; i++) {
            final int hz = HZ[i];
            TextView t = Ui.tv(ctx, hz + " Hz", 11.5f, Ui.TXT, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, Ui.dp(ctx, 7), 0, Ui.dp(ctx, 7));
            t.setOnClickListener(v -> {
                if (!sup.contains(hz)) { Panels.toast(this, hz + " Hz tidak didukung layar ini"); return; }
                desiredHz = hz;
                pushModePref(hz);
                Panels.applyHz(this, hz);
                main.postDelayed(() -> {
                    updateHz();
                    int cur;
                    try { cur = Math.round(display().getRefreshRate()); } catch (Throwable ignored) { cur = hz; }
                    if (cur == hz) { desiredHz = -1; Panels.toast(this, "Berhasil pindah ke " + hz + " Hz"); }
                    else Panels.toast(this, "HP ini belum mengizinkan " + hz + " Hz dari sini (sekarang " + cur + " Hz)");
                }, 2600);
            });
            hzTv[i] = t;
            seg.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        d.addView(seg, Ui.wrapLp(ctx, 10));

        // Ikon fitur
        LinearLayout tabs = Ui.row(ctx);
        int[] kinds = {HexButton.AUDIO, HexButton.SUN, HexButton.CROSS, HexButton.SENSI, HexButton.MAKRO};
        for (int i = 0; i < 5; i++) {
            final int idx = i;
            HexButton b = new HexButton(ctx, kinds[i], "", "");
            b.setOnClickListener(v -> { tab = tab == idx ? -1 : idx; paintTabs(); updateSheet(); });
            tabBtns[i] = b;
            tabs.addView(b, new LinearLayout.LayoutParams(0, Ui.dp(ctx, 46), 1f));
        }
        d.addView(tabs, Ui.wrapLp(ctx, 8));
        paintTabs();
        return d;
    }

    private void paintTabs() {
        for (int i = 0; i < 5; i++) if (tabBtns[i] != null) tabBtns[i].set(i == tab, false);
    }

    /** Ketuk ikon sekali: pengaturan muncul. Ketuk lagi: hilang. */
    private void updateSheet() {
        if (drawer == null) return;
        if (tab < 0) {
            if (sheet != null) drawer.removeView(sheet);
            sheet = null;
            body = null;
        } else {
            if (sheet == null) {
                sheet = Ui.col(ctx);
                sheet.setPadding(Ui.dp(ctx, 10), Ui.dp(ctx, 8), Ui.dp(ctx, 10), Ui.dp(ctx, 8));
                sheet.setBackground(Ui.glass(ctx, 16));
                body = new ScrollView(ctx);
                body.setVerticalScrollBarEnabled(false);
                sheet.addView(body, new LinearLayout.LayoutParams(-1, contentH));
                drawer.addView(sheet, Ui.lp(ctx, -1, -2, 0, 8, 0, 0));
                sheet.setAlpha(0f);
                sheet.animate().alpha(1f).setDuration(150).start();
            }
            fillBody();
        }
        try { wm.updateViewLayout(root, rootLp); } catch (Throwable ignored) { }
    }

    private void fillBody() {
        if (body == null) return;
        body.removeAllViews();
        View v;
        if (tab == 0) v = Panels.audio(ctx);
        else if (tab == 1) v = Panels.brightness(ctx);
        else if (tab == 2) v = Panels.crosshairSide(ctx);
        else if (tab == 3) v = Panels.sensi(ctx);
        else v = macroPanel();
        body.addView(v);
    }

    // ---------- Makro ----------

    private void loadMacroTargets() {
        macroTargets.clear();
        String s = Prefs.s(ctx, Prefs.MACRO_TARGETS, "");
        if (s == null || s.isEmpty()) return;
        for (String seg : s.split(";")) {
            String[] p = seg.split(",");
            if (p.length != 3) continue;
            try { macroTargets.add(new int[]{Integer.parseInt(p[0].trim()), Integer.parseInt(p[1].trim()), Integer.parseInt(p[2].trim())}); }
            catch (NumberFormatException ignored) { }
        }
    }

    private void saveMacroTargets() {
        StringBuilder sb = new StringBuilder();
        for (int[] t : macroTargets) { if (sb.length() > 0) sb.append(';'); sb.append(t[0]).append(',').append(t[1]).append(',').append(t[2]); }
        Prefs.put(ctx, Prefs.MACRO_TARGETS, sb.toString());
    }

    /** Jalankan urutan tap makro di background lewat "input tap" (Shizuku), tiap target punya jeda sendiri. */
    private void fireMacro() {
        List<int[]> snap = new ArrayList<>(macroTargets);
        if (snap.isEmpty()) { Panels.toast(ctx, "Belum ada target. Buka tab Makro > + Tambah Target"); return; }
        Shell.async(() -> {
            for (int[] t : snap) {
                if (t[2] > 0) try { Thread.sleep(t[2]); } catch (InterruptedException e) { return; }
                Shell.run("input tap " + t[0] + " " + t[1]);
            }
        });
    }

    private View macroPanel() {
        if (macroTargets.isEmpty() && Prefs.s(ctx, Prefs.MACRO_TARGETS, "") != null && !Prefs.s(ctx, Prefs.MACRO_TARGETS, "").isEmpty()) loadMacroTargets();
        LinearLayout col = Ui.col(ctx);
        col.addView(Ui.switchRow(ctx, "Makro", "Tombol trigger bisa digeser di layar, target dijalankan berurutan",
                Prefs.b(ctx, Prefs.MACRO_ON, false), on -> {
                    Prefs.put(ctx, Prefs.MACRO_ON, on);
                    if (on) buildMacroBtn(); else removeMacroBtn();
                }));
        col.addView(Ui.slider(ctx, "Opacity", 0, 100, Prefs.i(ctx, Prefs.MACRO_OPACITY, 85), "%", v -> {
            Prefs.put(ctx, Prefs.MACRO_OPACITY, v);
            if (macroBtn != null) macroBtn.setAlpha(Math.max(0.05f, v / 100f));
        }));
        macroList = Ui.col(ctx);
        col.addView(macroList);
        rebuildMacroList();
        TextView add = Ui.tv(ctx, "+ TAMBAH TARGET", 12, Ui.ON_ACC, true);
        add.setGravity(Gravity.CENTER);
        add.setPadding(Ui.dp(ctx, 14), Ui.dp(ctx, 9), Ui.dp(ctx, 14), Ui.dp(ctx, 9));
        GradientDrawable bgAdd = new GradientDrawable();
        bgAdd.setColor(Ui.YEL);
        bgAdd.setCornerRadius(Ui.dp(ctx, 12));
        add.setBackground(bgAdd);
        add.setOnClickListener(v -> {
            Rect sc = screen();
            macroTargets.add(new int[]{sc.width() / 2, sc.height() / 2, 150});
            saveMacroTargets(); rebuildMacroList();
            startPlaceTarget(macroTargets.size() - 1);
        });
        LinearLayout.LayoutParams addLp = new LinearLayout.LayoutParams(-2, -2);
        addLp.topMargin = Ui.dp(ctx, 8);
        col.addView(add, addLp);
        TextView hint = Ui.tv(ctx, "Tombol 📍 = geser titik oranye ke posisi yang mau ditap. Tombol ⚡ di layar = jalankan makronya.", 10, Ui.MUTED, false);
        hint.setPadding(0, Ui.dp(ctx, 6), 0, 0);
        col.addView(hint);
        return col;
    }

    private void rebuildMacroList() {
        if (macroList == null) return;
        macroList.removeAllViews();
        for (int i = 0; i < macroTargets.size(); i++) {
            final int idx = i;
            int[] t = macroTargets.get(i);
            LinearLayout row = Ui.row(ctx);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, Ui.dp(ctx, 4), 0, Ui.dp(ctx, 4));
            TextView num = Ui.tv(ctx, "T" + (idx + 1), 12, Ui.YEL, true);
            row.addView(num, new LinearLayout.LayoutParams(Ui.dp(ctx, 26), -2));
            TextView pin = Ui.tv(ctx, "📍", 15, Ui.TXT, false);
            pin.setGravity(Gravity.CENTER);
            pin.setPadding(Ui.dp(ctx, 7), Ui.dp(ctx, 5), Ui.dp(ctx, 7), Ui.dp(ctx, 5));
            GradientDrawable pinBg = new GradientDrawable();
            pinBg.setColor(macroEditIdx == idx ? Ui.acc(0x55) : 0x14FFFFFF);
            pinBg.setStroke(Ui.dp(ctx, 1), 0x33FFFFFF);
            pinBg.setCornerRadius(Ui.dp(ctx, 10));
            pin.setBackground(pinBg);
            pin.setOnClickListener(v -> { if (macroEditIdx == idx) stopPlaceTarget(); else startPlaceTarget(idx); });
            row.addView(pin, Ui.lp(ctx, -2, -2, 0, 0, 6, 0));
            LinearLayout sliderWrap = Ui.col(ctx);
            TextView msLabel = Ui.tv(ctx, t[2] + " ms", 11, Ui.TXT, true);
            sliderWrap.addView(new SliderView(ctx, 0, 2000, t[2], v -> { t[2] = v; msLabel.setText(v + " ms"); saveMacroTargets(); }),
                    new LinearLayout.LayoutParams(-1, Ui.dp(ctx, 30)));
            row.addView(sliderWrap, new LinearLayout.LayoutParams(0, -2, 1f));
            row.addView(msLabel, Ui.lp(ctx, Ui.dp(ctx, 46), -2, 4, 0, 0, 0));
            TextView del = Ui.tv(ctx, "✕", 14, Ui.MUTED, true);
            del.setPadding(Ui.dp(ctx, 8), Ui.dp(ctx, 4), Ui.dp(ctx, 8), Ui.dp(ctx, 4));
            del.setOnClickListener(v -> {
                if (macroEditIdx == idx) stopPlaceTarget();
                macroTargets.remove(idx); saveMacroTargets(); rebuildMacroList();
            });
            row.addView(del, Ui.lp(ctx, -2, -2, 6, 0, 0, 0));
            macroList.addView(row);
        }
    }

    /** Titik oranye yang bisa digeser ke posisi target. Dibuat/dihapus lewat tombol pin tiap baris. */
    private void startPlaceTarget(int idx) {
        stopPlaceTarget();
        macroEditIdx = idx;
        rebuildMacroList();
        int sizeV = Ui.dp(ctx, 34);
        TextView mk = Ui.tv(ctx, String.valueOf(idx + 1), 13, Color.WHITE, true);
        mk.setGravity(Gravity.CENTER);
        GradientDrawable mkBg = new GradientDrawable();
        mkBg.setColor(Color.argb(225, 255, 140, 0));
        mkBg.setStroke(Ui.dp(ctx, 2), Color.WHITE);
        mkBg.setCornerRadius(sizeV / 2f);
        mk.setBackground(mkBg);
        WindowManager.LayoutParams mlp = new WindowManager.LayoutParams(sizeV, sizeV,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        mlp.gravity = Gravity.TOP | Gravity.START;
        Rect sc = screen();
        int[] cur = idx < macroTargets.size() ? macroTargets.get(idx) : null;
        mlp.x = clamp((cur != null ? cur[0] : sc.width() / 2) - sizeV / 2, 0, Math.max(0, sc.width() - sizeV));
        mlp.y = clamp((cur != null ? cur[1] : sc.height() / 2) - sizeV / 2, 0, Math.max(0, sc.height() - sizeV));
        final float[] down = new float[2];
        final int[] start = new int[2];
        mk.setOnTouchListener((v, e) -> {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    down[0] = e.getRawX(); down[1] = e.getRawY(); start[0] = mlp.x; start[1] = mlp.y;
                    break;
                case MotionEvent.ACTION_MOVE:
                    mlp.x = clamp((int) (start[0] + (e.getRawX() - down[0])), 0, Math.max(0, sc.width() - sizeV));
                    mlp.y = clamp((int) (start[1] + (e.getRawY() - down[1])), 0, Math.max(0, sc.height() - sizeV));
                    try { wm.updateViewLayout(mk, mlp); } catch (Throwable ignored) { }
                    break;
                case MotionEvent.ACTION_UP:
                    if (idx < macroTargets.size()) {
                        macroTargets.get(idx)[0] = mlp.x + sizeV / 2;
                        macroTargets.get(idx)[1] = mlp.y + sizeV / 2;
                        saveMacroTargets();
                    }
                    break;
            }
            return true;
        });
        macroMarker = mk; macroMarkerLp = mlp;
        try { wm.addView(mk, mlp); } catch (Throwable ignored) { }
        Panels.toast(ctx, "Geser titik oranye T" + (idx + 1) + " ke posisi yang mau ditap");
    }

    private void stopPlaceTarget() {
        try { if (macroMarker != null) wm.removeView(macroMarker); } catch (Throwable ignored) { }
        macroMarker = null; macroMarkerLp = null;
        if (macroEditIdx != -1) { macroEditIdx = -1; rebuildMacroList(); }
    }

    /** Tombol petir yang bisa digeser di layar; tap (tanpa geser) = jalankan makro. */
    private void buildMacroBtn() {
        if (macroBtn != null) return;
        loadMacroTargets();
        int sizeV = Ui.dp(ctx, 50);
        TextView b = Ui.tv(ctx, "⚡", 20, Ui.ON_ACC, true);
        b.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Ui.YEL);
        bg.setCornerRadius(sizeV / 2f);
        b.setBackground(bg);
        b.setAlpha(Math.max(0.05f, Prefs.i(ctx, Prefs.MACRO_OPACITY, 85) / 100f));
        WindowManager.LayoutParams blp = new WindowManager.LayoutParams(sizeV, sizeV,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        blp.gravity = Gravity.TOP | Gravity.START;
        Rect sc = screen();
        int bx = Prefs.i(ctx, Prefs.MACRO_BX, -1), by = Prefs.i(ctx, Prefs.MACRO_BY, -1);
        blp.x = (bx >= 0 && bx <= sc.width()) ? bx : (sc.width() / 2 - sizeV / 2);
        blp.y = (by >= 0 && by <= sc.height()) ? by : (sc.height() / 2);
        final float[] down = new float[2];
        final int[] start = new int[2];
        final boolean[] moved = {false};
        b.setOnTouchListener((v, e) -> {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    down[0] = e.getRawX(); down[1] = e.getRawY(); start[0] = blp.x; start[1] = blp.y; moved[0] = false;
                    break;
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getRawX() - down[0], dy = e.getRawY() - down[1];
                    if (Math.abs(dx) > Ui.dp(ctx, 8) || Math.abs(dy) > Ui.dp(ctx, 8)) {
                        moved[0] = true;
                        blp.x = clamp((int) (start[0] + dx), 0, Math.max(0, sc.width() - sizeV));
                        blp.y = clamp((int) (start[1] + dy), 0, Math.max(0, sc.height() - sizeV));
                        try { wm.updateViewLayout(b, blp); } catch (Throwable ignored) { }
                    }
                    break;
                }
                case MotionEvent.ACTION_UP:
                    if (moved[0]) { Prefs.put(ctx, Prefs.MACRO_BX, blp.x); Prefs.put(ctx, Prefs.MACRO_BY, blp.y); }
                    else fireMacro();
                    break;
            }
            return true;
        });
        macroBtn = b; macroBtnLp = blp;
        try { wm.addView(b, blp); } catch (Throwable ignored) { }
    }

    private void removeMacroBtn() {
        try { if (macroBtn != null) wm.removeView(macroBtn); } catch (Throwable ignored) { }
        macroBtn = null; macroBtnLp = null;
    }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    // ---------- Refresh rate ----------

    private Display display() {
        return ((DisplayManager) getSystemService(DISPLAY_SERVICE)).getDisplay(Display.DEFAULT_DISPLAY);
    }

    private Set<Integer> supportedHz() {
        Set<Integer> s = new HashSet<>();
        try {
            for (Display.Mode m : display().getSupportedModes()) s.add(Math.round(m.getRefreshRate()));
        } catch (Throwable ignored) { }
        if (s.isEmpty()) s.add(60);
        return s;
    }

    private void updateHz() {
        if (drawer == null) return;
        int cur;
        try { cur = Math.round(display().getRefreshRate()); } catch (Throwable t) { cur = 60; }
        Set<Integer> sup = supportedHz();
        for (int i = 0; i < 4; i++) {
            TextView t = hzTv[i];
            if (t == null) continue;
            boolean locked = !sup.contains(HZ[i]), sel = HZ[i] == cur;
            t.setBackground(sel ? Ui.gradBg(ctx, 13) : null);
            t.setTextColor(sel ? Ui.ON_ACC : (locked ? Ui.MUTED : Ui.TXT));
            t.setAlpha(locked ? .4f : 1f);
        }
    }

    // ---------- FPS dan CPU ----------

    private final Runnable perfLoop = new Runnable() {
        @Override public void run() {
            if (!expanded || !inGame) return;
            perfTick();
            main.postDelayed(this, 1000);
        }
    };

    private void perfTick() {
        if (perfBusy || !curPkg.matches("[A-Za-z0-9_.]+")) return;
        perfBusy = true;
        final String pkg = curPkg;
        final String cmd = "echo CPU $(head -n1 /proc/stat); "
                + "dumpsys SurfaceFlinger --list | grep -F '" + pkg + "' | while IFS= read -r L; do "
                + "echo \"LAYER $L\"; dumpsys SurfaceFlinger --latency \"$L\"; done";
        Shell.async(() -> {
            final String out = Shell.run(cmd);
            main.post(() -> { perfBusy = false; parsePerf(out); });
        });
    }

    private static long stamp(String[] t) {
        int[] order = {1, 2, 0};
        for (int i : order) {
            try {
                long v = Long.parseLong(t[i]);
                if (v > 0 && v < Long.MAX_VALUE / 2) return v;
            } catch (NumberFormatException ignored) { }
        }
        return 0;
    }

    private void parsePerf(String out) {
        if (!expanded || fpsTxt == null) return;
        int cpu = -1;
        List<List<Long>> blocks = new ArrayList<>();
        List<Long> cur = null;
        boolean periodSkipped = false;
        for (String raw : out.split("\n")) {
            String line = raw.trim();
            if (line.startsWith("CPU cpu")) {
                String[] t = line.split("\\s+");
                if (t.length > 9) {
                    try {
                        long tot = 0;
                        for (int i = 2; i <= 9; i++) tot += Long.parseLong(t[i]);
                        long idle = Long.parseLong(t[5]) + Long.parseLong(t[6]);
                        if (lastCpu != null && tot > lastCpu[0]) {
                            long dt = tot - lastCpu[0], di = idle - lastCpu[1];
                            cpu = (int) Math.max(0, Math.min(100, 100 * (dt - di) / dt));
                        }
                        lastCpu = new long[]{tot, idle};
                    } catch (NumberFormatException ignored) { }
                }
            } else if (line.startsWith("LAYER")) {
                cur = new ArrayList<>();
                blocks.add(cur);
                periodSkipped = false;
            } else if (cur != null) {
                String[] t = line.split("\\s+");
                if (!periodSkipped) { if (t.length == 1) periodSkipped = true; continue; }
                if (t.length == 3) {
                    long v = stamp(t);
                    if (v > 0) cur.add(v);
                }
            }
        }
        int best = 0;
        for (List<Long> b : blocks) {
            if (b.size() < 5) continue;
            long max = 0;
            for (long v : b) max = Math.max(max, v);
            int cnt = 0;
            for (long v : b) if (v > max - 1_000_000_000L) cnt++;
            best = Math.max(best, cnt);
        }
        int fps = best > 0 ? Math.min(best, 240) : -1;
        fpsTxt.setText(fps >= 0 ? fps + " FPS" : "-- FPS");
        fpsTxt.setTextColor(fps < 0 ? Ui.TXT : fps >= 55 ? Ui.OK : fps >= 30 ? 0xFFFFB300 : Ui.BAD);
        if (fps >= 0) lastFps = fps;
        if (cpu >= 0 && cpuTxt != null) cpuTxt.setText("CPU " + cpu + "%");
    }

    // ---------- Crosshair ----------

    private void syncCrosshair() {
        if (!panelActive || !Prefs.b(this, Prefs.CH_ON, false)) {
            if (cross != null) { try { wm.removeView(cross); } catch (Throwable ignored) { } cross = null; }
            return;
        }
        int size = Ui.dp(ctx, Prefs.i(this, Prefs.CH_SIZE, 28) + 6);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(size, size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.CENTER;
        lp.x = Ui.dp(ctx, Prefs.i(this, Prefs.CH_DX, 0));
        lp.y = Ui.dp(ctx, Prefs.i(this, Prefs.CH_DY, 0));
        applyCutoutMode(lp);
        try {
            if (cross == null) { cross = new CrosshairView(ctx); wm.addView(cross, lp); }
            else { wm.updateViewLayout(cross, lp); cross.invalidate(); }
        } catch (Throwable ignored) { }
    }

    @Override public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        if (root != null) {
            if (expanded) closePanel(false);
            else { place(false); try { wm.updateViewLayout(root, rootLp); } catch (Throwable ignored) { } }
        }
        if (cross != null) syncCrosshair();
    }

    @Override public void onDestroy() {
        alive = false;
        main.removeCallbacksAndMessages(null);
        try { Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(prefL); } catch (Throwable ignored) { }
        Shell.async(SensiEngine::stop);
        leave();
        super.onDestroy();
    }
}

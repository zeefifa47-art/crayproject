package com.cray.hazi;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.Insets;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.ContextThemeWrapper;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Memantau game yang ditambahkan; menampilkan tab panel dan crosshair hanya saat game dibuka. */
public class GameService extends Service {
    private static final String CH_ID = "cray_game";
    private static final long RESET_MS = 5 * 60 * 1000L;
    private static final Pattern PKG = Pattern.compile("u\\d+\\s+([\\w.]+)/");
    private static final int[] HZ = {60, 90, 120, 144};

    private final Handler main = new Handler(Looper.getMainLooper());
    private Context ctx;
    private WindowManager wm;
    private boolean alive, busy, inGame, expanded, perfBusy;
    private String curPkg = "";
    private LinearLayout root, panel;
    private View handle;
    private ScrollView body;
    private CrosshairView cross;
    private WindowManager.LayoutParams rootLp;
    private final HexButton[] tabBtns = new HexButton[4], hzBtns = new HexButton[4];
    private GaugeView gauge;
    private TextView cpuTxt;
    private View cpuFill;
    private int tab = 2, trackPx, lastFps = -1;
    private long[] lastCpu;
    private SharedPreferences.OnSharedPreferenceChangeListener prefL;

    static void start(Context c) {
        try { c.startForegroundService(new Intent(c, GameService.class)); } catch (Throwable ignored) { }
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        Ui.load(this);
        Context base = this;
        if (Build.VERSION.SDK_INT >= 30) {
            try { base = createWindowContext(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, null); } catch (Throwable ignored) { }
        }
        wm = (WindowManager) base.getSystemService(Context.WINDOW_SERVICE);
        ctx = new ContextThemeWrapper(base, R.style.Theme_Cray);
        prefL = (sp, key) -> {
            if (key == null) return;
            if (key.startsWith("ch_") && inGame) main.post(this::syncCrosshair);
            else if (key.equals(Prefs.THEME)) main.post(() -> { Ui.load(this); if (inGame) { hideAll(); showHandle(); } });
        };
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(prefL);
    }

    @Override public int onStartCommand(Intent i, int flags, int id) {
        startFg();
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY; }
        if (!alive) { alive = true; main.post(tick); }
        return START_STICKY;
    }

    private void startFg() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CH_ID, "DRAX Mode Game", NotificationManager.IMPORTANCE_LOW));
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CH_ID)
                .setSmallIcon(R.drawable.ic_notif).setContentTitle("DRAX aktif")
                .setContentText("Panel muncul otomatis saat game dibuka").setContentIntent(pi).setOngoing(true).build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1, n);
    }

    // ---------- Deteksi game ----------

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!alive) return;
            if (!busy) {
                busy = true;
                Shell.async(() -> {
                    final boolean ready = Shell.ready();
                    final String out = ready ? Shell.run("dumpsys activity activities | grep -E 'topResumedActivity|ResumedActivity' | head -n 3") : "";
                    main.post(() -> { busy = false; onTop(out, ready); });
                });
            }
            main.postDelayed(this, 2000);
        }
    };

    private void onTop(String out, boolean ready) {
        boolean now = false;
        if (ready) {
            Matcher m = PKG.matcher(out);
            if (m.find() && Games.has(this, m.group(1))) { now = true; curPkg = m.group(1); }
        }
        if (now != inGame) {
            inGame = now;
            if (inGame) enter(); else leave();
        }
        long t = System.currentTimeMillis();
        if (inGame) {
            Prefs.put(this, Prefs.LEFT_AT, 0L);
        } else if (Resetter.anyApplied(this)) {
            long left = Prefs.l(this, Prefs.LEFT_AT, 0L);
            if (left == 0) Prefs.put(this, Prefs.LEFT_AT, t);
            else if (t - left >= RESET_MS) {
                Prefs.put(this, Prefs.LEFT_AT, 0L);
                Shell.async(() -> Resetter.resetAll(this));
                Panels.toast(this, "DRAX: semua pengaturan direset");
            }
        } else {
            Prefs.put(this, Prefs.LEFT_AT, 0L);
        }
    }

    private void enter() { showHandle(); syncCrosshair(); }

    private void leave() {
        hideAll();
        if (cross != null) { try { wm.removeView(cross); } catch (Throwable ignored) { } cross = null; }
    }

    // ---------- Ukuran layar ----------

    private int[] cutout() {
        try {
            WindowInsets wi = wm.getCurrentWindowMetrics().getWindowInsets();
            Insets in = wi.getInsets(WindowInsets.Type.displayCutout());
            return new int[]{in.left, in.top, in.right, in.bottom};
        } catch (Throwable t) {
            return new int[4];
        }
    }

    private Rect screen() {
        try { return wm.getCurrentWindowMetrics().getBounds(); } catch (Throwable t) { return new Rect(0, 0, 1600, 720); }
    }

    private void applyCutoutMode(WindowManager.LayoutParams lp) {
        if (Build.VERSION.SDK_INT >= 30) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        else if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
    }

    // ---------- Tab dan panel ----------

    private void showHandle() {
        if (root != null) return;
        root = Ui.col(ctx);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        handle = new HandleView(ctx);
        root.addView(handle, new LinearLayout.LayoutParams(-2, -2));

        rootLp = new WindowManager.LayoutParams(-2, -2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        rootLp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        rootLp.y = cutout()[1];
        applyCutoutMode(rootLp);

        final int slop = ViewConfiguration.get(ctx).getScaledTouchSlop();
        final float[] y0 = new float[1];
        handle.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    y0[0] = e.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (e.getRawY() - y0[0] > Ui.dp(ctx, 14)) openPanel();
                    return true;
                case MotionEvent.ACTION_UP:
                    if (Math.abs(e.getRawY() - y0[0]) < slop) openPanel();
                    return true;
                default:
                    return true;
            }
        });
        try { wm.addView(root, rootLp); } catch (Throwable t) { root = null; }
    }

    private void openPanel() {
        if (expanded || root == null) return;
        expanded = true;
        Rect sc = screen();
        int[] cut = cutout();
        int side = Math.max(Math.max(cut[0], cut[2]), Ui.dp(ctx, 12));
        int panelW = Math.min(sc.width() - 2 * side, Ui.dp(ctx, 620));
        rootLp.y = cut[1] + Ui.dp(ctx, 6);
        int hexW = Math.max(Ui.dp(ctx, 34), Math.min(Ui.dp(ctx, 54), (panelW - Ui.dp(ctx, 24) - Ui.dp(ctx, 100)) / 8));
        int contentH = Math.max(Ui.dp(ctx, 90), Math.min(Ui.dp(ctx, 200), sc.height() - rootLp.y - Ui.dp(ctx, 190)));
        panel = buildPanel(hexW, contentH);
        handle.setVisibility(View.GONE);
        root.addView(panel, new LinearLayout.LayoutParams(panelW, -2));
        panel.setAlpha(0f);
        panel.setTranslationY(-Ui.dp(ctx, 24));
        panel.animate().alpha(1f).translationY(0f).setDuration(180).start();
        try { wm.updateViewLayout(root, rootLp); } catch (Throwable ignored) { }
        updateHz();
        main.post(perfLoop);
    }

    private void closePanel() {
        if (!expanded) return;
        expanded = false;
        main.removeCallbacks(perfLoop);
        if (panel != null && root != null) root.removeView(panel);
        panel = null;
        body = null;
        if (handle != null) handle.setVisibility(View.VISIBLE);
        if (root != null) {
            rootLp.y = cutout()[1];
            try { wm.updateViewLayout(root, rootLp); } catch (Throwable ignored) { }
        }
    }

    private void hideAll() {
        main.removeCallbacks(perfLoop);
        if (root != null) { try { wm.removeView(root); } catch (Throwable ignored) { } }
        root = null; panel = null; body = null; handle = null; expanded = false;
    }

    private LinearLayout buildPanel(int hexW, int contentH) {
        LinearLayout p = Ui.col(ctx);
        int pad = Ui.dp(ctx, 10);
        p.setPadding(pad, pad, pad, pad);
        GradientDrawable bg = Ui.rect(ctx, Ui.alpha(Ui.BG, 0xF2), 18);
        bg.setStroke(Ui.dp(ctx, 2), Ui.YEL);
        p.setBackground(bg);

        LinearLayout head = Ui.row(ctx);
        android.widget.ImageView lg = new android.widget.ImageView(ctx);
        lg.setImageResource(R.drawable.logo_drax);
        lg.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
        lg.setBackground(Ui.rect(ctx, Ui.SURF, 8));
        lg.setClipToOutline(true);
        head.addView(lg, Ui.lp(ctx, Ui.dp(ctx, 26), Ui.dp(ctx, 26), 0, 0, 8, 0));
        TextView title = Ui.tv(ctx, "DRAX  PANEL", 11, Ui.YEL, true);
        title.setLetterSpacing(.18f);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView reset = Ui.pill(ctx, "RESET", Ui.acc(0x33), Ui.YEL);
        reset.setOnClickListener(v -> {
            Shell.async(() -> Resetter.resetAll(this));
            Panels.toast(this, "Semua pengaturan direset");
            main.postDelayed(() -> { syncCrosshair(); updateHz(); if (body != null) showTab(); }, 900);
        });
        Ui.press(reset);
        head.addView(reset);
        TextView x = Ui.tv(ctx, "X", 13, 0xFFFFFFFF, true);
        x.setGravity(Gravity.CENTER);
        GradientDrawable red = new GradientDrawable();
        red.setShape(GradientDrawable.OVAL);
        red.setColor(0xFFD32F2F);
        x.setBackground(red);
        x.setOnClickListener(v -> closePanel());
        Ui.press(x);
        head.addView(x, Ui.lp(ctx, Ui.dp(ctx, 30), Ui.dp(ctx, 30), 8, 0, 0, 0));
        p.addView(head);

        int hexH = Math.round(hexW * 0.866f) + Ui.dp(ctx, 17);
        LinearLayout mainRow = Ui.row(ctx);
        String[] names = {"AUDIO", "KECERAHAN", "CROSSHAIR", "SENSI"};
        int[] kinds = {HexButton.AUDIO, HexButton.SUN, HexButton.CROSS, HexButton.SENSI};
        for (int i = 0; i < 4; i++) {
            HexButton b = new HexButton(ctx, kinds[i], "", names[i]);
            final int idx = i;
            b.setOnClickListener(v -> { tab = idx; paintTabs(); showTab(); });
            tabBtns[i] = b;
            mainRow.addView(b, new LinearLayout.LayoutParams(hexW, hexH));
        }
        LinearLayout center = Ui.col(ctx);
        center.setGravity(Gravity.CENTER_HORIZONTAL);
        gauge = new GaugeView(ctx);
        gauge.set(-1, 60, null);
        center.addView(gauge, new LinearLayout.LayoutParams(Ui.dp(ctx, 84), Ui.dp(ctx, 70)));
        cpuTxt = Ui.tv(ctx, "CPU --%", 11, Ui.TXT, true);
        center.addView(cpuTxt, Ui.wrapLp(ctx, 2));
        trackPx = Ui.dp(ctx, 100);
        FrameLayout track = new FrameLayout(ctx);
        track.setBackground(Ui.rect(ctx, 0x22FFFFFF, 2));
        cpuFill = new View(ctx);
        cpuFill.setBackground(Ui.rect(ctx, Ui.YEL, 2));
        track.addView(cpuFill, new FrameLayout.LayoutParams(0, -1));
        center.addView(track, Ui.lp(ctx, trackPx, Ui.dp(ctx, 4), 0, 4, 0, 0));
        mainRow.addView(center, new LinearLayout.LayoutParams(0, -2, 1f));

        Set<Integer> sup = supportedHz();
        for (int i = 0; i < 4; i++) {
            boolean ok = sup.contains(HZ[i]);
            HexButton b = new HexButton(ctx, HexButton.TEXT, String.valueOf(HZ[i]), ok ? "Hz" : HZ[i] + " Hz");
            b.set(false, !ok);
            final int hz = HZ[i];
            b.setOnClickListener(v -> {
                if (!ok) { Panels.toast(this, hz + " Hz tidak didukung layar ini"); return; }
                Panels.applyHz(this, hz);
                main.postDelayed(this::updateHz, 900);
            });
            hzBtns[i] = b;
            mainRow.addView(b, new LinearLayout.LayoutParams(hexW, hexH));
        }
        p.addView(mainRow, Ui.wrapLp(ctx, 4));

        body = new ScrollView(ctx);
        body.setVerticalScrollBarEnabled(false);
        body.setBackground(Ui.stroke(ctx, Ui.acc(0x22), Ui.acc(0x33), 12));
        body.setPadding(Ui.dp(ctx, 12), Ui.dp(ctx, 6), Ui.dp(ctx, 12), Ui.dp(ctx, 6));
        p.addView(body, Ui.lp(ctx, -1, contentH, 0, 8, 0, 0));
        paintTabs();
        showTab();
        return p;
    }

    private void paintTabs() {
        for (int i = 0; i < 4; i++) if (tabBtns[i] != null) tabBtns[i].set(i == tab, false);
    }

    private void showTab() {
        if (body == null) return;
        body.removeAllViews();
        View v;
        if (tab == 0) v = Panels.audio(ctx);
        else if (tab == 1) v = Panels.brightness(ctx);
        else if (tab == 2) v = Panels.crosshairWide(ctx);
        else v = Panels.sensi(ctx);
        body.addView(v);
    }

    // ---------- Refresh rate ----------

    private Display display() {
        return ((DisplayManager) getSystemService(DISPLAY_SERVICE)).getDisplay(Display.DEFAULT_DISPLAY);
    }

    private Set<Integer> supportedHz() {
        Set<Integer> s = new HashSet<>();
        try {
            for (Display.Mode m : display().getSupportedModes()) s.add(Math.round(m.getRefreshRate()));
        } catch (Throwable ignored) { }
        if (s.isEmpty()) s.add(60);
        return s;
    }

    private void updateHz() {
        if (!expanded) return;
        int cur;
        try { cur = Math.round(display().getRefreshRate()); } catch (Throwable t) { cur = 60; }
        Set<Integer> sup = supportedHz();
        for (int i = 0; i < 4; i++) if (hzBtns[i] != null) hzBtns[i].set(HZ[i] == cur, !sup.contains(HZ[i]));
    }

    // ---------- FPS dan CPU ----------

    private final Runnable perfLoop = new Runnable() {
        @Override public void run() {
            if (!expanded || !inGame) return;
            perfTick();
            main.postDelayed(this, 1000);
        }
    };

    private void perfTick() {
        if (perfBusy || !curPkg.matches("[A-Za-z0-9_.]+")) return;
        perfBusy = true;
        final String pkg = curPkg;
        final String cmd = "echo CPU $(head -n1 /proc/stat); "
                + "L=$(dumpsys SurfaceFlinger --list | grep -F '" + pkg + "' | grep -F 'SurfaceView' | head -n1); "
                + "[ -z \"$L\" ] && L=$(dumpsys SurfaceFlinger --list | grep -F '" + pkg + "' | head -n1); "
                + "echo LAYER; dumpsys SurfaceFlinger --latency \"$L\"";
        Shell.async(() -> {
            final String out = Shell.run(cmd);
            main.post(() -> { perfBusy = false; parsePerf(out); });
        });
    }

    private void parsePerf(String out) {
        if (!expanded || gauge == null) return;
        int cpu = -1;
        boolean afterLayer = false, periodSkipped = false;
        List<Long> ts = new ArrayList<>();
        for (String raw : out.split("\n")) {
            String line = raw.trim();
            if (line.startsWith("CPU cpu")) {
                String[] t = line.split("\\s+");
                if (t.length > 9) {
                    try {
                        long tot = 0;
                        for (int i = 2; i <= 9; i++) tot += Long.parseLong(t[i]);
                        long idle = Long.parseLong(t[5]) + Long.parseLong(t[6]);
                        if (lastCpu != null && tot > lastCpu[0]) {
                            long dt = tot - lastCpu[0], di = idle - lastCpu[1];
                            cpu = (int) Math.max(0, Math.min(100, 100 * (dt - di) / dt));
                        }
                        lastCpu = new long[]{tot, idle};
                    } catch (NumberFormatException ignored) { }
                }
            } else if (line.equals("LAYER")) {
                afterLayer = true;
            } else if (afterLayer) {
                String[] t = line.split("\\s+");
                if (!periodSkipped) { if (t.length == 1) periodSkipped = true; continue; }
                if (t.length == 3) {
                    try {
                        long v = Long.parseLong(t[1]);
                        if (v > 0 && v < Long.MAX_VALUE / 2) ts.add(v);
                    } catch (NumberFormatException ignored) { }
                }
            }
        }
        int fps = -1;
        if (ts.size() >= 5) {
            long max = 0;
            for (long v : ts) max = Math.max(max, v);
            int cnt = 0;
            for (long v : ts) if (v > max - 1_000_000_000L) cnt++;
            fps = Math.min(cnt, 240);
        }
        String trend = null;
        if (fps >= 0 && lastFps >= 0) trend = fps > lastFps + 3 ? "NAIK" : fps < lastFps - 3 ? "TURUN" : "STABIL";
        if (fps >= 0) lastFps = fps;
        int maxHz = 60;
        for (int h : supportedHz()) maxHz = Math.max(maxHz, h);
        gauge.set(fps, maxHz, trend);
        if (cpu >= 0 && cpuTxt != null) {
            cpuTxt.setText("CPU " + cpu + "%");
            cpuFill.setLayoutParams(new FrameLayout.LayoutParams(trackPx * cpu / 100, -1));
        }
    }

    // ---------- Crosshair ----------

    private void syncCrosshair() {
        if (!inGame || !Prefs.b(this, Prefs.CH_ON, false)) {
            if (cross != null) { try { wm.removeView(cross); } catch (Throwable ignored) { } cross = null; }
            return;
        }
        int size = Ui.dp(ctx, Prefs.i(this, Prefs.CH_SIZE, 28) + 6);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(size, size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.CENTER;
        lp.x = Ui.dp(ctx, Prefs.i(this, Prefs.CH_DX, 0));
        lp.y = Ui.dp(ctx, Prefs.i(this, Prefs.CH_DY, 0));
        applyCutoutMode(lp);
        try {
            if (cross == null) { cross = new CrosshairView(ctx); wm.addView(cross, lp); }
            else { wm.updateViewLayout(cross, lp); cross.invalidate(); }
        } catch (Throwable ignored) { }
    }

    @Override public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        if (root != null) { closePanel(); rootLp.y = cutout()[1]; try { wm.updateViewLayout(root, rootLp); } catch (Throwable ignored) { } }
        if (cross != null) syncCrosshair();
    }

    @Override public void onDestroy() {
        alive = false;
        main.removeCallbacksAndMessages(null);
        try { Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(prefL); } catch (Throwable ignored) { }
        leave();
        super.onDestroy();
    }
}

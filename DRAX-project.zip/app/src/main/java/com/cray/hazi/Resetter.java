package com.cray.hazi;

import android.content.Context;
import android.media.AudioManager;
import android.provider.Settings;

final class Resetter {
    static boolean anyApplied(Context c) {
        return Prefs.b(c, Prefs.PX_APPLIED, false) || Prefs.i(c, Prefs.DPI_APPLIED, 0) != 0
                || Prefs.i(c, Prefs.BR_ORIG, -1) >= 0 || Prefs.i(c, Prefs.VOL_ORIG, -1) >= 0
                || Prefs.b(c, Prefs.CH_ON, false) || Prefs.b(c, Prefs.HZ_SET, false)
                || Prefs.i(c, Prefs.PTR_ORIG, -99) != -99
                || Prefs.i(c, Prefs.SENSI_X, 0) > 0 || Prefs.i(c, Prefs.SENSI_Y, 0) > 0;
    }

    /** Panggil dari thread latar. */
    static void resetAll(Context c) {
        Context a = c.getApplicationContext();
        Angle.reset();
        SensiEngine.stop();
        Prefs.put(a, Prefs.SENSI_X, 0);
        Prefs.put(a, Prefs.SENSI_Y, 0);
        if (Prefs.i(a, Prefs.DPI_APPLIED, 0) != 0) Shell.run("wm density reset");
        restoreDisplay(a);
        Prefs.put(a, Prefs.CH_ON, false);
        Prefs.put(a, Prefs.PX_APPLIED, false);
        Prefs.put(a, Prefs.PX_LEVEL, 0);
        Prefs.put(a, Prefs.PX_NEAREST, false);
        Prefs.put(a, Prefs.PX_MIP, false);
        Prefs.put(a, Prefs.DPI_APPLIED, 0);
        Prefs.put(a, Prefs.LEFT_AT, 0L);
    }

    static void restoreDisplay(Context a) {
        int br = Prefs.i(a, Prefs.BR_ORIG, -1);
        if (br >= 0) {
            try {
                Settings.System.putInt(a.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, br);
                Settings.System.putInt(a.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE,
                        Prefs.i(a, Prefs.BR_MODE, 0));
            } catch (Throwable ignored) { }
            Prefs.put(a, Prefs.BR_ORIG, -1);
        }
        if (Prefs.b(a, Prefs.HZ_SET, false)) {
            String[] keys = {"peak_refresh_rate", "min_refresh_rate", "user_refresh_rate"};
            String[] pk = {"hz_o_peak", "hz_o_min", "hz_o_user"};
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < keys.length; i++) {
                String o = Prefs.sp(a).getString(pk[i], "null");
                if (o.isEmpty() || o.equals("null")) sb.append("settings delete system ").append(keys[i]);
                else sb.append("settings put system ").append(keys[i]).append(' ').append(o);
                sb.append("; ");
            }
            int m0 = Prefs.i(a, Prefs.HZ_MODE0, -1);
            if (m0 >= 0) sb.append("service call SurfaceFlinger 1035 i32 ").append(m0);
            if (Shell.ready()) Shell.run(sb.toString());
            Prefs.put(a, Prefs.HZ_SET, false);
        }
        int po = Prefs.i(a, Prefs.PTR_ORIG, -99);
        if (po != -99) {
            try { Settings.System.putInt(a.getContentResolver(), "pointer_speed", po); } catch (Throwable ignored) { }
            Prefs.put(a, Prefs.PTR_ORIG, -99);
        }
        int v = Prefs.i(a, Prefs.VOL_ORIG, -1);
        if (v >= 0) {
            try {
                ((AudioManager) a.getSystemService(Context.AUDIO_SERVICE)).setStreamVolume(AudioManager.STREAM_MUSIC, v, 0);
            } catch (Throwable ignored) { }
            Prefs.put(a, Prefs.VOL_ORIG, -1);
        }
    }
}

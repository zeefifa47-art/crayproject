package com.cray.hazi;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Dialog untuk memilih game dari aplikasi terpasang. */
final class GamePicker {
    private static final class App { String pkg, label; Drawable icon; }

    static void show(Activity a, Runnable onChanged) {
        Dialog d = new Dialog(a, R.style.Theme_Cray_Dialog);
        LinearLayout root = Ui.col(a);
        int p = Ui.dp(a, 16);
        root.setPadding(p, p, p, p);
        root.setBackground(Ui.stroke(a, Ui.SURF, Ui.LINE, 24));
        root.addView(Ui.tv(a, "Tambah Game", 18, Ui.TXT, true));
        TextView sub = Ui.tv(a, "Pilih game yang ingin memakai panel DRAX. Ketuk lagi untuk menghapus.", 12, Ui.MUTED, false);
        root.addView(sub, Ui.wrapLp(a, 4));

        EditText q = new EditText(a);
        q.setHint("Cari aplikasi...");
        q.setSingleLine(true);
        q.setTextSize(14);
        q.setTextColor(Ui.TXT);
        q.setHintTextColor(Ui.MUTED);
        q.setTypeface(Ui.med(a));
        q.setPadding(Ui.dp(a, 14), Ui.dp(a, 10), Ui.dp(a, 14), Ui.dp(a, 10));
        q.setBackground(Ui.rect(a, Ui.SURF2, 14));
        root.addView(q, Ui.wrapLp(a, 12));

        ScrollView sv = new ScrollView(a);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout list = Ui.col(a);
        sv.addView(list);
        TextView loading = Ui.tv(a, "Memuat daftar aplikasi...", 13, Ui.MUTED, false);
        loading.setPadding(0, Ui.dp(a, 16), 0, 0);
        list.addView(loading);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(Ui.button(a, "Selesai", true, v -> d.dismiss()), Ui.wrapLp(a, 12));

        d.setContentView(root);
        d.setOnDismissListener(x -> onChanged.run());
        d.show();
        if (d.getWindow() != null) {
            int w = a.getResources().getDisplayMetrics().widthPixels, h = a.getResources().getDisplayMetrics().heightPixels;
            d.getWindow().setLayout(Math.min((int) (w * .92), Ui.dp(a, 480)), (int) (h * .82));
        }

        final List<App> apps = new ArrayList<>();
        new Thread(() -> {
            PackageManager pm = a.getPackageManager();
            Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            Set<String> seen = new HashSet<>();
            for (ResolveInfo r : pm.queryIntentActivities(i, 0)) {
                String pkg = r.activityInfo.packageName;
                if (pkg.equals(a.getPackageName()) || !seen.add(pkg)) continue;
                App ap = new App();
                ap.pkg = pkg;
                ap.label = String.valueOf(r.loadLabel(pm));
                ap.icon = r.loadIcon(pm);
                apps.add(ap);
            }
            apps.sort((x, y) -> x.label.compareToIgnoreCase(y.label));
            a.runOnUiThread(() -> render(a, list, apps, ""));
        }).start();

        q.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int af) { }
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) { }
            @Override public void afterTextChanged(Editable e) { render(a, list, apps, e.toString()); }
        });
    }

    private static void render(Activity a, LinearLayout list, List<App> apps, String filter) {
        list.removeAllViews();
        String f = filter.trim().toLowerCase(Locale.ROOT);
        for (App ap : apps) {
            if (!f.isEmpty() && !ap.label.toLowerCase(Locale.ROOT).contains(f) && !ap.pkg.contains(f)) continue;
            LinearLayout r = Ui.row(a);
            r.setPadding(Ui.dp(a, 6), Ui.dp(a, 8), Ui.dp(a, 6), Ui.dp(a, 8));
            ImageView iv = new ImageView(a);
            iv.setImageDrawable(ap.icon);
            r.addView(iv, new LinearLayout.LayoutParams(Ui.dp(a, 40), Ui.dp(a, 40)));
            LinearLayout t = Ui.col(a);
            t.addView(Ui.tv(a, ap.label, 14, Ui.TXT, true));
            t.addView(Ui.tv(a, ap.pkg, 10.5f, Ui.MUTED, false), Ui.wrapLp(a, 2));
            r.addView(t, Ui.lp(a, 0, -2, 12, 0, 8, 0));
            ((LinearLayout.LayoutParams) t.getLayoutParams()).weight = 1f;
            TextView tag = Ui.pill(a, "", 0, Ui.DARK);
            r.addView(tag);
            Runnable paint = () -> {
                boolean on = Games.has(a, ap.pkg);
                tag.setText(on ? "Ditambah" : "Tambah");
                tag.setTextColor(on ? Ui.ON_ACC : Ui.YEL);
                tag.setBackground(on ? Ui.rect(a, Ui.YEL, 20) : Ui.stroke(a, 0, Ui.acc(0x66), 20));
            };
            paint.run();
            r.setOnClickListener(v -> {
                if (Games.has(a, ap.pkg)) Games.remove(a, ap.pkg); else Games.add(a, ap.pkg);
                paint.run();
            });
            list.addView(r);
        }
        if (list.getChildCount() == 0) list.addView(Ui.tv(a, "Tidak ada aplikasi yang cocok.", 13, Ui.MUTED, false));
    }
}

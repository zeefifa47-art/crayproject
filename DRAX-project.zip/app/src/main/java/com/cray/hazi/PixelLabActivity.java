package com.cray.hazi;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

/** Pixel Lab: tekstur kasar lewat ANGLE. Hanya Android 15+. */
public class PixelLabActivity extends Activity {
    private static final String[] LEVELS = {"Asli", "Ringan", "Retro", "Kotak", "Ekstrem"};
    private static final String[] PRESETS = {"Halus", "Retro", "Kotak Total", "Kustom"};
    private int level, tab;
    private boolean nearest, mip;
    private boolean locked;
    private String pkg;
    private CompareView compare;
    private TextView levelName;
    private FrameLayout host;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.load(this);
        locked = Build.VERSION.SDK_INT < 35;
        pkg = getIntent().getStringExtra("pkg");
        if (pkg != null && !Prefs.sp(this).contains("px_" + pkg)) Prefs.put(this, "px_" + pkg, true);
        level = Prefs.i(this, Prefs.PX_LEVEL, 2);
        nearest = Prefs.b(this, Prefs.PX_NEAREST, true);
        mip = Prefs.b(this, Prefs.PX_MIP, true);
        tab = Prefs.i(this, Prefs.PX_TAB, 1);
        host = new FrameLayout(this);
        host.setFitsSystemWindows(true);
        host.setBackgroundColor(Ui.BG);
        setContentView(host);
        build();
    }

    @Override public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        build();
    }

    private void refresh() {
        compare.update(level, nearest, mip);
        levelName.setText(LEVELS[level]);
    }

    private void build() {
        host.removeAllViews();
        boolean land = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
        LinearLayout root = Ui.col(this);
        int p = Ui.dp(this, 16);
        root.setPadding(p, Ui.dp(this, 8), p, p);

        // header
        LinearLayout head = Ui.row(this);
        TextView back = Ui.tv(this, "<", 18, Ui.TXT, true);
        back.setGravity(Gravity.CENTER);
        back.setBackground(Ui.stroke(this, Ui.SURF, Ui.LINE, 22));
        back.setOnClickListener(v -> finish());
        Ui.press(back);
        head.addView(back, new LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44)));
        LinearLayout ht = Ui.col(this);
        TextView tag = Ui.tv(this, "DRAX GAME SPACE", 10.5f, Ui.YEL, true);
        tag.setLetterSpacing(.2f);
        ht.addView(tag);
        ht.addView(Ui.tv(this, "Tekstur Ringan", 20, Ui.TXT, true), Ui.wrapLp(this, 4));
        head.addView(ht, Ui.lp(this, 0, -2, 14, 0, 0, 0));
        ((LinearLayout.LayoutParams) ht.getLayoutParams()).weight = 1f;
        root.addView(head);

        if (locked) {
            LinearLayout w = Ui.card(this);
            w.setBackground(Ui.stroke(this, 0x22FF5A5F, 0x66FF5A5F, 16));
            w.addView(Ui.tv(this, "Terkunci: Pixel Lab hanya untuk Android 15 ke atas. Perangkatmu Android " + Build.VERSION.RELEASE + ".", 12.5f, Ui.TXT, true));
            root.addView(w, Ui.wrapLp(this, 10));
        }

        LinearLayout body = land ? Ui.row(this) : Ui.col(this);
        body.setGravity(Gravity.TOP);

        // kiri: sampel + game
        LinearLayout left = Ui.col(this);
        compare = new CompareView(this);
        left.addView(compare, land ? new LinearLayout.LayoutParams(-1, 0, 1f) : new LinearLayout.LayoutParams(-1, Ui.dp(this, 230)));
        LinearLayout games = Ui.card(this);
        games.setPadding(Ui.dp(this, 14), Ui.dp(this, 4), Ui.dp(this, 14), Ui.dp(this, 4));
        if (pkg == null) {
            games.addView(Ui.tv(this, "Buka Pixel Lab dari Game Space.", 12.5f, Ui.MUTED, true));
            games.setPadding(Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 14));
        } else {
            games.addView(Ui.switchRow(this, Games.label(this, pkg), "Terapkan tekstur kasar untuk game ini",
                    Prefs.b(this, "px_" + pkg, true), v -> Prefs.put(this, "px_" + pkg, v)));
        }
        left.addView(games, Ui.wrapLp(this, 12));

        // kanan: kontrol
        LinearLayout controls = Ui.col(this);
        controls.addView(Ui.chips(this, PRESETS, tab, i -> { tab = i; preset(i); }));
        LinearLayout lv = Ui.row(this);
        lv.addView(Ui.tv(this, "Detail Tekstur", 14, Ui.TXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        levelName = Ui.tv(this, LEVELS[level], 14, Ui.YEL, true);
        lv.addView(levelName);
        controls.addView(lv, Ui.wrapLp(this, 16));
        controls.addView(Ui.slider(this, "Asli  >  Ekstrem", 0, 4, level, "", v -> { level = v; tab = 3; refresh(); }));
        LinearLayout opt = Ui.col(this);
        opt.addView(Ui.switchRow(this, "Piksel Tajam", "Tepi tekstur kotak-kotak. Matikan untuk efek buram halus.", nearest, v -> { nearest = v; refresh(); }));
        opt.addView(Ui.switchRow(this, "Batas Jarak Tegas", "Perpindahan detail dekat-jauh jadi patah-patah.", mip, v -> { mip = v; refresh(); }));
        LinearLayout oc = Ui.card(this);
        oc.setPadding(Ui.dp(this, 14), Ui.dp(this, 4), Ui.dp(this, 14), Ui.dp(this, 4));
        oc.addView(opt);
        controls.addView(oc, Ui.wrapLp(this, 10));
        TextView h1 = Ui.tv(this, "• Diubah waktu lagi main? Tutup game lalu buka lagi.", 11.5f, Ui.MUTED, false);
        TextView h2 = Ui.tv(this, "• Paling kelihatan kalau grafis game di setelan paling rendah.", 11.5f, Ui.MUTED, false);
        TextView h3 = Ui.tv(this, "• Sampel di atas hanya simulasi, bukan tampilan asli game.", 11.5f, Ui.MUTED, false);
        controls.addView(h1, Ui.wrapLp(this, 12));
        controls.addView(h2, Ui.wrapLp(this, 6));
        controls.addView(h3, Ui.wrapLp(this, 6));

        LinearLayout btns = Ui.row(this);
        btns.addView(Ui.button(this, "Reset", false, v -> doReset()), new LinearLayout.LayoutParams(0, -2, 1f));
        btns.addView(Ui.button(this, "Simpan", true, v -> doSave(false)), Ui.lp(this, 0, -2, 8, 0, 0, 0));
        btns.addView(Ui.button(this, "MAIN", true, v -> doSave(true)), Ui.lp(this, 0, -2, 8, 0, 0, 0));
        ((LinearLayout.LayoutParams) btns.getChildAt(1).getLayoutParams()).weight = 1.4f;
        ((LinearLayout.LayoutParams) btns.getChildAt(2).getLayoutParams()).weight = 1f;
        controls.addView(btns, Ui.wrapLp(this, 16));
        controls.setAlpha(locked ? .4f : 1f);

        FrameLayout rightWrap = new FrameLayout(this);
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.addView(controls);
        rightWrap.addView(sv);
        if (locked) {
            View blocker = new View(this);
            blocker.setClickable(true);
            blocker.setOnClickListener(v -> Panels.toast(this, "Pixel Lab hanya untuk Android 15 ke atas"));
            rightWrap.addView(blocker, new FrameLayout.LayoutParams(-1, -1));
        }

        if (land) {
            body.addView(left, new LinearLayout.LayoutParams(0, -1, 1f));
            body.addView(rightWrap, Ui.lp(this, 0, -1, 16, 0, 0, 0));
            ((LinearLayout.LayoutParams) rightWrap.getLayoutParams()).weight = 1f;
            root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1f));
            ((LinearLayout.LayoutParams) body.getLayoutParams()).topMargin = Ui.dp(this, 12);
        } else {
            ScrollView all = new ScrollView(this);
            all.setVerticalScrollBarEnabled(false);
            LinearLayout stack = Ui.col(this);
            stack.addView(left);
            stack.addView(rightWrap, Ui.wrapLp(this, 12));
            all.addView(stack);
            root.addView(all, new LinearLayout.LayoutParams(-1, 0, 1f));
        }
        host.addView(root, new FrameLayout.LayoutParams(-1, -1));
        refresh();
    }

    private void preset(int i) {
        if (i == 0) { level = 1; nearest = false; mip = false; }
        else if (i == 1) { level = 2; nearest = true; mip = true; }
        else if (i == 2) { level = 3; nearest = true; mip = true; }
        else return;
        build();
    }

    private List<String> pkgs() {
        List<String> l = new ArrayList<>();
        for (String g : Games.list(this)) if (Prefs.b(this, "px_" + g, false)) l.add(g);
        return l;
    }

    private void saveState(boolean applied) {
        Prefs.put(this, Prefs.PX_LEVEL, level);
        Prefs.put(this, Prefs.PX_NEAREST, nearest);
        Prefs.put(this, Prefs.PX_MIP, mip);
        Prefs.put(this, Prefs.PX_TAB, tab);
        Prefs.put(this, Prefs.PX_APPLIED, applied);
        Prefs.put(this, Prefs.LEFT_AT, 0L);
    }

    private void doSave(boolean play) {
        if (locked) { Panels.toast(this, "Pixel Lab hanya untuk Android 15 ke atas"); return; }
        List<String> p = pkgs();
        if (p.isEmpty()) { Panels.toast(this, "Aktifkan game ini dulu"); return; }
        final int lv = level;
        final boolean n = nearest, m = mip;
        final boolean any = !Angle.features(lv, n, m).isEmpty();
        saveState(any);
        Prefs.put(this, Prefs.GAME_MODE, true);
        GameService.start(this);
        Shell.async(() -> {
            if (!Shell.ready()) { Panels.toast(this, "Shizuku belum aktif"); return; }
            Angle.apply(p, lv, n, m);
            if (play) {
                StringBuilder sb = new StringBuilder();
                for (String s : p) sb.append("am force-stop ").append(s).append("; ");
                Shell.run(sb.toString());
                runOnUiThread(() -> launch(pkg != null ? pkg : p.get(0)));
            } else {
                Panels.toast(this, "Tersimpan. Tutup game lalu buka lagi.");
            }
        });
    }

    private void launch(String pkg) {
        Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
        if (i != null) startActivity(i); else Panels.toast(this, "Game tidak ditemukan");
    }

    private void doReset() {
        if (locked) { Panels.toast(this, "Pixel Lab hanya untuk Android 15 ke atas"); return; }
        level = 0; nearest = false; mip = false; tab = 3;
        saveState(false);
        Shell.async(() -> {
            if (Shell.ready()) Angle.reset();
            Panels.toast(this, "Dikembalikan ke asli");
        });
        build();
    }
}

package com.cray.hazi;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Pixel Lab: tekstur kasar lewat ANGLE. Hanya Android 15+. Semua setelan tersimpan otomatis. */
public class PixelLabActivity extends Activity {
    private static final String[] LEVELS = {"Asli", "Ringan", "Retro", "Kotak", "Ekstrem"};
    private static final String[] PRESETS = {"Halus", "Retro", "Kotak Total", "Kustom"};
    private int level, tab;
    private boolean nearest, mip;
    private boolean locked;
    private String pkg;
    private CompareView compare;
    private TextView levelName;
    private TextView[] tickLabels;
    private FrameLayout host;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.load(this);
        locked = Build.VERSION.SDK_INT < 35;
        pkg = getIntent().getStringExtra("pkg");
        if (pkg != null && !Prefs.sp(this).contains("px_" + pkg)) Prefs.put(this, "px_" + pkg, true);
        level = Prefs.i(this, Prefs.PX_LEVEL, 2);
        nearest = Prefs.b(this, Prefs.PX_NEAREST, true);
        mip = Prefs.b(this, Prefs.PX_MIP, true);
        tab = Prefs.i(this, Prefs.PX_TAB, 1);
        host = new FrameLayout(this);
        host.setFitsSystemWindows(true);
        host.setBackground(new GridDrawable(this));
        setContentView(host);
        build();
    }

    @Override public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        build();
    }

    /** Simpan otomatis setiap perubahan. */
    private void persist() {
        Prefs.put(this, Prefs.PX_LEVEL, level);
        Prefs.put(this, Prefs.PX_NEAREST, nearest);
        Prefs.put(this, Prefs.PX_MIP, mip);
        Prefs.put(this, Prefs.PX_TAB, tab);
    }

    private void refresh() {
        compare.update(level, nearest, mip);
        levelName.setText(LEVELS[level]);
        for (int i = 0; i < tickLabels.length; i++) tickLabels[i].setTextColor(i == level ? Ui.YEL : Ui.MUTED);
    }

    private void build() {
        host.removeAllViews();
        boolean land = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
        LinearLayout root = Ui.col(this);
        int p = Ui.dp(this, 16);
        root.setPadding(p, Ui.dp(this, 8), p, p);

        LinearLayout head = Ui.row(this);
        TextView back = Ui.tv(this, "‹", 26, Ui.TXT, true);
        back.setGravity(Gravity.CENTER);
        back.setBackground(Ui.glass(this, 22));
        back.setOnClickListener(v -> finish());
        Ui.press(back);
        head.addView(back, new LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44)));
        LinearLayout ht = Ui.col(this);
        ht.addView(Ui.tv(this, "Pixel Lab", 22, Ui.TXT, true));
        ht.addView(Ui.tv(this, "Tekstur ringan · tersimpan otomatis", 12, Ui.MUTED, false), Ui.wrapLp(this, 2));
        head.addView(ht, Ui.lp(this, 0, -2, 14, 0, 0, 0));
        ((LinearLayout.LayoutParams) ht.getLayoutParams()).weight = 1f;
        root.addView(head);

        if (locked) {
            LinearLayout w = Ui.card(this);
            w.addView(Ui.tv(this, "Terkunci: Pixel Lab hanya untuk Android 15 ke atas. Perangkatmu Android " + Build.VERSION.RELEASE + ".", 12.5f, Ui.BAD, true));
            root.addView(w, Ui.wrapLp(this, 10));
        }

        LinearLayout body = land ? Ui.row(this) : Ui.col(this);
        body.setGravity(Gravity.TOP);

        // kiri: sampel + pilihan game
        LinearLayout left = Ui.col(this);
        compare = new CompareView(this);
        left.addView(compare, land ? new LinearLayout.LayoutParams(-1, 0, 1f) : new LinearLayout.LayoutParams(-1, Ui.dp(this, 230)));
        LinearLayout games = Ui.card(this);
        games.setPadding(Ui.dp(this, 14), Ui.dp(this, 12), Ui.dp(this, 14), Ui.dp(this, 12));
        games.addView(Ui.tv(this, "Game", 14, Ui.TXT, true));
        if (pkg == null) {
            games.addView(Ui.tv(this, "Buka Pixel Lab dari Game Space.", 12, Ui.MUTED, false), Ui.wrapLp(this, 6));
        } else {
            HorizontalScrollView hs = new HorizontalScrollView(this);
            hs.setHorizontalScrollBarEnabled(false);
            LinearLayout chipRow = new LinearLayout(this);
            hs.addView(chipRow);
            for (String g : Games.list(this)) {
                TextView chip = Ui.tv(this, Games.label(this, g), 12, Ui.TXT, true);
                chip.setPadding(Ui.dp(this, 14), Ui.dp(this, 9), Ui.dp(this, 14), Ui.dp(this, 9));
                Runnable paint = () -> {
                    boolean on = Prefs.b(this, "px_" + g, false);
                    chip.setBackground(on ? Ui.gradBg(this, 14) : Ui.glass(this, 14));
                    chip.setTextColor(on ? Ui.ON_ACC : Ui.TXT);
                };
                paint.run();
                chip.setOnClickListener(v -> {
                    Prefs.put(this, "px_" + g, !Prefs.b(this, "px_" + g, false));
                    paint.run();
                });
                chipRow.addView(chip, Ui.lp(this, -2, -2, 0, 0, 8, 0));
            }
            games.addView(hs, Ui.wrapLp(this, 8));
            games.addView(Ui.tv(this, "Pilih game yang memakai tekstur kasar.", 11, Ui.MUTED, false), Ui.wrapLp(this, 6));
        }
        left.addView(games, Ui.wrapLp(this, 12));

        // kanan: kontrol
        LinearLayout controls = Ui.col(this);
        controls.addView(Ui.segment(this, PRESETS, tab, i -> { tab = i; preset(i); }));

        LinearLayout sc = Ui.card(this);
        LinearLayout lv = Ui.row(this);
        lv.addView(Ui.tv(this, "Tingkat Tekstur", 16, Ui.TXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        levelName = Ui.tv(this, LEVELS[level], 14, Ui.YEL, true);
        lv.addView(levelName);
        sc.addView(lv);
        sc.addView(Ui.tv(this, "Makin tinggi, makin kasar dan kotak-kotak.", 12, Ui.MUTED, false), Ui.wrapLp(this, 4));
        sc.addView(new SliderView(this, 0, 4, level, v -> {
            level = v;
            tab = 3;
            persist();
            refresh();
        }), Ui.lp(this, -1, Ui.dp(this, 34), 0, 12, 0, 0));
        LinearLayout ticks = new LinearLayout(this);
        tickLabels = new TextView[LEVELS.length];
        for (int i = 0; i < LEVELS.length; i++) {
            TextView t = Ui.tv(this, LEVELS[i], 10.5f, Ui.MUTED, true);
            t.setGravity(i == 0 ? Gravity.START : i == LEVELS.length - 1 ? Gravity.END : Gravity.CENTER);
            tickLabels[i] = t;
            ticks.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        sc.addView(ticks, Ui.lp(this, -1, -2, 6, 4, 6, 0));
        controls.addView(sc, Ui.wrapLp(this, 12));

        ToggleView t1 = new ToggleView(this);
        t1.set(nearest);
        t1.setOnChange(v -> { nearest = v; persist(); refresh(); });
        controls.addView(Ui.feature(this, new IconView(this, IconView.GRID), 26, "Piksel Tajam",
                "Tepi tekstur kotak-kotak. Matikan untuk efek buram halus.", t1), Ui.wrapLp(this, 10));
        ToggleView t2 = new ToggleView(this);
        t2.set(mip);
        t2.setOnChange(v -> { mip = v; persist(); refresh(); });
        controls.addView(Ui.feature(this, new IconView(this, IconView.LAYERS), 26, "Batas Jarak Tegas",
                "Perpindahan detail dekat-jauh jadi patah-patah.", t2), Ui.wrapLp(this, 10));

        controls.addView(Ui.tv(this, "• Kalau sudah aktif dan belum direset, tekstur langsung berubah saat game dibuka lewat DRAX tanpa simpan lagi.", 11.5f, Ui.MUTED, false), Ui.wrapLp(this, 12));
        controls.addView(Ui.tv(this, "• Diubah waktu lagi main? Tutup game lalu buka lagi.", 11.5f, Ui.MUTED, false), Ui.wrapLp(this, 6));
        controls.addView(Ui.tv(this, "• Paling kelihatan kalau grafis game di setelan paling rendah.", 11.5f, Ui.MUTED, false), Ui.wrapLp(this, 6));

        LinearLayout btns = Ui.row(this);
        btns.addView(Ui.lightBtn(this, "Reset ke Asli", v -> doReset()), new LinearLayout.LayoutParams(0, -2, 1f));
        btns.addView(Ui.cbtn(this, "Simpan", true, true, v -> doSave(false)), Ui.lp(this, 0, -2, 10, 0, 0, 0));
        ((LinearLayout.LayoutParams) btns.getChildAt(1).getLayoutParams()).weight = 1f;
        controls.addView(btns, Ui.wrapLp(this, 16));
        controls.addView(Ui.cbtn(this, "Launch", true, false, v -> doSave(true)), Ui.wrapLp(this, 10));
        controls.setAlpha(locked ? .4f : 1f);

        FrameLayout rightWrap = new FrameLayout(this);
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.addView(controls);
        rightWrap.addView(sv);
        if (locked) {
            View blocker = new View(this);
            blocker.setClickable(true);
            blocker.setOnClickListener(v -> Panels.toast(this, "Pixel Lab hanya untuk Android 15 ke atas"));
            rightWrap.addView(blocker, new FrameLayout.LayoutParams(-1, -1));
        }

        if (land) {
            body.addView(left, new LinearLayout.LayoutParams(0, -1, 1f));
            body.addView(rightWrap, Ui.lp(this, 0, -1, 16, 0, 0, 0));
            ((LinearLayout.LayoutParams) rightWrap.getLayoutParams()).weight = 1f;
            root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1f));
            ((LinearLayout.LayoutParams) body.getLayoutParams()).topMargin = Ui.dp(this, 12);
        } else {
            ScrollView all = new ScrollView(this);
            all.setVerticalScrollBarEnabled(false);
            LinearLayout stack = Ui.col(this);
            stack.addView(left);
            stack.addView(rightWrap, Ui.wrapLp(this, 12));
            all.addView(stack);
            root.addView(all, new LinearLayout.LayoutParams(-1, 0, 1f));
        }
        host.addView(root, new FrameLayout.LayoutParams(-1, -1));
        refresh();
    }

    private void preset(int i) {
        if (i == 0) { level = 1; nearest = false; mip = false; }
        else if (i == 1) { level = 2; nearest = true; mip = true; }
        else if (i == 2) { level = 3; nearest = true; mip = true; }
        else { persist(); return; }
        persist();
        build();
    }

    private boolean anyEnabled() {
        for (String g : Games.list(this)) if (Prefs.b(this, "px_" + g, false)) return true;
        return false;
    }

    private void doSave(boolean play) {
        if (locked) { Panels.toast(this, "Pixel Lab hanya untuk Android 15 ke atas"); return; }
        if (!anyEnabled()) { Panels.toast(this, "Pilih minimal satu game dulu"); return; }
        persist();
        boolean any = !Angle.features(level, nearest, mip).isEmpty();
        Prefs.put(this, Prefs.PX_APPLIED, any);
        Prefs.put(this, Prefs.LEFT_AT, 0L);
        Prefs.put(this, Prefs.GAME_MODE, true);
        GameService.start(this);
        if (play && pkg != null) { HomePage.launch(this, pkg); return; }
        Shell.async(() -> {
            if (!Shell.ready()) { Panels.toast(this, "Shizuku belum aktif"); return; }
            Angle.applySaved(this);
            Panels.toast(this, "Tersimpan. Tutup game lalu buka lagi.");
        });
    }

    private void doReset() {
        if (locked) { Panels.toast(this, "Pixel Lab hanya untuk Android 15 ke atas"); return; }
        level = 0; nearest = false; mip = false; tab = 3;
        persist();
        Prefs.put(this, Prefs.PX_APPLIED, false);
        Shell.async(() -> {
            if (Shell.ready()) Angle.reset();
            Panels.toast(this, "Dikembalikan ke asli");
        });
        build();
    }
}

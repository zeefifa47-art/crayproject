package com.cray.hazi;

import java.util.ArrayList;
import java.util.List;

/** Mengatur sampling tekstur lewat fitur ANGLE. */
final class Angle {
    static final String FF = "com.dts.freefireth", FF_MAX = "com.dts.freefiremax";

    static String features(int level, boolean nearest, boolean mip) {
        List<String> f = new ArrayList<>();
        if (nearest) f.add("forceNearestFiltering");
        if (mip) f.add("forceNearestMipFiltering");
        if (level > 0) f.add("forceTextureLodOffset" + Math.min(level, 4));
        return String.join(":", f);
    }

    /** Panggil dari thread latar. */
    static void apply(List<String> pkgs, int level, boolean nearest, boolean mip) {
        String f = features(level, nearest, mip);
        if (f.isEmpty() || pkgs.isEmpty()) { reset(); return; }
        StringBuilder vals = new StringBuilder();
        for (int i = 0; i < pkgs.size(); i++) vals.append(i == 0 ? "" : ",").append("angle");
        Shell.run("settings put global angle_gl_driver_selection_pkgs " + String.join(",", pkgs)
                + "; settings put global angle_gl_driver_selection_values " + vals
                + "; settings put global angle_egl_features '" + f + "'"
                + "; setprop debug.angle.feature_overrides_enabled '" + f + "'");
    }

    static void reset() {
        Shell.run("settings delete global angle_gl_driver_selection_pkgs"
                + "; settings delete global angle_gl_driver_selection_values"
                + "; settings delete global angle_egl_features"
                + "; setprop debug.angle.feature_overrides_enabled ''");
    }
}

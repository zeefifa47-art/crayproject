package com.cray.hazi;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;
import java.util.function.Consumer;

/** Saklar tebal: trek persegi membulat berwarna tema, dengan kotak gelap sebagai gagang. */
final class ToggleView extends View {
    private boolean checked;
    private float pos;
    private Consumer<Boolean> cb;
    private final Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG), th = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private ValueAnimator anim;

    ToggleView(Context c) {
        super(c);
        setClickable(true);
        setOnClickListener(v -> setChecked(!checked, true));
    }

    void setOnChange(Consumer<Boolean> l) { cb = l; }

    boolean isChecked() { return checked; }

    /** Mengubah status tanpa animasi dan tanpa memanggil listener. */
    void set(boolean b) {
        checked = b;
        pos = b ? 1f : 0f;
        invalidate();
    }

    void setChecked(boolean b, boolean notify) {
        if (b == checked) return;
        checked = b;
        if (anim != null) anim.cancel();
        anim = ValueAnimator.ofFloat(pos, b ? 1f : 0f);
        anim.setDuration(160);
        anim.addUpdateListener(a -> { pos = (float) a.getAnimatedValue(); invalidate(); });
        anim.start();
        if (notify && cb != null) cb.accept(b);
    }

    @Override protected void onMeasure(int w, int h) {
        setMeasuredDimension(Ui.dp(getContext(), 58), Ui.dp(getContext(), 38));
    }

    @Override protected void onDraw(Canvas cv) {
        Context c = getContext();
        float w = getWidth(), h = getHeight();
        r.set(0, 0, w, h);
        tp.setColor(Ui.mix(Ui.mix(Ui.BG, 0xFFFFFFFF, .14f), Ui.YEL, pos));
        cv.drawRoundRect(r, Ui.dp(c, 14), Ui.dp(c, 14), tp);
        float s = Ui.dp(c, 24), pad = (h - s) / 2f;
        float x = pad + pos * (w - 2 * pad - s);
        th.setColor(Ui.mix(0xFF8A8A8A, Ui.mix(Ui.BG, 0xFF000000, .55f), pos));
        r.set(x, pad, x + s, pad + s);
        cv.drawRoundRect(r, Ui.dp(c, 9), Ui.dp(c, 9), th);
    }
}

package com.cray.hazi;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private static final String SHIZUKU_PKG = "moe.shizuku.privileged.api";
    private FrameLayout host;
    private boolean mainShown;
    private ViewPager2 pager;
    private final TextView[] tabs = new TextView[2];

    private final Shizuku.OnBinderReceivedListener binderL = () -> runOnUiThread(this::refresh);
    private final Shizuku.OnRequestPermissionResultListener permL = (req, res) -> runOnUiThread(this::refresh);

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.load(this);
        host = new FrameLayout(this);
        host.setFitsSystemWindows(true);
        host.setBackground(new GridDrawable(this));
        setContentView(host);
        try {
            Shizuku.addBinderReceivedListenerSticky(binderL);
            Shizuku.addRequestPermissionResultListener(permL);
        } catch (Throwable ignored) { }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
    }

    @Override protected void onResume() {
        super.onResume();
        refresh();
    }

    @Override protected void onDestroy() {
        try {
            Shizuku.removeBinderReceivedListener(binderL);
            Shizuku.removeRequestPermissionResultListener(permL);
        } catch (Throwable ignored) { }
        super.onDestroy();
    }

    private boolean overlayOk() { return Settings.canDrawOverlays(this); }
    private boolean writeOk() { return Settings.System.canWrite(this); }

    private void refresh() {
        boolean all = overlayOk() && writeOk() && Shell.ready();
        if (all) {
            if (!mainShown) showMain();
            if (Prefs.b(this, Prefs.GAME_MODE, true) && Games.any(this)) GameService.start(this);
        } else {
            mainShown = false;
            showGate();
        }
    }

    // ---------- Gerbang izin ----------

    private void showGate() {
        host.removeAllViews();
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout l = Ui.col(this);
        int p = Ui.dp(this, 22);
        l.setPadding(p, Ui.dp(this, 28), p, p);
        sv.addView(l);

        TextView logo = Ui.tv(this, "DRAX", 44, Ui.YEL, true);
        logo.setTypeface(Ui.brand(this));
        l.addView(logo);
        l.addView(Ui.tv(this, "Siapkan 3 izin dulu supaya semua fitur bisa jalan.", 14, Ui.MUTED, false), Ui.wrapLp(this, 6));

        boolean ov = overlayOk(), wr = writeOk(), sh = Shell.ready();
        l.addView(step(1, "Tampil di atas aplikasi lain", "Untuk panel dan crosshair saat kamu bermain.", ov, "Beri Izin",
                v -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())))), Ui.wrapLp(this, 22));
        l.addView(step(2, "Ubah pengaturan sistem", "Untuk kecerahan layar dan pengaturan suara.", wr, "Beri Izin",
                v -> startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + getPackageName())))), Ui.wrapLp(this, 12));

        String shLabel = "Beri Izin", shDesc = "Untuk Pixel Lab, DPI, dan mendeteksi game yang terbuka.";
        View.OnClickListener shAction = v -> {
            try { Shizuku.requestPermission(100); } catch (Throwable t) { Panels.toast(this, "Jalankan Shizuku dulu"); }
        };
        boolean installed = installed(SHIZUKU_PKG);
        boolean running;
        try { running = Shizuku.pingBinder(); } catch (Throwable t) { running = false; }
        if (!installed) {
            shLabel = "Pasang Shizuku";
            shAction = v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/")));
        } else if (!running) {
            shLabel = "Buka Shizuku";
            shDesc = "Shizuku terpasang tapi belum berjalan. Buka lalu jalankan (Wireless debugging / root).";
            shAction = v -> {
                Intent i = getPackageManager().getLaunchIntentForPackage(SHIZUKU_PKG);
                if (i != null) startActivity(i);
            };
        }
        l.addView(step(3, "Shizuku", shDesc, sh, shLabel, shAction), Ui.wrapLp(this, 12));
        l.addView(Ui.tv(this, "Halaman ini otomatis berganti setelah semua izin aktif.", 11.5f, Ui.MUTED, false), Ui.wrapLp(this, 18));
        host.addView(sv);
    }

    private boolean installed(String pkg) {
        try { getPackageManager().getPackageInfo(pkg, 0); return true; } catch (Throwable t) { return false; }
    }

    private View step(int n, String title, String desc, boolean done, String action, View.OnClickListener l) {
        LinearLayout c = Ui.card(this);
        c.setBackground(Ui.stroke(this, Ui.SURF, done ? 0x663DDC84 : Ui.LINE, 20));
        LinearLayout head = Ui.row(this);
        TextView num = Ui.tv(this, String.valueOf(n), 14, done ? Ui.DARK : Ui.ON_ACC, true);
        num.setGravity(Gravity.CENTER);
        num.setBackground(Ui.rect(this, done ? Ui.OK : Ui.YEL, 14));
        head.addView(num, new LinearLayout.LayoutParams(Ui.dp(this, 28), Ui.dp(this, 28)));
        TextView t = Ui.tv(this, title, 15, Ui.TXT, true);
        head.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        ((LinearLayout.LayoutParams) t.getLayoutParams()).leftMargin = Ui.dp(this, 12);
        head.addView(Ui.pill(this, done ? "Aktif" : "Belum", done ? 0x333DDC84 : 0x33FF5A5F, done ? Ui.OK : Ui.BAD));
        c.addView(head);
        TextView d = Ui.tv(this, desc, 12.5f, Ui.MUTED, false);
        d.setLineSpacing(0, 1.15f);
        c.addView(d, Ui.wrapLp(this, 10));
        if (!done) c.addView(Ui.button(this, action, true, l), Ui.wrapLp(this, 12));
        return c;
    }

    // ---------- Halaman utama ----------

    private void showMain() {
        mainShown = true;
        host.removeAllViews();
        LinearLayout col = Ui.col(this);

        final View[] pages = {HomePage.build(this, () -> pager.setCurrentItem(1, true)), DonatePage.build(this)};
        pager = new ViewPager2(this);
        pager.setAdapter(new RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            @Override public int getItemViewType(int pos) { return pos; }
            @Override public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int type) {
                FrameLayout f = new FrameLayout(parent.getContext());
                f.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
                View v = pages[type];
                if (v.getParent() != null) ((ViewGroup) v.getParent()).removeView(v);
                f.addView(v, new FrameLayout.LayoutParams(-1, -1));
                return new RecyclerView.ViewHolder(f) { };
            }
            @Override public void onBindViewHolder(RecyclerView.ViewHolder h, int pos) { }
            @Override public int getItemCount() { return 2; }
        });
        pager.setOffscreenPageLimit(1);
        pager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override public void onPageSelected(int pos) { paintTabs(pos); }
        });
        col.addView(pager, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout bar = Ui.row(this);
        bar.setPadding(Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 4));
        bar.setBackground(new CyberDrawable(this, Ui.SURF, Ui.SURF, Ui.acc(0x77), 1.5f, 12, false));
        String[] names = {"BERANDA", "DONASI"};
        for (int i = 0; i < 2; i++) {
            TextView t = Ui.tv(this, names[i], 12, Ui.TXT, true);
            t.setLetterSpacing(.15f);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, Ui.dp(this, 14), 0, Ui.dp(this, 14));
            final int idx = i;
            t.setOnClickListener(v -> pager.setCurrentItem(idx, true));
            tabs[i] = t;
            bar.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        col.addView(bar, Ui.lp(this, -1, -2, 16, 6, 16, 12));
        paintTabs(0);
        host.addView(col, new FrameLayout.LayoutParams(-1, -1));
    }

    private void paintTabs(int sel) {
        for (int i = 0; i < 2; i++) {
            boolean on = i == sel;
            tabs[i].setBackground(on ? new CyberDrawable(this, Ui.YEL, Ui.YEL, 0, 0, 10, false) : null);
            tabs[i].setTextColor(on ? Ui.ON_ACC : Ui.TXT);
        }
    }
}

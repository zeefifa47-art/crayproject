package com.cray.hazi;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import java.util.List;

final class HomePage {
    static final String TIKTOK = "https://www.tiktok.com/@inihazi";
    static final String WA = "https://whatsapp.com/channel/0029VbDubQbHrDZYJiw3fC1s";

    static void open(Activity a, String url) {
        try { a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Throwable t) { Panels.toast(a, "Tidak bisa membuka tautan"); }
    }

    static View build(Activity a, Runnable goDonate) {
        ScrollView sv = new ScrollView(a);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout l = Ui.col(a);
        int p = Ui.dp(a, 20);
        l.setPadding(p, Ui.dp(a, 8), p, Ui.dp(a, 32));
        sv.addView(l);

        // Logo
        ImageView logo = new ImageView(a);
        logo.setImageResource(R.drawable.logo_drax);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        logo.setBackground(Ui.rect(a, Ui.SURF, 26));
        logo.setClipToOutline(true);
        l.addView(logo, new LinearLayout.LayoutParams(-1, Ui.dp(a, 190)));
        TextView sub = Ui.tv(a, "Panel crosshair, sensitivity, dan Pixel Lab untuk game pilihanmu.", 13, Ui.MUTED, false);
        sub.setLineSpacing(0, 1.15f);
        l.addView(sub, Ui.wrapLp(a, 12));

        LinearLayout inner = Ui.col(a);
        inner.setPadding(Ui.dp(a, 16), Ui.dp(a, 4), Ui.dp(a, 12), Ui.dp(a, 4));
        inner.setBackground(Ui.stroke(a, Ui.SURF, Ui.acc(0x88), 20));
        Switch[] sw = new Switch[1];
        View modeRow = Ui.switchRow(a, "Mode Game", "Tab panel muncul otomatis saat game yang ditambah dibuka",
                Prefs.b(a, Prefs.GAME_MODE, true) && Games.any(a), v -> {
                    if (v && !Games.any(a)) {
                        Panels.toast(a, "Tambah game dulu");
                        if (sw[0] != null) sw[0].setChecked(false);
                        return;
                    }
                    Prefs.put(a, Prefs.GAME_MODE, v);
                    if (v) GameService.start(a); else a.stopService(new Intent(a, GameService.class));
                });
        sw[0] = (Switch) ((LinearLayout) modeRow).getChildAt(1);
        inner.addView(modeRow);
        l.addView(inner, Ui.wrapLp(a, 4));

        LinearLayout chips = Ui.row(a);
        chips.addView(Ui.pill(a, "Shizuku aktif", 0x333DDC84, Ui.OK));
        chips.addView(Ui.pill(a, "Geser dari atas", Ui.acc(0x33), Ui.YEL), Ui.lp(a, -2, -2, 8, 0, 0, 0));
        chips.addView(Ui.pill(a, "Reset 5 menit", 0x33FFFFFF, Ui.TXT), Ui.lp(a, -2, -2, 8, 0, 0, 0));
        l.addView(chips, Ui.wrapLp(a, 14));

        // Game saya
        LinearLayout gc = Ui.card(a);
        LinearLayout gh = Ui.row(a);
        gh.addView(Ui.tv(a, "Game Saya", 18, Ui.TXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout gl = Ui.col(a);
        Runnable[] fill = new Runnable[1];
        TextView add = Ui.pill(a, "+ Tambah Game", Ui.YEL, Ui.ON_ACC);
        add.setOnClickListener(v -> GamePicker.show(a, () -> {
            fill[0].run();
            if (Games.any(a) && Prefs.b(a, Prefs.GAME_MODE, true)) GameService.start(a);
            sw[0].setChecked(Games.any(a) && Prefs.b(a, Prefs.GAME_MODE, true));
        }));
        Ui.press(add);
        gh.addView(add);
        gc.addView(gh);
        TextView gd = Ui.tv(a, "Tambah game dulu supaya panel aktif. Bisa game apa saja.", 12.5f, Ui.MUTED, false);
        gc.addView(gd, Ui.wrapLp(a, 6));
        gc.addView(gl, Ui.wrapLp(a, 6));
        fill[0] = () -> {
            gl.removeAllViews();
            List<String> gs = Games.list(a);
            if (gs.isEmpty()) {
                TextView e = Ui.tv(a, "Belum ada game.", 13, Ui.MUTED, true);
                e.setPadding(0, Ui.dp(a, 8), 0, Ui.dp(a, 4));
                gl.addView(e);
                return;
            }
            for (String pkg : gs) {
                LinearLayout r = Ui.row(a);
                r.setPadding(0, Ui.dp(a, 6), 0, Ui.dp(a, 6));
                ImageView iv = new ImageView(a);
                iv.setImageDrawable(Games.icon(a, pkg));
                r.addView(iv, new LinearLayout.LayoutParams(Ui.dp(a, 36), Ui.dp(a, 36)));
                TextView nm = Ui.tv(a, Games.label(a, pkg), 14, Ui.TXT, true);
                r.addView(nm, Ui.lp(a, 0, -2, 12, 0, 8, 0));
                ((LinearLayout.LayoutParams) nm.getLayoutParams()).weight = 1f;
                TextView rm = Ui.pill(a, "Hapus", 0x33FF5A5F, Ui.BAD);
                rm.setOnClickListener(v -> {
                    Games.remove(a, pkg);
                    fill[0].run();
                    if (!Games.any(a)) {
                        Prefs.put(a, Prefs.GAME_MODE, false);
                        a.stopService(new Intent(a, GameService.class));
                        sw[0].setChecked(false);
                    }
                });
                Ui.press(rm);
                r.addView(rm);
                gl.addView(r);
            }
        };
        fill[0].run();
        l.addView(gc, Ui.wrapLp(a, 16));

        // Pixel Lab
        boolean ok = Build.VERSION.SDK_INT >= 35;
        LinearLayout px = Ui.card(a);
        LinearLayout ph = Ui.row(a);
        ph.addView(Ui.tv(a, "Pixel Lab", 18, Ui.TXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        ph.addView(Ui.pill(a, ok ? "Android 15+" : "Terkunci", ok ? Ui.acc(0x33) : 0x33FF5A5F, ok ? Ui.YEL : Ui.BAD));
        px.addView(ph);
        TextView pd = Ui.tv(a, "Buat tekstur game jadi kotak-kotak ala retro. Ada gambar sampel sebelum dan sesudah.", 12.5f, Ui.MUTED, false);
        pd.setLineSpacing(0, 1.15f);
        px.addView(pd, Ui.wrapLp(a, 8));
        px.addView(Ui.button(a, ok ? "Buka Pixel Lab" : "Butuh Android 15 ke atas", ok, v -> {
            if (Build.VERSION.SDK_INT >= 35) a.startActivity(new Intent(a, PixelLabActivity.class));
            else Panels.toast(a, "Pixel Lab hanya untuk Android 15 ke atas");
        }), Ui.wrapLp(a, 12));
        l.addView(px, Ui.wrapLp(a, 16));

        // Tema warna
        LinearLayout th = Ui.card(a);
        th.addView(Ui.tv(a, "Tema Warna", 18, Ui.TXT, true));
        th.addView(Ui.tv(a, "Berlaku juga untuk panel di dalam game.", 12.5f, Ui.MUTED, false), Ui.wrapLp(a, 6));
        th.addView(Ui.chips(a, Ui.THEME_NAMES, Prefs.i(a, Prefs.THEME, 0), i -> {
            Prefs.put(a, Prefs.THEME, i);
            Ui.load(a);
            a.recreate();
        }), Ui.wrapLp(a, 12));
        l.addView(th, Ui.wrapLp(a, 16));

        // Pengaturan panel
        LinearLayout set = Ui.card(a);
        set.addView(Ui.tv(a, "Pengaturan Panel", 18, Ui.TXT, true));
        set.addView(Ui.tv(a, "Atur dari sini, atau geser tab Pengaturan Cepat di tengah atas layar saat di dalam game.", 12.5f, Ui.MUTED, false), Ui.wrapLp(a, 6));
        LinearLayout box = Ui.col(a);
        set.addView(Ui.chips(a, new String[]{"Crosshair", "Sensitivity", "Layar"}, 0, i -> {
            box.removeAllViews();
            box.addView(i == 0 ? Panels.crosshair(a) : i == 1 ? Panels.sensi(a) : Panels.display(a));
        }), Ui.wrapLp(a, 14));
        box.addView(Panels.crosshair(a));
        set.addView(box, Ui.wrapLp(a, 4));
        l.addView(set, Ui.wrapLp(a, 16));

        TextView rs = Ui.tv(a, "Semua fitur, termasuk Pixel Lab, otomatis kembali normal jika 5 menit tidak kembali ke game.", 11.5f, Ui.MUTED, false);
        rs.setLineSpacing(0, 1.2f);
        l.addView(rs, Ui.wrapLp(a, 14));

        l.addView(Ui.button(a, "Dukung DRAX lewat QRIS  >", false, v -> goDonate.run()), Ui.wrapLp(a, 16));

        LinearLayout links = Ui.row(a);
        links.addView(Ui.button(a, "by @inihazi", true, v -> open(a, TIKTOK)), new LinearLayout.LayoutParams(0, -2, 1f));
        links.addView(Ui.button(a, "Saluran WhatsApp", false, v -> open(a, WA)), Ui.lp(a, 0, -2, 10, 0, 0, 0));
        ((LinearLayout.LayoutParams) links.getChildAt(1).getLayoutParams()).weight = 1f;
        l.addView(links, Ui.wrapLp(a, 12));

        TextView foot = Ui.tv(a, "DRAX  •  by @inihazi", 11, Ui.MUTED, false);
        foot.setGravity(Gravity.CENTER);
        l.addView(foot, Ui.wrapLp(a, 20));
        return sv;
    }
}

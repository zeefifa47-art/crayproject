package com.cray.hazi;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import java.util.List;
import java.util.Locale;

final class HomePage {
    static final String TIKTOK = "https://www.tiktok.com/@inihazi";
    static final String WA = "https://whatsapp.com/channel/0029VbDubQbHrDZYJiw3fC1s";

    static void open(Activity a, String url) {
        try { a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Throwable t) { Panels.toast(a, "Tidak bisa membuka tautan"); }
    }

    /** Membuka game. Jika Pixel Lab sudah aktif dan belum direset, tekstur langsung diterapkan tanpa simpan ulang. */
    static void launch(Activity a, String pkg) {
        Intent i = a.getPackageManager().getLaunchIntentForPackage(pkg);
        if (i == null) { Panels.toast(a, "Game tidak ditemukan"); return; }
        Prefs.sp(a).edit().putString("last_game", pkg).apply();
        Prefs.put(a, Prefs.LEFT_AT, 0L);
        if (Prefs.b(a, Prefs.GAME_MODE, true)) GameService.start(a);
        boolean px = Build.VERSION.SDK_INT >= 35 && Prefs.b(a, Prefs.PX_APPLIED, false)
                && Prefs.b(a, "px_" + pkg, false) && Shell.ready();
        if (px) {
            Shell.async(() -> {
                Angle.applySaved(a);
                Shell.run("am force-stop " + pkg);
                a.runOnUiThread(() -> a.startActivity(i));
            });
        } else {
            a.startActivity(i);
        }
    }

    static void openSpace(Activity a, String pkg) {
        Prefs.sp(a).edit().putString("last_game", pkg).apply();
        a.startActivity(new Intent(a, GameSpaceActivity.class).putExtra("pkg", pkg));
    }

    private static boolean sysOk(Activity a) {
        return android.provider.Settings.canDrawOverlays(a) && android.provider.Settings.System.canWrite(a);
    }

    private static View tile(Activity a, String label, String value, boolean good) {
        LinearLayout t = Ui.col(a);
        t.setPadding(Ui.dp(a, 14), Ui.dp(a, 12), Ui.dp(a, 14), Ui.dp(a, 12));
        t.setBackground(Ui.glass(a, 18));
        t.addView(Ui.tv(a, label, 11, Ui.MUTED, false));
        LinearLayout r = Ui.row(a);
        r.addView(Ui.tv(a, "●", 10, good ? Ui.OK : Ui.BAD, true));
        r.addView(Ui.tv(a, value, 14, Ui.TXT, true), Ui.lp(a, -2, -2, 6, 0, 0, 0));
        t.addView(r, Ui.wrapLp(a, 6));
        return t;
    }

    static View build(Activity a, Runnable goDonate) {
        ScrollView sv = new ScrollView(a);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout l = Ui.col(a);
        int p = Ui.dp(a, 20);
        l.setPadding(p, Ui.dp(a, 14), p, Ui.dp(a, 24));
        sv.addView(l);

        // Header
        LinearLayout head = Ui.row(a);
        ImageView lg = new ImageView(a);
        lg.setImageResource(R.drawable.logo_drax);
        lg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        lg.setBackground(Ui.rect(a, Ui.SURF, 14));
        lg.setClipToOutline(true);
        head.addView(lg, new LinearLayout.LayoutParams(Ui.dp(a, 44), Ui.dp(a, 44)));
        LinearLayout tc = Ui.col(a);
        TextView title = Ui.tv(a, "DRAX", 20, Ui.TXT, true);
        title.setTypeface(Ui.brand(a));
        title.setLetterSpacing(.12f);
        tc.addView(title);
        tc.addView(Ui.tv(a, "Game space by @inihazi", 11.5f, Ui.MUTED, false), Ui.wrapLp(a, 2));
        head.addView(tc, Ui.lp(a, 0, -2, 12, 0, 8, 0));
        ((LinearLayout.LayoutParams) tc.getLayoutParams()).weight = 1f;
        head.addView(Ui.cbtn(a, "@inihazi", false, true, v -> open(a, TIKTOK)));
        l.addView(head);

        // Hero
        FrameLayout hero = new FrameLayout(a);
        hero.setBackground(Ui.rect(a, Ui.SURF, 28));
        hero.setClipToOutline(true);
        ImageView hi = new ImageView(a);
        hi.setImageResource(R.drawable.logo_drax);
        hi.setScaleType(ImageView.ScaleType.CENTER_CROP);
        hero.addView(hi, new FrameLayout.LayoutParams(-1, -1));
        View scrim = new View(a);
        scrim.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0x00000000, Ui.alpha(Ui.BG, 0xF2)}));
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-1, Ui.dp(a, 150));
        sp.gravity = Gravity.BOTTOM;
        hero.addView(scrim, sp);
        LinearLayout ht = Ui.col(a);
        ht.setPadding(Ui.dp(a, 20), 0, Ui.dp(a, 20), Ui.dp(a, 18));
        TextView big = Ui.tv(a, "", 26, Ui.TXT, true);
        TextView desc = Ui.tv(a, "", 12.5f, 0xCCF6F4EA, false);
        ht.addView(big);
        ht.addView(desc, Ui.wrapLp(a, 4));
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-1, -2);
        tp.gravity = Gravity.BOTTOM;
        hero.addView(ht, tp);
        l.addView(hero, Ui.lp(a, -1, Ui.dp(a, 210), 0, 16, 0, 0));

        // Status
        LinearLayout tiles = Ui.row(a);
        boolean sh = Shell.ready(), sys = sysOk(a), gfx = Build.VERSION.SDK_INT >= 35;
        tiles.addView(tile(a, "Shizuku", sh ? "Aktif" : "Mati", sh), new LinearLayout.LayoutParams(0, -2, 1f));
        tiles.addView(tile(a, "Izin sistem", sys ? "OK" : "Belum", sys), Ui.lp(a, 0, -2, 10, 0, 0, 0));
        tiles.addView(tile(a, "Grafik", gfx ? "Siap" : "Terkunci", gfx), Ui.lp(a, 0, -2, 10, 0, 0, 0));
        ((LinearLayout.LayoutParams) tiles.getChildAt(1).getLayoutParams()).weight = 1f;
        ((LinearLayout.LayoutParams) tiles.getChildAt(2).getLayoutParams()).weight = 1f;
        l.addView(tiles, Ui.wrapLp(a, 12));

        // Mode game
        Switch[] sw = new Switch[1];
        View modeRow = Ui.switchRow(a, "Mode game", "Panel muncul otomatis saat game dibuka",
                Prefs.b(a, Prefs.GAME_MODE, true) && Games.any(a), v -> {
                    if (v && !Games.any(a)) {
                        Panels.toast(a, "Tambah game dulu");
                        if (sw[0] != null) sw[0].setChecked(false);
                        return;
                    }
                    Prefs.put(a, Prefs.GAME_MODE, v);
                    if (v) GameService.start(a); else a.stopService(new Intent(a, GameService.class));
                });
        sw[0] = (Switch) ((LinearLayout) modeRow).getChildAt(1);
        LinearLayout mc = Ui.card(a);
        mc.setPadding(Ui.dp(a, 18), Ui.dp(a, 6), Ui.dp(a, 14), Ui.dp(a, 6));
        mc.addView(modeRow);
        l.addView(mc, Ui.wrapLp(a, 12));

        TextView go = Ui.cbtn(a, "Mulai main", true, false, v -> {
            List<String> gs = Games.list(a);
            if (gs.isEmpty()) { Panels.toast(a, "Tambah game dulu"); return; }
            String last = Prefs.sp(a).getString("last_game", gs.get(0));
            openSpace(a, gs.contains(last) ? last : gs.get(0));
        });
        l.addView(go, Ui.wrapLp(a, 12));

        // Game saya
        LinearLayout lh = Ui.row(a);
        lh.addView(Ui.tv(a, "Game saya", 18, Ui.TXT, true));
        TextView cnt = Ui.pill(a, "", 0x1FFFFFFF, Ui.MUTED);
        lh.addView(cnt, Ui.lp(a, -2, -2, 10, 0, 0, 0));
        View sp2 = new View(a);
        lh.addView(sp2, new LinearLayout.LayoutParams(0, 1, 1f));
        LinearLayout lib = Ui.col(a);
        Runnable[] fill = new Runnable[1];
        Runnable[] upd = new Runnable[1];
        Runnable add = () -> GamePicker.show(a, () -> {
            fill[0].run();
            upd[0].run();
            if (Games.any(a) && Prefs.b(a, Prefs.GAME_MODE, true)) GameService.start(a);
            sw[0].setChecked(Games.any(a) && Prefs.b(a, Prefs.GAME_MODE, true));
        });
        lh.addView(Ui.roundBtn(a, "+", 38, v -> add.run()));
        l.addView(lh, Ui.wrapLp(a, 24));
        l.addView(lib, Ui.wrapLp(a, 12));

        upd[0] = () -> {
            boolean any = Games.any(a);
            big.setText(any ? "Siap main" : "Mulai dari sini");
            desc.setText(any ? "Pilih game, atur panel, lalu Launch." : "Tambah game dulu supaya panel dan Pixel Lab bisa dipakai.");
            go.setAlpha(any ? 1f : .45f);
            cnt.setText(String.format(Locale.US, "%d/%d", Games.set(a).size(), Games.MAX));
        };
        fill[0] = () -> {
            lib.removeAllViews();
            List<String> gs = Games.list(a);
            if (gs.isEmpty()) {
                LinearLayout e = Ui.card(a);
                e.setGravity(Gravity.CENTER_HORIZONTAL);
                e.setPadding(Ui.dp(a, 20), Ui.dp(a, 26), Ui.dp(a, 20), Ui.dp(a, 22));
                TextView t = Ui.tv(a, "Belum ada game", 16, Ui.TXT, true);
                t.setGravity(Gravity.CENTER);
                e.addView(t);
                TextView d = Ui.tv(a, "Tambahkan game pertamamu untuk mulai memakai panel dan Pixel Lab.", 12.5f, Ui.MUTED, false);
                d.setGravity(Gravity.CENTER);
                e.addView(d, Ui.wrapLp(a, 6));
                e.addView(Ui.cbtn(a, "Tambah game", true, true, v -> add.run()), Ui.lp(a, -2, -2, 0, 16, 0, 0));
                lib.addView(e);
                return;
            }
            for (String pkg : gs) {
                LinearLayout card = Ui.col(a);
                card.setPadding(Ui.dp(a, 14), Ui.dp(a, 14), Ui.dp(a, 14), Ui.dp(a, 12));
                card.setBackground(Ui.glass(a, 22));
                LinearLayout top = Ui.row(a);
                top.addView(Ui.appIcon(a, pkg, 16), new LinearLayout.LayoutParams(Ui.dp(a, 56), Ui.dp(a, 56)));
                LinearLayout nm = Ui.col(a);
                nm.addView(Ui.tv(a, Games.label(a, pkg), 16, Ui.TXT, true));
                nm.addView(Ui.tv(a, pkg, 11, Ui.MUTED, false), Ui.wrapLp(a, 3));
                top.addView(nm, Ui.lp(a, 0, -2, 14, 0, 10, 0));
                ((LinearLayout.LayoutParams) nm.getLayoutParams()).weight = 1f;
                top.addView(Ui.roundBtn(a, "▶", 44, v -> openSpace(a, pkg)));
                card.addView(top);

                LinearLayout st = Ui.row(a);
                boolean pn = Prefs.b(a, "panel_" + pkg, false);
                st.addView(Ui.pill(a, pn ? "Panel aktif" : "Panel mati", pn ? Ui.acc(0x33) : 0x1FFFFFFF, pn ? Ui.YEL : Ui.MUTED));
                if (Prefs.b(a, Prefs.PX_APPLIED, false) && Prefs.b(a, "px_" + pkg, false))
                    st.addView(Ui.pill(a, "Pixel aktif", Ui.acc(0x33), Ui.YEL), Ui.lp(a, -2, -2, 8, 0, 0, 0));
                View fl = new View(a);
                st.addView(fl, new LinearLayout.LayoutParams(0, 1, 1f));
                TextView rm = Ui.tv(a, "Hapus", 12, Ui.BAD, true);
                rm.setPadding(Ui.dp(a, 10), Ui.dp(a, 6), Ui.dp(a, 4), Ui.dp(a, 6));
                boolean[] armed = {false};
                rm.setOnClickListener(v -> {
                    if (!armed[0]) {
                        armed[0] = true;
                        rm.setText("Yakin hapus?");
                        v.postDelayed(() -> { armed[0] = false; rm.setText("Hapus"); }, 2500);
                        return;
                    }
                    Games.remove(a, pkg);
                    fill[0].run();
                    upd[0].run();
                    if (!Games.any(a)) {
                        Prefs.put(a, Prefs.GAME_MODE, false);
                        a.stopService(new Intent(a, GameService.class));
                        sw[0].setChecked(false);
                    }
                });
                st.addView(rm);
                card.addView(st, Ui.wrapLp(a, 12));
                card.setOnClickListener(v -> openSpace(a, pkg));
                Ui.press(card);
                lib.addView(card, Ui.wrapLp(a, 10));
            }
        };
        fill[0].run();
        upd[0].run();

        // Tema warna
        LinearLayout th = Ui.card(a);
        LinearLayout thh = Ui.row(a);
        thh.addView(Ui.tv(a, "Tema warna", 15, Ui.TXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        int cur = Prefs.i(a, Prefs.THEME, 0);
        thh.addView(Ui.tv(a, Ui.THEME_NAMES[Math.max(0, Math.min(Ui.THEME_NAMES.length - 1, cur))], 12, Ui.MUTED, true));
        th.addView(thh);
        th.addView(Ui.tv(a, "Berlaku juga untuk panel di dalam game.", 12, Ui.MUTED, false), Ui.wrapLp(a, 4));
        LinearLayout dots = Ui.row(a);
        for (int i = 0; i < Ui.THEME_NAMES.length; i++) {
            final int idx = i;
            View d = new View(a);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(Ui.themeColor(i));
            if (i == cur) g.setStroke(Ui.dp(a, 3), Ui.TXT);
            d.setBackground(g);
            d.setOnClickListener(v -> {
                Prefs.put(a, Prefs.THEME, idx);
                Ui.load(a);
                a.recreate();
            });
            Ui.press(d);
            dots.addView(d, Ui.lp(a, Ui.dp(a, 36), Ui.dp(a, 36), 0, 0, 14, 0));
        }
        th.addView(dots, Ui.wrapLp(a, 14));
        l.addView(th, Ui.wrapLp(a, 14));

        l.addView(Ui.cbtn(a, "Saluran WhatsApp", false, false, v -> open(a, WA)), Ui.wrapLp(a, 12));
        TextView foot = Ui.tv(a, "DRAX · by @inihazi", 11.5f, Ui.MUTED, false);
        foot.setGravity(Gravity.CENTER);
        l.addView(foot, Ui.wrapLp(a, 18));
        return sv;
    }
}

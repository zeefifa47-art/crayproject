package com.cray.hazi;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import java.util.List;
import java.util.Locale;

final class HomePage {
    static final String TIKTOK = "https://www.tiktok.com/@inihazi";
    static final String WA = "https://whatsapp.com/channel/0029VbDubQbHrDZYJiw3fC1s";

    static void open(Activity a, String url) {
        try { a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Throwable t) { Panels.toast(a, "Tidak bisa membuka tautan"); }
    }

    static void launch(Activity a, String pkg) {
        Intent i = a.getPackageManager().getLaunchIntentForPackage(pkg);
        if (i == null) { Panels.toast(a, "Game tidak ditemukan"); return; }
        Prefs.sp(a).edit().putString("last_game", pkg).apply();
        if (Prefs.b(a, Prefs.GAME_MODE, true)) GameService.start(a);
        a.startActivity(i);
    }

    private static View row(Activity a, String label, String val, int color) {
        LinearLayout r = Ui.row(a);
        r.setPadding(0, Ui.dp(a, 7), 0, Ui.dp(a, 7));
        TextView k = Ui.tv(a, label, 11.5f, Ui.MUTED, true);
        k.setLetterSpacing(.15f);
        r.addView(k, new LinearLayout.LayoutParams(0, -2, 1f));
        r.addView(Ui.tv(a, "● " + val, 12, color, true));
        return r;
    }

    static View build(Activity a, Runnable goDonate) {
        ScrollView sv = new ScrollView(a);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout l = Ui.col(a);
        int p = Ui.dp(a, 16);
        l.setPadding(p, Ui.dp(a, 14), p, Ui.dp(a, 24));
        sv.addView(l);

        // Header
        LinearLayout head = Ui.row(a);
        ImageView lg = new ImageView(a);
        lg.setImageResource(R.drawable.logo_drax);
        lg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        lg.setBackground(Ui.rect(a, Ui.SURF, 12));
        lg.setClipToOutline(true);
        head.addView(lg, new LinearLayout.LayoutParams(Ui.dp(a, 52), Ui.dp(a, 52)));
        LinearLayout tc = Ui.col(a);
        TextView title = Ui.tv(a, "DRAX", 22, Ui.TXT, true);
        title.setTypeface(Ui.brand(a));
        title.setLetterSpacing(.25f);
        tc.addView(title);
        TextView subt = Ui.tv(a, "GAME SPACE // by @inihazi // v1.0.0", 9, Ui.YEL, true);
        subt.setLetterSpacing(.1f);
        tc.addView(subt, Ui.wrapLp(a, 4));
        head.addView(tc, Ui.lp(a, 0, -2, 12, 0, 8, 0));
        ((LinearLayout.LayoutParams) tc.getLayoutParams()).weight = 1f;
        head.addView(Ui.cbtn(a, "♪ @inihazi", false, true, v -> open(a, TIKTOK)));
        l.addView(head);

        // System status
        LinearLayout st = Ui.col(a);
        st.setPadding(Ui.dp(a, 20), Ui.dp(a, 18), Ui.dp(a, 20), Ui.dp(a, 18));
        st.setBackground(new CyberDrawable(a, Ui.SURF, Ui.SURF, Ui.acc(0xCC), 2, 16, false));
        st.addView(Ui.cap(a, "SYSTEM STATUS"));
        TextView big = Ui.tv(a, "", 28, Ui.YEL, true);
        big.setTypeface(Ui.brand(a));
        st.addView(big, Ui.wrapLp(a, 6));
        TextView desc = Ui.tv(a, "", 12.5f, Ui.MUTED, false);
        st.addView(desc, Ui.wrapLp(a, 4));
        View div = new View(a);
        div.setBackgroundColor(Ui.LINE);
        st.addView(div, Ui.lp(a, -1, 1, 0, 14, 0, 6));
        boolean sys = Settings_ok(a);
        st.addView(row(a, "SHIZUKU", Shell.ready() ? "AKTIF" : "MATI", Shell.ready() ? Ui.YEL : Ui.BAD));
        st.addView(row(a, "IZIN SISTEM", sys ? "OK" : "BELUM", sys ? Ui.YEL : Ui.BAD));
        boolean gfx = Build.VERSION.SDK_INT >= 35;
        st.addView(row(a, "GRAFIK", gfx ? "SIAP" : "TERKUNCI", gfx ? Ui.YEL : Ui.BAD));

        Switch[] sw = new Switch[1];
        View modeRow = Ui.switchRow(a, "Mode Game", "Tab panel muncul otomatis saat game dibuka",
                Prefs.b(a, Prefs.GAME_MODE, true) && Games.any(a), v -> {
                    if (v && !Games.any(a)) {
                        Panels.toast(a, "Tambah game dulu");
                        if (sw[0] != null) sw[0].setChecked(false);
                        return;
                    }
                    Prefs.put(a, Prefs.GAME_MODE, v);
                    if (v) GameService.start(a); else a.stopService(new Intent(a, GameService.class));
                });
        sw[0] = (Switch) ((LinearLayout) modeRow).getChildAt(1);
        st.addView(modeRow, Ui.wrapLp(a, 6));

        TextView gas = Ui.cbtn(a, "GAS MAIN", true, false, v -> {
            List<String> gs = Games.list(a);
            if (gs.isEmpty()) { Panels.toast(a, "Tambah game dulu"); return; }
            String last = Prefs.sp(a).getString("last_game", gs.get(0));
            launch(a, gs.contains(last) ? last : gs.get(0));
        });
        st.addView(gas, Ui.wrapLp(a, 12));
        l.addView(st, Ui.wrapLp(a, 18));

        // Game library
        LinearLayout lh = Ui.row(a);
        View bar = new View(a);
        bar.setBackgroundColor(Ui.YEL);
        lh.addView(bar, new LinearLayout.LayoutParams(Ui.dp(a, 4), Ui.dp(a, 20)));
        TextView lt = Ui.tv(a, "GAME LIBRARY", 15, Ui.TXT, true);
        lt.setLetterSpacing(.15f);
        lh.addView(lt, Ui.lp(a, -2, -2, 10, 0, 0, 0));
        TextView cnt = Ui.tv(a, "", 11, Ui.MUTED, true);
        lh.addView(cnt, Ui.lp(a, 0, -2, 10, 0, 0, 0));
        ((LinearLayout.LayoutParams) cnt.getLayoutParams()).weight = 1f;
        LinearLayout lib = Ui.col(a);
        Runnable[] fill = new Runnable[1];
        Runnable[] upd = new Runnable[1];
        lh.addView(Ui.cbtn(a, "+ Tambah", false, true, v -> GamePicker.show(a, () -> {
            fill[0].run();
            upd[0].run();
            if (Games.any(a) && Prefs.b(a, Prefs.GAME_MODE, true)) GameService.start(a);
            sw[0].setChecked(Games.any(a) && Prefs.b(a, Prefs.GAME_MODE, true));
        })));
        l.addView(lh, Ui.wrapLp(a, 4));
        l.addView(lib, Ui.wrapLp(a, 12));

        upd[0] = () -> {
            boolean any = Games.any(a);
            big.setText(any ? "SIAP MAIN" : "TAMBAH GAME");
            desc.setText(any ? "Semua izin aktif. Pilih game lalu tekan Launch." : "Tambah game dulu di Game Library, baru bisa main.");
            gas.setAlpha(any ? 1f : .45f);
            cnt.setText(String.format(Locale.US, "%02d / %d", Games.set(a).size(), Games.MAX));
        };
        fill[0] = () -> {
            lib.removeAllViews();
            List<String> gs = Games.list(a);
            if (gs.isEmpty()) {
                LinearLayout e = Ui.col(a);
                e.setPadding(Ui.dp(a, 18), Ui.dp(a, 22), Ui.dp(a, 18), Ui.dp(a, 22));
                e.setBackground(new CyberDrawable(a, Ui.SURF, Ui.SURF, Ui.LINE, 1, 12, false));
                e.addView(Ui.tv(a, "Belum ada game. Tekan + TAMBAH untuk menambah game pertamamu.", 13, Ui.MUTED, true));
                lib.addView(e);
                return;
            }
            for (String pkg : gs) {
                LinearLayout card = Ui.row(a);
                card.setPadding(Ui.dp(a, 16), Ui.dp(a, 14), Ui.dp(a, 16), Ui.dp(a, 14));
                card.setBackground(new CyberDrawable(a, Ui.SURF2, Ui.alpha(Ui.YEL, 0x55), Ui.acc(0xAA), 1.5f, 14, true));
                LinearLayout left = Ui.col(a);
                left.addView(Ui.cap(a, "GAME"));
                left.addView(Ui.tv(a, Games.label(a, pkg), 20, Ui.TXT, true), Ui.wrapLp(a, 4));
                left.addView(Ui.tv(a, pkg, 10, Ui.MUTED, false), Ui.wrapLp(a, 2));
                LinearLayout br = Ui.row(a);
                br.addView(Ui.cbtn(a, "Launch", true, true, v -> launch(a, pkg)));
                TextView rm = Ui.tv(a, "HAPUS", 11, Ui.BAD, true);
                rm.setPadding(Ui.dp(a, 14), Ui.dp(a, 9), Ui.dp(a, 8), Ui.dp(a, 9));
                rm.setOnClickListener(v -> {
                    Games.remove(a, pkg);
                    fill[0].run();
                    upd[0].run();
                    if (!Games.any(a)) {
                        Prefs.put(a, Prefs.GAME_MODE, false);
                        a.stopService(new Intent(a, GameService.class));
                        sw[0].setChecked(false);
                    }
                });
                br.addView(rm);
                left.addView(br, Ui.wrapLp(a, 14));
                card.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));
                ImageView iv = new ImageView(a);
                iv.setImageDrawable(Games.icon(a, pkg));
                iv.setPadding(Ui.dp(a, 3), Ui.dp(a, 3), Ui.dp(a, 3), Ui.dp(a, 3));
                iv.setBackground(new CyberDrawable(a, 0x33000000, 0x33000000, Ui.YEL, 1.5f, 8, false));
                LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(Ui.dp(a, 66), Ui.dp(a, 66));
                ip.gravity = Gravity.TOP;
                card.addView(iv, ip);
                card.setOnClickListener(v -> {
                    Prefs.sp(a).edit().putString("last_game", pkg).apply();
                    a.startActivity(new Intent(a, GameSpaceActivity.class).putExtra("pkg", pkg));
                });
                Ui.press(card);
                lib.addView(card, Ui.wrapLp(a, 10));
            }
        };
        fill[0].run();
        upd[0].run();

        // Tema
        LinearLayout th = Ui.col(a);
        th.setPadding(Ui.dp(a, 16), Ui.dp(a, 14), Ui.dp(a, 16), Ui.dp(a, 14));
        th.setBackground(new CyberDrawable(a, Ui.SURF, Ui.SURF, Ui.LINE, 1, 12, false));
        th.addView(Ui.cap(a, "TEMA WARNA"));
        th.addView(Ui.tv(a, "Berlaku juga untuk panel di dalam game.", 12, Ui.MUTED, false), Ui.wrapLp(a, 4));
        th.addView(Ui.chips(a, Ui.THEME_NAMES, Prefs.i(a, Prefs.THEME, 0), i -> {
            Prefs.put(a, Prefs.THEME, i);
            Ui.load(a);
            a.recreate();
        }), Ui.wrapLp(a, 12));
        l.addView(th, Ui.wrapLp(a, 14));

        l.addView(Ui.cbtn(a, "Saluran WhatsApp", false, false, v -> open(a, WA)), Ui.wrapLp(a, 14));
        TextView foot = Ui.tv(a, "DRAX  •  by @inihazi", 11, Ui.MUTED, false);
        foot.setGravity(Gravity.CENTER);
        l.addView(foot, Ui.wrapLp(a, 18));
        return sv;
    }

    private static boolean Settings_ok(Activity a) {
        return android.provider.Settings.canDrawOverlays(a) && android.provider.Settings.System.canWrite(a);
    }
}

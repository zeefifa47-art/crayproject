package com.cray.hazi;

import android.content.ContentResolver;
import android.content.Context;
import android.content.res.Resources;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** Isi panel fitur, dipakai di aplikasi dan di panel dalam game. */
final class Panels {
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    static void toast(Context c, String s) {
        MAIN.post(() -> Toast.makeText(c.getApplicationContext(), s, Toast.LENGTH_SHORT).show());
    }

    // ---------- Crosshair ----------

    private static View chSwitch(Context c) {
        return Ui.switchRow(c, "Crosshair", "Titik bidik di tengah layar saat bermain",
                Prefs.b(c, Prefs.CH_ON, false), v -> Prefs.put(c, Prefs.CH_ON, v));
    }
    private static View chStyle(Context c) {
        return Ui.chips(c, new String[]{"Titik", "Plus", "Lingkaran", "Bidik"},
                Prefs.i(c, Prefs.CH_STYLE, 1), i -> Prefs.put(c, Prefs.CH_STYLE, i));
    }
    private static View chColor(Context c) {
        return Ui.chips(c, new String[]{"Kuning", "Merah", "Hijau", "Putih", "Cyan"},
                Prefs.i(c, Prefs.CH_COLOR, 0), i -> Prefs.put(c, Prefs.CH_COLOR, i));
    }
    private static void chSliders(Context c, LinearLayout l) {
        l.addView(Ui.slider(c, "Ukuran", 8, 90, Prefs.i(c, Prefs.CH_SIZE, 28), " dp", v -> Prefs.put(c, Prefs.CH_SIZE, v)));
        l.addView(Ui.slider(c, "Transparansi", 20, 100, Prefs.i(c, Prefs.CH_ALPHA, 90), "%", v -> Prefs.put(c, Prefs.CH_ALPHA, v)));
        l.addView(Ui.slider(c, "Geser kiri / kanan", -80, 80, Prefs.i(c, Prefs.CH_DX, 0), "", v -> Prefs.put(c, Prefs.CH_DX, v)));
        l.addView(Ui.slider(c, "Geser atas / bawah", -80, 80, Prefs.i(c, Prefs.CH_DY, 0), "", v -> Prefs.put(c, Prefs.CH_DY, v)));
    }

    static View crosshair(Context c) {
        LinearLayout l = Ui.col(c);
        l.addView(chSwitch(c));
        l.addView(Ui.section(c, "Gaya"));
        l.addView(chStyle(c));
        l.addView(Ui.section(c, "Warna"));
        l.addView(chColor(c));
        l.addView(Ui.section(c, "Ukuran dan posisi"));
        chSliders(c, l);
        return l;
    }

    /** Dua kolom, untuk panel dalam game. */
    static View crosshairWide(Context c) {
        LinearLayout h = Ui.row(c);
        h.setGravity(Gravity.TOP);
        LinearLayout a = Ui.col(c), b = Ui.col(c);
        a.addView(chSwitch(c));
        a.addView(Ui.section(c, "Gaya"));
        a.addView(chStyle(c));
        a.addView(Ui.section(c, "Warna"));
        a.addView(chColor(c));
        chSliders(c, b);
        h.addView(a, new LinearLayout.LayoutParams(0, -2, 1f));
        h.addView(b, Ui.lp(c, 0, -2, 18, 0, 0, 0));
        ((LinearLayout.LayoutParams) b.getLayoutParams()).weight = 1f;
        return h;
    }

    // ---------- Sensitivity ----------

    static View pointer(Context c) {
        LinearLayout l = Ui.col(c);
        ContentResolver cr = c.getContentResolver();
        int cur;
        try { cur = Settings.System.getInt(cr, "pointer_speed", 0); } catch (Throwable t) { cur = 0; }
        int v0 = Math.max(1, Math.min(10, Math.round((cur + 7) * 9f / 14f + 1)));
        l.addView(Ui.slider(c, "Kecepatan pointer", 1, 10, v0, "", v -> {
            if (!Settings.System.canWrite(c)) { toast(c, "Izin ubah sistem belum diberikan"); return; }
            try {
                if (Prefs.i(c, Prefs.PTR_ORIG, -99) == -99)
                    Prefs.put(c, Prefs.PTR_ORIG, Settings.System.getInt(cr, "pointer_speed", 0));
                Settings.System.putInt(cr, "pointer_speed", Math.round(-7f + (v - 1) * 14f / 9f));
            } catch (Throwable t) { toast(c, "Gagal mengubah"); }
        }));
        TextView n = Ui.tv(c, "1 = pelan, 10 = cepat. Hanya setelan sistem, tidak menyentuh file game.", 11, Ui.MUTED, false);
        l.addView(n, Ui.wrapLp(c, 2));
        return l;
    }

    static View sensi(Context c) {
        LinearLayout l = Ui.col(c);
        l.addView(Ui.section(c, "Pointer"));
        l.addView(pointer(c));
        if (Prefs.i(c, Prefs.DPI_APPLIED, 0) == 0)
            Prefs.put(c, Prefs.DPI_BASE, Resources.getSystem().getDisplayMetrics().densityDpi);
        int base = Prefs.i(c, Prefs.DPI_BASE, 420);
        int cur = Prefs.i(c, Prefs.DPI_APPLIED, 0) != 0 ? Prefs.i(c, Prefs.DPI_APPLIED, base) : base;
        int[] pick = {cur};

        l.addView(Ui.section(c, "DPI layar"));
        l.addView(Ui.slider(c, "DPI (bawaan " + base + ")", 280, 640, cur, "", v -> pick[0] = v));
        LinearLayout btns = Ui.row(c);
        btns.addView(Ui.button(c, "Terapkan DPI", true, v -> Shell.async(() -> {
            if (!Shell.ready()) { toast(c, "Shizuku belum aktif"); return; }
            Shell.run("wm density " + pick[0]);
            Prefs.put(c, Prefs.DPI_APPLIED, pick[0]);
            toast(c, "DPI " + pick[0] + " diterapkan");
        })), new LinearLayout.LayoutParams(0, -2, 1f));
        btns.addView(Ui.button(c, "Reset", false, v -> Shell.async(() -> {
            if (Shell.ready()) Shell.run("wm density reset");
            Prefs.put(c, Prefs.DPI_APPLIED, 0);
            toast(c, "DPI dikembalikan");
        })), Ui.lp(c, 0, -2, 8, 0, 0, 0));
        ((LinearLayout.LayoutParams) btns.getChildAt(1).getLayoutParams()).weight = 1f;
        l.addView(btns, Ui.wrapLp(c, 6));
        TextView warn = Ui.tv(c, "DPI mengubah skala tampilan sehingga rasa sentuh ikut berubah. Kembali normal otomatis jika 5 menit tidak masuk game.", 11, Ui.MUTED, false);
        warn.setPadding(0, Ui.dp(c, 8), 0, 0);
        l.addView(warn);

        l.addView(Ui.section(c, "Saran sensitivity dalam game"));
        LinearLayout table = Ui.col(c);
        Runnable fill = () -> {
            table.removeAllViews();
            int[] vals = SensiCalc.values(Prefs.i(c, Prefs.SENSI_STYLE, 1), Prefs.i(c, Prefs.SENSI_BOOST, 0));
            for (int i = 0; i < vals.length; i++) {
                LinearLayout r = Ui.row(c);
                r.setPadding(Ui.dp(c, 12), Ui.dp(c, 9), Ui.dp(c, 12), Ui.dp(c, 9));
                r.setBackground(Ui.rect(c, i % 2 == 0 ? Ui.SURF2 : Ui.SURF, 10));
                r.addView(Ui.tv(c, SensiCalc.NAMES[i], 13, Ui.TXT, false), new LinearLayout.LayoutParams(0, -2, 1f));
                r.addView(Ui.tv(c, String.valueOf(vals[i]), 14, Ui.YEL, true));
                table.addView(r);
            }
        };
        fill.run();
        l.addView(Ui.chips(c, SensiCalc.STYLES, Prefs.i(c, Prefs.SENSI_STYLE, 1), i -> { Prefs.put(c, Prefs.SENSI_STYLE, i); fill.run(); }));
        l.addView(Ui.slider(c, "Naik / turun semua", -10, 10, Prefs.i(c, Prefs.SENSI_BOOST, 0), "", v -> { Prefs.put(c, Prefs.SENSI_BOOST, v); fill.run(); }));
        l.addView(table, Ui.wrapLp(c, 4));
        TextView note = Ui.tv(c, "Titik awal saja. Masukkan angka ini di pengaturan sensitivitas dalam game, lalu sesuaikan sendiri.", 11, Ui.MUTED, false);
        note.setPadding(0, Ui.dp(c, 8), 0, 0);
        l.addView(note);
        return l;
    }

    // ---------- Layar dan suara ----------

    static View brightness(Context c) {
        ContentResolver cr = c.getContentResolver();
        int br;
        try { br = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS); } catch (Exception e) { br = 128; }
        return Ui.slider(c, "Kecerahan", 1, 255, br, "", v -> {
            if (!Settings.System.canWrite(c)) { toast(c, "Izin ubah sistem belum diberikan"); return; }
            try {
                if (Prefs.i(c, Prefs.BR_ORIG, -1) < 0) {
                    Prefs.put(c, Prefs.BR_MODE, Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, 0));
                    Prefs.put(c, Prefs.BR_ORIG, Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128));
                }
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, 0);
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, v);
            } catch (Throwable t) { toast(c, "Gagal mengubah kecerahan"); }
        });
    }

    static View audio(Context c) {
        AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
        int max = Math.max(1, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        return Ui.slider(c, "Volume media", 0, max, am.getStreamVolume(AudioManager.STREAM_MUSIC), "", v -> {
            try {
                if (Prefs.i(c, Prefs.VOL_ORIG, -1) < 0)
                    Prefs.put(c, Prefs.VOL_ORIG, am.getStreamVolume(AudioManager.STREAM_MUSIC));
                am.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0);
            } catch (Throwable t) { toast(c, "Gagal mengubah volume"); }
        });
    }

    static View display(Context c) {
        LinearLayout l = Ui.col(c);
        l.addView(brightness(c));
        l.addView(audio(c));
        l.addView(Ui.button(c, "Kembalikan kecerahan, suara, Hz", false, v -> {
            Shell.async(() -> Resetter.restoreDisplay(c));
            toast(c, "Dikembalikan ke semula");
        }), Ui.wrapLp(c, 10));
        return l;
    }

    // ---------- Refresh rate ----------

    static void applyHz(Context c, int hz) {
        if (!Settings.System.canWrite(c)) { toast(c, "Izin ubah sistem belum diberikan"); return; }
        ContentResolver cr = c.getContentResolver();
        try {
            if (!Prefs.b(c, Prefs.HZ_SET, false)) {
                Prefs.putF(c, Prefs.HZ_PEAK0, Settings.System.getFloat(cr, "peak_refresh_rate", 0f));
                Prefs.putF(c, Prefs.HZ_MIN0, Settings.System.getFloat(cr, "min_refresh_rate", 0f));
                Prefs.put(c, Prefs.HZ_SET, true);
            }
            Settings.System.putFloat(cr, "min_refresh_rate", hz);
            Settings.System.putFloat(cr, "peak_refresh_rate", hz);
        } catch (Throwable t) { toast(c, "Gagal mengubah refresh rate"); }
    }

    // ---------- Tampilan kompak untuk panel dalam game ----------

    private static View chColorDots(Context c) {
        LinearLayout row = Ui.row(c);
        View[] ds = new View[CrosshairView.COLORS.length];
        int[] cur = {Prefs.i(c, Prefs.CH_COLOR, 0)};
        Runnable paint = () -> {
            for (int i = 0; i < ds.length; i++) {
                GradientDrawable g = new GradientDrawable();
                g.setShape(GradientDrawable.OVAL);
                g.setColor(CrosshairView.COLORS[i]);
                g.setStroke(Ui.dp(c, i == cur[0] ? 2.5f : 1), i == cur[0] ? 0xFFFFFFFF : 0x55FFFFFF);
                ds[i].setBackground(g);
            }
        };
        for (int i = 0; i < ds.length; i++) {
            View d = new View(c);
            final int idx = i;
            d.setOnClickListener(v -> { cur[0] = idx; Prefs.put(c, Prefs.CH_COLOR, idx); paint.run(); });
            ds[i] = d;
            row.addView(d, Ui.lp(c, Ui.dp(c, 26), Ui.dp(c, 26), 0, 0, 8, 0));
        }
        paint.run();
        return row;
    }

    static View crosshairSide(Context c) {
        LinearLayout l = Ui.col(c);
        l.addView(chSwitch(c));
        l.addView(Ui.chipsCompact(c, new String[]{"Titik", "Plus", "Cincin", "Bidik"}, Prefs.i(c, Prefs.CH_STYLE, 1),
                i -> Prefs.put(c, Prefs.CH_STYLE, i)), Ui.wrapLp(c, 4));
        l.addView(chColorDots(c), Ui.wrapLp(c, 12));
        chSliders(c, l);
        return l;
    }

    static View crosshairCompact(Context c) {
        LinearLayout l = Ui.col(c);
        LinearLayout r1 = Ui.row(c);
        r1.addView(Ui.switchRow(c, "Crosshair", null, Prefs.b(c, Prefs.CH_ON, false), v -> Prefs.put(c, Prefs.CH_ON, v)),
                new LinearLayout.LayoutParams(Ui.dp(c, 150), -2));
        r1.addView(Ui.chipsCompact(c, new String[]{"Titik", "Plus", "Cincin", "Bidik"}, Prefs.i(c, Prefs.CH_STYLE, 1),
                i -> Prefs.put(c, Prefs.CH_STYLE, i)), Ui.lp(c, 0, -2, 12, 0, 12, 0));
        ((LinearLayout.LayoutParams) r1.getChildAt(1).getLayoutParams()).weight = 1f;
        r1.addView(chColorDots(c));
        l.addView(r1);
        LinearLayout g = Ui.row(c);
        g.setGravity(Gravity.TOP);
        LinearLayout a = Ui.col(c), b = Ui.col(c);
        a.addView(Ui.slider(c, "Ukuran", 8, 90, Prefs.i(c, Prefs.CH_SIZE, 28), " dp", v -> Prefs.put(c, Prefs.CH_SIZE, v)));
        a.addView(Ui.slider(c, "Transparansi", 20, 100, Prefs.i(c, Prefs.CH_ALPHA, 90), "%", v -> Prefs.put(c, Prefs.CH_ALPHA, v)));
        b.addView(Ui.slider(c, "Geser kiri / kanan", -80, 80, Prefs.i(c, Prefs.CH_DX, 0), "", v -> Prefs.put(c, Prefs.CH_DX, v)));
        b.addView(Ui.slider(c, "Geser atas / bawah", -80, 80, Prefs.i(c, Prefs.CH_DY, 0), "", v -> Prefs.put(c, Prefs.CH_DY, v)));
        g.addView(a, new LinearLayout.LayoutParams(0, -2, 1f));
        g.addView(b, Ui.lp(c, 0, -2, 20, 0, 0, 0));
        ((LinearLayout.LayoutParams) b.getLayoutParams()).weight = 1f;
        l.addView(g, Ui.wrapLp(c, 4));
        return l;
    }

    static View sensiCompact(Context c) {
        if (Prefs.i(c, Prefs.DPI_APPLIED, 0) == 0)
            Prefs.put(c, Prefs.DPI_BASE, Resources.getSystem().getDisplayMetrics().densityDpi);
        int base = Prefs.i(c, Prefs.DPI_BASE, 420);
        int cur = Prefs.i(c, Prefs.DPI_APPLIED, 0) != 0 ? Prefs.i(c, Prefs.DPI_APPLIED, base) : base;
        int[] pick = {cur};

        LinearLayout h = Ui.row(c);
        h.setGravity(Gravity.TOP);
        LinearLayout left = Ui.col(c), right = Ui.col(c);

        left.addView(pointer(c));
        left.addView(Ui.slider(c, "DPI layar (bawaan " + base + ")", 280, 640, cur, "", v -> pick[0] = v));
        LinearLayout btns = Ui.row(c);
        btns.addView(Ui.cbtn(c, "Terapkan", true, true, v -> Shell.async(() -> {
            if (!Shell.ready()) { toast(c, "Shizuku belum aktif"); return; }
            Shell.run("wm density " + pick[0]);
            Prefs.put(c, Prefs.DPI_APPLIED, pick[0]);
            toast(c, "DPI " + pick[0] + " diterapkan");
        })), new LinearLayout.LayoutParams(0, -2, 1f));
        btns.addView(Ui.cbtn(c, "Reset DPI", false, true, v -> Shell.async(() -> {
            if (Shell.ready()) Shell.run("wm density reset");
            Prefs.put(c, Prefs.DPI_APPLIED, 0);
            toast(c, "DPI dikembalikan");
        })), Ui.lp(c, 0, -2, 8, 0, 0, 0));
        ((LinearLayout.LayoutParams) btns.getChildAt(1).getLayoutParams()).weight = 1f;
        left.addView(btns, Ui.wrapLp(c, 6));

        LinearLayout table = Ui.col(c);
        Runnable fill = () -> {
            table.removeAllViews();
            int[] vals = SensiCalc.values(Prefs.i(c, Prefs.SENSI_STYLE, 1), Prefs.i(c, Prefs.SENSI_BOOST, 0));
            for (int r = 0; r < 3; r++) {
                LinearLayout row = Ui.row(c);
                for (int k = 0; k < 2; k++) {
                    int i = r * 2 + k;
                    LinearLayout cell = Ui.row(c);
                    cell.setPadding(Ui.dp(c, 10), Ui.dp(c, 7), Ui.dp(c, 10), Ui.dp(c, 7));
                    cell.setBackground(Ui.glass(c, 10));
                    cell.addView(Ui.tv(c, SensiCalc.NAMES[i], 11.5f, Ui.MUTED, false), new LinearLayout.LayoutParams(0, -2, 1f));
                    cell.addView(Ui.tv(c, String.valueOf(vals[i]), 13, Ui.YEL, true));
                    row.addView(cell, Ui.lp(c, 0, -2, k == 0 ? 0 : 6, 0, 0, 0));
                    ((LinearLayout.LayoutParams) cell.getLayoutParams()).weight = 1f;
                }
                table.addView(row, Ui.wrapLp(c, r == 0 ? 0 : 6));
            }
        };
        fill.run();
        TextView t = Ui.tv(c, "Saran sensitivity dalam game", 12, Ui.MUTED, true);
        right.addView(t);
        right.addView(Ui.chipsCompact(c, SensiCalc.STYLES, Prefs.i(c, Prefs.SENSI_STYLE, 1), i -> { Prefs.put(c, Prefs.SENSI_STYLE, i); fill.run(); }), Ui.wrapLp(c, 8));
        right.addView(Ui.slider(c, "Naik / turun semua", -10, 10, Prefs.i(c, Prefs.SENSI_BOOST, 0), "", v -> { Prefs.put(c, Prefs.SENSI_BOOST, v); fill.run(); }));
        right.addView(table, Ui.wrapLp(c, 4));

        h.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));
        h.addView(right, Ui.lp(c, 0, -2, 20, 0, 0, 0));
        ((LinearLayout.LayoutParams) right.getLayoutParams()).weight = 1f;
        return h;
    }
}

package com.cray.hazi;

import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.display.DisplayManager;
import android.view.Display;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** Isi panel fitur, dipakai di aplikasi dan di panel dalam game. */
final class Panels {
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    static void toast(Context c, String s) {
        MAIN.post(() -> Toast.makeText(c.getApplicationContext(), s, Toast.LENGTH_SHORT).show());
    }

    // ---------- Crosshair ----------

    private static View chSwitch(Context c) {
        return Ui.switchRow(c, "Crosshair", "Titik bidik di tengah layar saat bermain",
                Prefs.b(c, Prefs.CH_ON, false), v -> Prefs.put(c, Prefs.CH_ON, v));
    }
    private static View chStyle(Context c) {
        return Ui.chips(c, new String[]{"Titik", "Plus", "Lingkaran", "Bidik"},
                Prefs.i(c, Prefs.CH_STYLE, 1), i -> Prefs.put(c, Prefs.CH_STYLE, i));
    }
    private static View chColor(Context c) {
        return Ui.chips(c, new String[]{"Kuning", "Merah", "Hijau", "Putih", "Cyan"},
                Prefs.i(c, Prefs.CH_COLOR, 0), i -> Prefs.put(c, Prefs.CH_COLOR, i));
    }
    private static void chSliders(Context c, LinearLayout l) {
        l.addView(Ui.slider(c, "Ukuran", 8, 90, Prefs.i(c, Prefs.CH_SIZE, 28), " dp", v -> Prefs.put(c, Prefs.CH_SIZE, v)));
        l.addView(Ui.slider(c, "Transparansi", 20, 100, Prefs.i(c, Prefs.CH_ALPHA, 90), "%", v -> Prefs.put(c, Prefs.CH_ALPHA, v)));
        l.addView(Ui.slider(c, "Geser kiri / kanan", -80, 80, Prefs.i(c, Prefs.CH_DX, 0), "", v -> Prefs.put(c, Prefs.CH_DX, v)));
        l.addView(Ui.slider(c, "Geser atas / bawah", -80, 80, Prefs.i(c, Prefs.CH_DY, 0), "", v -> Prefs.put(c, Prefs.CH_DY, v)));
    }

    static View crosshair(Context c) {
        LinearLayout l = Ui.col(c);
        l.addView(chSwitch(c));
        l.addView(Ui.section(c, "Gaya"));
        l.addView(chStyle(c));
        l.addView(Ui.section(c, "Warna"));
        l.addView(chColor(c));
        l.addView(Ui.section(c, "Ukuran dan posisi"));
        chSliders(c, l);
        return l;
    }

    /** Dua kolom, untuk panel dalam game. */
    static View crosshairWide(Context c) {
        LinearLayout h = Ui.row(c);
        h.setGravity(Gravity.TOP);
        LinearLayout a = Ui.col(c), b = Ui.col(c);
        a.addView(chSwitch(c));
        a.addView(Ui.section(c, "Gaya"));
        a.addView(chStyle(c));
        a.addView(Ui.section(c, "Warna"));
        a.addView(chColor(c));
        chSliders(c, b);
        h.addView(a, new LinearLayout.LayoutParams(0, -2, 1f));
        h.addView(b, Ui.lp(c, 0, -2, 18, 0, 0, 0));
        ((LinearLayout.LayoutParams) b.getLayoutParams()).weight = 1f;
        return h;
    }

    // ---------- Sensitivity ----------

    /** Sensitivitas sentuh: X dan Y, 0 = normal sampai 10 = tertinggi. */
    static View sensi(Context c) {
        LinearLayout l = Ui.col(c);
        l.addView(Ui.slider(c, "Sensi X (kiri / kanan)", 0, 10, Prefs.i(c, Prefs.SENSI_X, 0), "", v -> Prefs.put(c, Prefs.SENSI_X, v)));
        l.addView(Ui.slider(c, "Sensi Y (atas / bawah)", 0, 10, Prefs.i(c, Prefs.SENSI_Y, 0), "", v -> Prefs.put(c, Prefs.SENSI_Y, v)));
        TextView n = Ui.tv(c, "0 = normal, 10 = tertinggi.", 11.5f, Ui.MUTED, false);
        l.addView(n, Ui.wrapLp(c, 2));
        TextView a = Ui.tv(c, "Area sentuh", 12, Ui.MUTED, true);
        l.addView(a, Ui.wrapLp(c, 12));
        l.addView(Ui.chipsCompact(c, new String[]{"Kanan layar", "Seluruh layar"}, Prefs.i(c, Prefs.SENSI_ZONE, 0),
                i -> Prefs.put(c, Prefs.SENSI_ZONE, i)), Ui.wrapLp(c, 8));
        TextView h = Ui.tv(c, "Kanan layar menjaga joystick tetap normal. Berjalan lewat Shizuku dan berhenti sendiri saat keluar game.", 11, Ui.MUTED, false);
        h.setLineSpacing(0, 1.15f);
        l.addView(h, Ui.wrapLp(c, 8));
        l.addView(Ui.cbtn(c, "Kembalikan normal", false, true, v -> {
            Prefs.put(c, Prefs.SENSI_X, 0);
            Prefs.put(c, Prefs.SENSI_Y, 0);
            toast(c, "Sensi dikembalikan ke normal");
        }), Ui.wrapLp(c, 12));
        return l;
    }

    // ---------- Layar dan suara ----------

    static View brightness(Context c) {
        ContentResolver cr = c.getContentResolver();
        int br;
        try { br = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS); } catch (Exception e) { br = 128; }
        return Ui.slider(c, "Kecerahan", 1, 255, br, "", v -> {
            if (!Settings.System.canWrite(c)) { toast(c, "Izin ubah sistem belum diberikan"); return; }
            try {
                if (Prefs.i(c, Prefs.BR_ORIG, -1) < 0) {
                    Prefs.put(c, Prefs.BR_MODE, Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, 0));
                    Prefs.put(c, Prefs.BR_ORIG, Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128));
                }
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, 0);
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, v);
            } catch (Throwable t) { toast(c, "Gagal mengubah kecerahan"); }
        });
    }

    static View audio(Context c) {
        AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
        int max = Math.max(1, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        return Ui.slider(c, "Volume media", 0, max, am.getStreamVolume(AudioManager.STREAM_MUSIC), "", v -> {
            try {
                if (Prefs.i(c, Prefs.VOL_ORIG, -1) < 0)
                    Prefs.put(c, Prefs.VOL_ORIG, am.getStreamVolume(AudioManager.STREAM_MUSIC));
                am.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0);
            } catch (Throwable t) { toast(c, "Gagal mengubah volume"); }
        });
    }

    static View display(Context c) {
        LinearLayout l = Ui.col(c);
        l.addView(brightness(c));
        l.addView(audio(c));
        l.addView(Ui.button(c, "Kembalikan kecerahan, suara, Hz", false, v -> {
            Shell.async(() -> Resetter.restoreDisplay(c));
            toast(c, "Dikembalikan ke semula");
        }), Ui.wrapLp(c, 10));
        return l;
    }

    // ---------- Refresh rate ----------

    private static int modeIdFor(Context c, int hz) {
        try {
            Display d = ((DisplayManager) c.getSystemService(Context.DISPLAY_SERVICE)).getDisplay(Display.DEFAULT_DISPLAY);
            Display.Mode cur = d.getMode();
            for (Display.Mode m : d.getSupportedModes())
                if (m.getPhysicalWidth() == cur.getPhysicalWidth() && m.getPhysicalHeight() == cur.getPhysicalHeight()
                        && Math.round(m.getRefreshRate()) == hz) return m.getModeId();
        } catch (Throwable ignored) { }
        return -1;
    }

    private static String sget(String key) {
        String v = Shell.run("settings get system " + key).trim();
        return v.isEmpty() ? "null" : v;
    }

    /** Mengatur refresh rate lewat beberapa jalur sekaligus, karena tiap merek HP berbeda. */
    static void applyHz(Context c, int hz) {
        Shell.async(() -> {
            if (!Shell.ready()) { toast(c, "Shizuku belum aktif"); return; }
            if (!Prefs.b(c, Prefs.HZ_SET, false)) {
                SharedPreferences sp = Prefs.sp(c);
                sp.edit().putString("hz_o_peak", sget("peak_refresh_rate"))
                        .putString("hz_o_min", sget("min_refresh_rate"))
                        .putString("hz_o_user", sget("user_refresh_rate")).apply();
                int m0 = -1;
                try {
                    m0 = ((DisplayManager) c.getSystemService(Context.DISPLAY_SERVICE)).getDisplay(Display.DEFAULT_DISPLAY).getMode().getModeId();
                } catch (Throwable ignored) { }
                Prefs.put(c, Prefs.HZ_MODE0, m0);
                Prefs.put(c, Prefs.HZ_SET, true);
            }
            int mode = modeIdFor(c, hz);
            Shell.run("settings put system peak_refresh_rate " + hz
                    + "; settings put system min_refresh_rate " + hz
                    + "; settings put system user_refresh_rate " + hz
                    + (mode >= 0 ? "; service call SurfaceFlinger 1035 i32 " + mode : ""));
        });
    }

    // ---------- Tampilan kompak untuk panel dalam game ----------

    private static View chColorDots(Context c) {
        LinearLayout row = Ui.row(c);
        View[] ds = new View[CrosshairView.COLORS.length];
        int[] cur = {Prefs.i(c, Prefs.CH_COLOR, 0)};
        Runnable paint = () -> {
            for (int i = 0; i < ds.length; i++) {
                GradientDrawable g = new GradientDrawable();
                g.setShape(GradientDrawable.OVAL);
                g.setColor(CrosshairView.COLORS[i]);
                g.setStroke(Ui.dp(c, i == cur[0] ? 2.5f : 1), i == cur[0] ? 0xFFFFFFFF : 0x55FFFFFF);
                ds[i].setBackground(g);
            }
        };
        for (int i = 0; i < ds.length; i++) {
            View d = new View(c);
            final int idx = i;
            d.setOnClickListener(v -> { cur[0] = idx; Prefs.put(c, Prefs.CH_COLOR, idx); paint.run(); });
            ds[i] = d;
            row.addView(d, Ui.lp(c, Ui.dp(c, 26), Ui.dp(c, 26), 0, 0, 8, 0));
        }
        paint.run();
        return row;
    }

    static View crosshairSide(Context c) {
        LinearLayout l = Ui.col(c);
        l.addView(chSwitch(c));
        l.addView(Ui.chipsCompact(c, new String[]{"Titik", "Plus", "Cincin", "Bidik"}, Prefs.i(c, Prefs.CH_STYLE, 1),
                i -> Prefs.put(c, Prefs.CH_STYLE, i)), Ui.wrapLp(c, 4));
        l.addView(chColorDots(c), Ui.wrapLp(c, 12));
        chSliders(c, l);
        return l;
    }

    static View crosshairCompact(Context c) {
        LinearLayout l = Ui.col(c);
        LinearLayout r1 = Ui.row(c);
        r1.addView(Ui.switchRow(c, "Crosshair", null, Prefs.b(c, Prefs.CH_ON, false), v -> Prefs.put(c, Prefs.CH_ON, v)),
                new LinearLayout.LayoutParams(Ui.dp(c, 150), -2));
        r1.addView(Ui.chipsCompact(c, new String[]{"Titik", "Plus", "Cincin", "Bidik"}, Prefs.i(c, Prefs.CH_STYLE, 1),
                i -> Prefs.put(c, Prefs.CH_STYLE, i)), Ui.lp(c, 0, -2, 12, 0, 12, 0));
        ((LinearLayout.LayoutParams) r1.getChildAt(1).getLayoutParams()).weight = 1f;
        r1.addView(chColorDots(c));
        l.addView(r1);
        LinearLayout g = Ui.row(c);
        g.setGravity(Gravity.TOP);
        LinearLayout a = Ui.col(c), b = Ui.col(c);
        a.addView(Ui.slider(c, "Ukuran", 8, 90, Prefs.i(c, Prefs.CH_SIZE, 28), " dp", v -> Prefs.put(c, Prefs.CH_SIZE, v)));
        a.addView(Ui.slider(c, "Transparansi", 20, 100, Prefs.i(c, Prefs.CH_ALPHA, 90), "%", v -> Prefs.put(c, Prefs.CH_ALPHA, v)));
        b.addView(Ui.slider(c, "Geser kiri / kanan", -80, 80, Prefs.i(c, Prefs.CH_DX, 0), "", v -> Prefs.put(c, Prefs.CH_DX, v)));
        b.addView(Ui.slider(c, "Geser atas / bawah", -80, 80, Prefs.i(c, Prefs.CH_DY, 0), "", v -> Prefs.put(c, Prefs.CH_DY, v)));
        g.addView(a, new LinearLayout.LayoutParams(0, -2, 1f));
        g.addView(b, Ui.lp(c, 0, -2, 20, 0, 0, 0));
        ((LinearLayout.LayoutParams) b.getLayoutParams()).weight = 1f;
        l.addView(g, Ui.wrapLp(c, 4));
        return l;
    }
}

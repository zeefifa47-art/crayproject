package com.cray.hazi;

import android.content.Context;
import android.content.pm.PackageManager;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import rikka.shizuku.Shizuku;

/** Menjalankan perintah shell lewat Shizuku. */
final class Shell {
    private static final ExecutorService EX = Executors.newSingleThreadExecutor();

    static boolean ready() {
        try {
            return Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    static void async(Runnable r) { EX.execute(r); }

    static String run(String cmd) {
        try {
            Method m = Shizuku.class.getDeclaredMethod("newProcess", String[].class, String[].class, String.class);
            m.setAccessible(true);
            Process p = (Process) m.invoke(null, new Object[]{new String[]{"sh", "-c", cmd + " 2>&1"}, null, null});
            StringBuilder sb = new StringBuilder();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String s;
                while ((s = br.readLine()) != null) sb.append(s).append('\n');
            }
            p.waitFor();
            return sb.toString();
        } catch (Throwable t) {
            return "";
        }
    }

    /** Menyalin file dari assets ke lokasi yang bisa dijalankan oleh shell, lalu chmod 755. */
    static boolean pushAsset(Context c, String asset, String dest) {
        try {
            Method m = Shizuku.class.getDeclaredMethod("newProcess", String[].class, String[].class, String.class);
            m.setAccessible(true);
            Process p = (Process) m.invoke(null, new Object[]{new String[]{"sh", "-c", "cat > " + dest + " && chmod 755 " + dest}, null, null});
            try (InputStream in = c.getAssets().open(asset); OutputStream os = p.getOutputStream()) {
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
            }
            return p.waitFor() == 0;
        } catch (Throwable t) {
            return false;
        }
    }
}

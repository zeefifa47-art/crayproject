package com.cray.hazi;

import android.app.Activity;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Halaman Owner: pemilik dan co-owner DRAX. */
final class OwnerPage {
    private static View person(Activity a, int photo, String role, String name, String handle) {
        LinearLayout c = Ui.card(a);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setPadding(Ui.dp(a, 20), Ui.dp(a, 24), Ui.dp(a, 20), Ui.dp(a, 20));
        c.addView(Ui.roundPhoto(a, photo, 128));
        TextView rp = Ui.tv(a, role, 11.5f, Ui.ON_ACC, true);
        rp.setLetterSpacing(.12f);
        rp.setPadding(Ui.dp(a, 14), Ui.dp(a, 6), Ui.dp(a, 14), Ui.dp(a, 6));
        rp.setBackground(Ui.gradBg(a, 14));
        c.addView(rp, Ui.lp(a, -2, -2, 0, 16, 0, 0));
        TextView nm = Ui.tv(a, name, 22, Ui.TXT, true);
        nm.setGravity(Gravity.CENTER);
        c.addView(nm, Ui.wrapLp(a, 10));
        TextView hd = Ui.tv(a, "TikTok  @" + handle, 13, Ui.MUTED, false);
        hd.setGravity(Gravity.CENTER);
        c.addView(hd, Ui.wrapLp(a, 4));
        c.addView(Ui.cbtn(a, "Buka TikTok", true, false, v -> HomePage.open(a, "https://www.tiktok.com/@" + handle)), Ui.wrapLp(a, 16));
        return c;
    }

    static View build(Activity a) {
        ScrollView sv = new ScrollView(a);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout l = Ui.col(a);
        int p = Ui.dp(a, 20);
        l.setPadding(p, Ui.dp(a, 14), p, Ui.dp(a, 24));
        sv.addView(l);

        l.addView(Ui.tv(a, "Owner", 26, Ui.TXT, true));
        l.addView(Ui.tv(a, "Orang-orang di balik DRAX", 13, Ui.MUTED, false), Ui.wrapLp(a, 4));
        l.addView(person(a, R.drawable.owner_hazi, "OWNER", "Hazi Tamvan", "inihazi"), Ui.wrapLp(a, 20));
        l.addView(person(a, R.drawable.owner_hans, "CO-OWNER", "Hans", "hansssanjay1945"), Ui.wrapLp(a, 16));
        TextView foot = Ui.tv(a, "DRAX · terima kasih sudah memakai", 11.5f, Ui.MUTED, false);
        foot.setGravity(Gravity.CENTER);
        l.addView(foot, Ui.wrapLp(a, 18));
        return sv;
    }
}

package com.cray.hazi;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

final class CrosshairView extends View {
    static final int[] COLORS = {0xFFFFD60A, 0xFFFF3B30, 0xFF34C759, 0xFFFFFFFF, 0xFF00E5FF};
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shadow = new Paint(Paint.ANTI_ALIAS_FLAG);

    CrosshairView(Context c) {
        super(c);
        p.setStrokeCap(Paint.Cap.ROUND);
        shadow.setStrokeCap(Paint.Cap.ROUND);
        shadow.setColor(0xFF000000);
    }

    @Override protected void onDraw(Canvas cv) {
        Context c = getContext();
        int style = Prefs.i(c, Prefs.CH_STYLE, 1);
        int color = COLORS[Math.max(0, Math.min(COLORS.length - 1, Prefs.i(c, Prefs.CH_COLOR, 0)))];
        int a = Prefs.i(c, Prefs.CH_ALPHA, 90) * 255 / 100;
        float cx = getWidth() / 2f, cy = getHeight() / 2f;
        float r = Math.min(getWidth(), getHeight()) / 2f - Ui.dp(c, 2);
        float sw = Math.max(Ui.dp(c, 1.6f), r / 12f);
        p.setColor(color);
        p.setAlpha(a);
        shadow.setAlpha(a / 2);
        draw(cv, style, cx, cy, r, sw, shadow, sw + Ui.dp(c, 1.4f));
        draw(cv, style, cx, cy, r, sw, p, sw);
    }

    private void draw(Canvas cv, int style, float cx, float cy, float r, float sw, Paint pt, float w) {
        pt.setStrokeWidth(w);
        pt.setStyle(Paint.Style.STROKE);
        float gap = r * 0.28f;
        switch (style) {
            case 0:
                pt.setStyle(Paint.Style.FILL);
                cv.drawCircle(cx, cy, Math.max(w * 1.4f, r / 5f), pt);
                break;
            case 1:
                cv.drawLine(cx - r, cy, cx - gap, cy, pt);
                cv.drawLine(cx + gap, cy, cx + r, cy, pt);
                cv.drawLine(cx, cy - r, cx, cy - gap, pt);
                cv.drawLine(cx, cy + gap, cx, cy + r, pt);
                break;
            case 2:
                cv.drawCircle(cx, cy, r * 0.85f, pt);
                pt.setStyle(Paint.Style.FILL);
                cv.drawCircle(cx, cy, Math.max(w, r / 9f), pt);
                break;
            default:
                cv.drawCircle(cx, cy, r * 0.6f, pt);
                cv.drawLine(cx - r, cy, cx - r * 0.35f, cy, pt);
                cv.drawLine(cx + r * 0.35f, cy, cx + r, cy, pt);
                cv.drawLine(cx, cy - r, cx, cy - r * 0.35f, pt);
                cv.drawLine(cx, cy + r * 0.35f, cx, cy + r, pt);
                pt.setStyle(Paint.Style.FILL);
                cv.drawCircle(cx, cy, Math.max(w * 0.9f, r / 10f), pt);
        }
    }
}

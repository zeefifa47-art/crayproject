package com.cray.hazi;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

/** Batang tipis berwarna tema di tepi kiri layar. Geser ke kanan atau ketuk untuk membuka panel. */
final class HandleView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    HandleView(Context c) { super(c); }

    @Override protected void onMeasure(int w, int h) {
        setMeasuredDimension(Ui.dp(getContext(), 20), Ui.dp(getContext(), 60));
    }

    @Override protected void onDraw(Canvas cv) {
        Context c = getContext();
        float h = getHeight(), r = Ui.dp(c, 8);
        p.setShader(new LinearGradient(0, 0, 0, h, Ui.YEL, Ui.ACC2, Shader.TileMode.CLAMP));
        cv.drawRoundRect(new RectF(-r, Ui.dp(c, 2), Ui.dp(c, 12), h - Ui.dp(c, 2)), r, r, p);
    }
}

package com.cray.hazi;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Tab "Pengaturan Cepat" di tengah atas layar; geser ke bawah atau ketuk untuk membuka panel. */
final class HandleView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG), t = new Paint(Paint.ANTI_ALIAS_FLAG);

    HandleView(Context c) {
        super(c);
        t.setTextAlign(Paint.Align.CENTER);
        t.setTypeface(Ui.bold(c));
    }

    @Override protected void onMeasure(int w, int h) {
        setMeasuredDimension(Ui.dp(getContext(), 150), Ui.dp(getContext(), 26));
    }

    @Override protected void onDraw(Canvas cv) {
        Context c = getContext();
        float w = getWidth(), h = getHeight(), r = Ui.dp(c, 13);
        p.setColor(Ui.acc(0xE6));
        cv.drawRoundRect(new RectF(0, -r, w, h), r, r, p);
        t.setColor(Ui.ON_ACC);
        t.setTextSize(Ui.dp(c, 10));
        cv.drawText("Pengaturan Cepat", w / 2f, h * 0.55f, t);
        p.setColor(Ui.alpha(Ui.ON_ACC, 0x66));
        cv.drawRoundRect(new RectF(w / 2 - Ui.dp(c, 14), h - Ui.dp(c, 6), w / 2 + Ui.dp(c, 14), h - Ui.dp(c, 3.5f)),
                Ui.dp(c, 2), Ui.dp(c, 2), p);
    }
}

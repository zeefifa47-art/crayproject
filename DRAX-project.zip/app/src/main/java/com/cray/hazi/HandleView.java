package com.cray.hazi;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Tab kecil di tepi kanan layar dengan tanda "‹". Geser ke kiri atau ketuk untuk membuka panel. */
final class HandleView extends View {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), line = new Paint(Paint.ANTI_ALIAS_FLAG),
            arrow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    HandleView(Context c) {
        super(c);
        line.setStyle(Paint.Style.STROKE);
        arrow.setStyle(Paint.Style.STROKE);
        arrow.setStrokeCap(Paint.Cap.ROUND);
        arrow.setStrokeJoin(Paint.Join.ROUND);
    }

    @Override protected void onMeasure(int w, int h) {
        setMeasuredDimension(Ui.dp(getContext(), 26), Ui.dp(getContext(), 64));
    }

    @Override protected void onDraw(Canvas cv) {
        Context c = getContext();
        float w = getWidth(), h = getHeight(), r = Ui.dp(c, 14);
        cv.clipRect(0, 0, w, h);
        fill.setColor(Ui.alpha(Ui.BG, 0xE6));
        line.setColor(Ui.acc(0x88));
        line.setStrokeWidth(Ui.dp(c, 1));
        RectF rc = new RectF(Ui.dp(c, 0.5f), Ui.dp(c, 0.5f), w + r, h - Ui.dp(c, 0.5f));
        cv.drawRoundRect(rc, r, r, fill);
        cv.drawRoundRect(rc, r, r, line);
        arrow.setColor(Ui.YEL);
        arrow.setStrokeWidth(Ui.dp(c, 2.4f));
        path.reset();
        path.moveTo(w * 0.62f, h * 0.36f);
        path.lineTo(w * 0.38f, h * 0.5f);
        path.lineTo(w * 0.62f, h * 0.64f);
        cv.drawPath(path, arrow);
    }
}

package com.cray.hazi;

import android.app.Activity;
import android.content.ContentValues;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.OutputStream;

final class DonatePage {
    static View build(Activity a) {
        ScrollView sv = new ScrollView(a);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout l = Ui.col(a);
        int p = Ui.dp(a, 20);
        l.setPadding(p, Ui.dp(a, 8), p, Ui.dp(a, 32));
        l.setGravity(Gravity.CENTER_HORIZONTAL);
        sv.addView(l);

        TextView t = Ui.tv(a, "Dukung DRAX", 26, Ui.YEL, true);
        t.setTypeface(Ui.brand(a));
        l.addView(t, new LinearLayout.LayoutParams(-1, -2));
        TextView s = Ui.tv(a, "Suka dengan DRAX? Dukung pengembangannya lewat QRIS. Bisa dari semua e-wallet dan m-banking.", 13, Ui.MUTED, false);
        s.setLineSpacing(0, 1.2f);
        l.addView(s, Ui.wrapLp(a, 6));

        LinearLayout box = Ui.col(a);
        box.setPadding(Ui.dp(a, 10), Ui.dp(a, 10), Ui.dp(a, 10), Ui.dp(a, 10));
        box.setBackground(Ui.rect(a, Color.WHITE, 22));
        ImageView iv = new ImageView(a);
        iv.setAdjustViewBounds(true);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        TextView msg = Ui.tv(a, "Memuat QR...", 13, Ui.DARK, true);
        msg.setGravity(Gravity.CENTER);
        msg.setPadding(0, Ui.dp(a, 60), 0, Ui.dp(a, 60));
        box.addView(msg, new LinearLayout.LayoutParams(-1, -2));
        l.addView(box, Ui.wrapLp(a, 18));

        TextView save = Ui.button(a, "Simpan QR ke Galeri", true, null);
        save.setVisibility(View.GONE);
        l.addView(save, Ui.wrapLp(a, 14));
        TextView note = Ui.tv(a, "Terima kasih banyak. Dukunganmu bikin DRAX terus berkembang.", 12, Ui.MUTED, false);
        note.setGravity(Gravity.CENTER);
        l.addView(note, Ui.wrapLp(a, 14));

        Handler main = new Handler(Looper.getMainLooper());
        new Thread(() -> {
            Bitmap bmp = Guard.qr(a);
            main.post(() -> {
                box.removeAllViews();
                if (bmp == null) {
                    TextView bad = Ui.tv(a, "QR tidak bisa dimuat. Pasang DRAX resmi dari @inihazi.", 13, Ui.DARK, true);
                    bad.setGravity(Gravity.CENTER);
                    bad.setPadding(Ui.dp(a, 12), Ui.dp(a, 50), Ui.dp(a, 12), Ui.dp(a, 50));
                    box.addView(bad);
                    return;
                }
                iv.setImageBitmap(bmp);
                box.addView(iv, new LinearLayout.LayoutParams(-1, -2));
                save.setVisibility(View.VISIBLE);
                save.setOnClickListener(v -> saveToGallery(a, bmp));
            });
        }).start();
        return sv;
    }

    private static void saveToGallery(Activity a, Bitmap bmp) {
        if (Build.VERSION.SDK_INT < 29) { Panels.toast(a, "Screenshot layar ini saja ya"); return; }
        try {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Images.Media.DISPLAY_NAME, "DRAX-QRIS.png");
            cv.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            cv.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/DRAX");
            Uri u = a.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
            try (OutputStream o = a.getContentResolver().openOutputStream(u)) {
                bmp.compress(Bitmap.CompressFormat.PNG, 100, o);
            }
            Panels.toast(a, "QR tersimpan di Galeri");
        } catch (Throwable t) {
            Panels.toast(a, "Gagal menyimpan");
        }
    }
}

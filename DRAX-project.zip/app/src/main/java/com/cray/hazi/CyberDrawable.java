package com.cray.hazi;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/** Persegi membulat dengan isi gradien dan garis tepi. (Nama lama dipertahankan.) */
final class CyberDrawable extends Drawable {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final float radius, sw;
    private final int c0, c1;

    CyberDrawable(Context c, int c0, int c1, int stroke, float strokeDp, float cutDp, boolean stripes) {
        this.c0 = c0;
        this.c1 = c1;
        this.radius = Ui.dp(c, cutDp * 1.5f);
        this.sw = Ui.dp(c, strokeDp);
        line.setStyle(Paint.Style.STROKE);
        line.setColor(stroke);
        line.setStrokeWidth(sw);
    }

    CyberDrawable all() { return this; }
    CyberDrawable banner(Bitmap b) { return this; }

    @Override protected void onBoundsChange(Rect b) {
        float i = sw / 2f;
        r.set(b.left + i, b.top + i, b.right - i, b.bottom - i);
        fill.setColor(c0);
        fill.setShader(c0 == c1 ? null : new LinearGradient(b.left, b.top, b.right, b.bottom, c0, c1, Shader.TileMode.CLAMP));
    }

    @Override public void draw(Canvas cv) {
        cv.drawRoundRect(r, radius, radius, fill);
        if (sw > 0) cv.drawRoundRect(r, radius, radius, line);
    }

    @Override public void setAlpha(int a) { fill.setAlpha(a); line.setAlpha(a); }
    @Override public void setColorFilter(ColorFilter f) { }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}

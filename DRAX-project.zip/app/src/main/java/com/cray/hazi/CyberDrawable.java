package com.cray.hazi;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/** Bentuk bergaya cyber: sudut kiri atas dan kanan bawah dipotong, opsional garis diagonal. */
final class CyberDrawable extends Drawable {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), line = new Paint(Paint.ANTI_ALIAS_FLAG),
            stripe = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final float cut, sw, gap;
    private final int c0, c1;
    private final boolean stripes;

    CyberDrawable(Context c, int c0, int c1, int stroke, float strokeDp, float cutDp, boolean stripes) {
        this.c0 = c0;
        this.c1 = c1;
        this.cut = Ui.dp(c, cutDp);
        this.sw = Ui.dp(c, strokeDp);
        this.gap = Ui.dp(c, 9);
        this.stripes = stripes;
        line.setStyle(Paint.Style.STROKE);
        line.setColor(stroke);
        line.setStrokeWidth(sw);
        stripe.setStyle(Paint.Style.STROKE);
        stripe.setColor(0x12FFFFFF);
        stripe.setStrokeWidth(Ui.dp(c, 1.2f));
    }

    @Override protected void onBoundsChange(Rect b) {
        float i = sw / 2f;
        float l = b.left + i, t = b.top + i, r = b.right - i, bt = b.bottom - i;
        path.reset();
        path.moveTo(l + cut, t);
        path.lineTo(r, t);
        path.lineTo(r, bt - cut);
        path.lineTo(r - cut, bt);
        path.lineTo(l, bt);
        path.lineTo(l, t + cut);
        path.close();
        fill.setColor(c0);
        fill.setShader(c0 == c1 ? null : new LinearGradient(b.left, b.top, b.right, b.bottom, c0, c1, Shader.TileMode.CLAMP));
    }

    @Override public void draw(Canvas cv) {
        Rect b = getBounds();
        cv.drawPath(path, fill);
        if (stripes) {
            cv.save();
            cv.clipPath(path);
            float h = b.height();
            for (float x = -h; x < b.width() + h; x += gap) cv.drawLine(b.left + x, b.bottom, b.left + x + h, b.top, stripe);
            cv.restore();
        }
        if (sw > 0) cv.drawPath(path, line);
    }

    @Override public void setAlpha(int a) { fill.setAlpha(a); line.setAlpha(a); }
    @Override public void setColorFilter(ColorFilter f) { }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}

package com.cray.hazi;

import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.security.MessageDigest;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/** QR donasi terikat ke sertifikat penandatangan: APK yang di-resign tidak bisa membukanya. */
final class Guard {
    private static byte[] key(Context c) throws Exception {
        Signature[] s = c.getPackageManager()
                .getPackageInfo(c.getPackageName(), PackageManager.GET_SIGNING_CERTIFICATES)
                .signingInfo.getApkContentsSigners();
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] h = md.digest(s[0].toByteArray());
        md.reset();
        md.update(h);
        md.update("com.cray.hazi|CRAY-QRIS".getBytes("UTF-8"));
        return md.digest();
    }

    /** Mengembalikan null jika aplikasi bukan build resmi. */
    static Bitmap qr(Context c) {
        try {
            byte[] enc;
            try (InputStream in = c.getAssets().open("q.bin"); ByteArrayOutputStream bo = new ByteArrayOutputStream()) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                enc = bo.toByteArray();
            }
            Cipher ci = Cipher.getInstance("AES/GCM/NoPadding");
            ci.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key(c), "AES"), new GCMParameterSpec(128, enc, 0, 12));
            byte[] img = ci.doFinal(enc, 12, enc.length - 12);
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inSampleSize = 1;
            return BitmapFactory.decodeByteArray(img, 0, img.length, o);
        } catch (Throwable t) {
            return null;
        }
    }
}

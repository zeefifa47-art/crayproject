# Mengikat QR donasi ke sertifikat penandatangan APK (AES-GCM).
# APK yang di-resign orang lain tidak akan bisa membuka QR-nya.
import sys, hashlib, os
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
cert = open(sys.argv[1], 'rb').read()
img = open(sys.argv[2], 'rb').read()
key = hashlib.sha256(hashlib.sha256(cert).digest() + b"com.cray.hazi|CRAY-QRIS").digest()
iv = os.urandom(12)
os.makedirs(os.path.dirname(sys.argv[3]), exist_ok=True)
open(sys.argv[3], 'wb').write(iv + AESGCM(key).encrypt(iv, img, None))
print("QR terikat ke tanda tangan:", hashlib.sha256(cert).hexdigest()[:16])
